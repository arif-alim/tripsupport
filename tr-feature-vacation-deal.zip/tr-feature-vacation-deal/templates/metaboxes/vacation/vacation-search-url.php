<?php
global $post;
$post_vacation_Search_Url = get_post_meta($post->ID, 'vacation_search_url', true);
$post_vacation_search_title = get_post_meta($post->ID, 'vacation_search_title', true);
$post_vacation_search_description = get_post_meta($post->ID, 'vacation_search_description', true);
?>

<label>Vacation Search URL : </label>
<input type="url" style="width: 100%;" name="vacation_search_url" value="<?php echo $post_vacation_Search_Url ?>">

<label>Title:</label>
<input type="text" style="width: 100%;" name="vacation_search_title" value="<?php echo $post_vacation_search_title ?>">

<label>Description</label>
<textarea style="width: 100%;" name="vacation_search_description"><?php echo $post_vacation_search_description ?></textarea>
