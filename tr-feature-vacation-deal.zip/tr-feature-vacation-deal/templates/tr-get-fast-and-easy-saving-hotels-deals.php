<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<div class="col-md-12 pr-0 pr-md-2">
    <p class="tr-get-fast-and-easy-saving-htels-deals-main-title m-0 pb-2">Get fast & easy savings on hotel deals</p>
    <p class="tr-get-fast-and-easy-saving-htels-deals-second-title m-0 pb-4">Staying local or international doesn’t have
        to be
        second
        rate. Choose an extra-special hotel for a trip to remember.</p>
    <div class="row col-md-12 mb-3 p-0 m-0">
        <div class="swiper-container tr-get-fast-easy-saving-hotel-swiper-slide">
            <div class="swiper-wrapper">

                <?php foreach ($hotels->data as $hotel): ?>
                <?php if(!empty($hotel->hotel->mainImge)){?>

                    <div class="tr-get-fast-and-easy-hotels-each-item-container swiper-slide p-0">
                        <div class="tr-get-fast-and-easy-hotels-each-item-imag"
                             style="background-image: url(<?php echo $hotel->hotel->mainImge ?>)">
                    <span class="tr-get-fast-and-easy-hotels-each-item-rate-container float-right mt-1 mr-1">
                        <i class="fa fa-star" style="color: #FFB310"></i><?php echo $hotel->hotel->rating ?> (1332)
                    </span>
                        </div>
                        <div class="pt-2 pb-1">
                            <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                      fill="#007AFF"/>
                            </svg>
                            <span class="tr-get-fast-and-easy-hotels-each-item-location-text pt-2 pb-2">
                           <?php echo $hotel->hotel->placeInfo->city->name ?>
                                , <?php echo $hotel->hotel->placeInfo->country->name ?>                    </span>
                        </div>
                        <p class="m-0 tr-get-fast-and-easy-hotels-each-item-hotel-name pb-2"><?php echo substr($hotel->hotel->name, 0, 15) ?></p>
                        <p class="m-0 tr-get-fast-and-easy-hotels-each-item-price">CA
                            $<?php echo $hotel->availableRooms[0]->price->amount ?> <span class="font-weight-light">/ night</span>
                        </p>
                        <p class="m-0 tr-get-fast-and-easy-hotels-each-item-tax">price includes taxes and fees</p>
                        <p class="m-0 tr-get-fast-and-easy-hotels-each-item-pay-later">Free Cancellation, Reserve now
                            pay
                            later</p>
                    </div>
                <?php } ?>
                <?php endforeach; ?>
            </div>
            <br><br>
            <!-- If we need pagination -->
            <div class="swiper-pagination d-block d-sm-none"></div>

        </div>
        <div class="d-none d-sm-flex swiper-button-prev ">
            <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0.861978 8.68671L6.46214 14.8097C6.92546 15.2767 7.66838 15.3213 8.15605 14.9617C8.64369 14.6022 8.72405 13.8756 8.32469 13.4365L4.3371 9.08065H16.2001C16.8628 9.08065 17.4001 8.59689 17.4001 8.00015C17.4001 7.40338 16.8628 6.91963 16.2001 6.91963H4.3371L8.32469 2.56376C8.72405 2.12474 8.63418 1.40827 8.15605 1.03856C7.66302 0.657276 6.86138 0.751468 6.46214 1.19059L0.861978 7.31355C0.497418 7.77511 0.528538 8.24038 0.861978 8.68671Z"
                      fill="#66678F"/>
            </svg>
        </div>
        <div class="d-none d-sm-flex swiper-button-next ">
            <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.138 8.68671L11.5379 14.8097C11.0745 15.2767 10.3316 15.3213 9.84395 14.9617C9.35631 14.6022 9.27595 13.8756 9.67531 13.4365L13.6629 9.08065H1.79994C1.13718 9.08065 0.599899 8.59689 0.599899 8.00015C0.599899 7.40338 1.13718 6.91963 1.79994 6.91963H13.6629L9.67531 2.56376C9.27595 2.12474 9.36582 1.40827 9.84395 1.03856C10.337 0.657276 11.1386 0.751468 11.5379 1.19059L17.138 7.31355C17.5026 7.77511 17.4715 8.24038 17.138 8.68671Z"
                      fill="#66678F"/>
            </svg>
        </div>
    </div>
</div>
<style>
    .swiper-pagination-bullet {
        background-color: white !important;
        border: 1px solid gray;
    }

    .swiper-pagination-bullet-active {
        background-color: white !important;
        border: 1px solid red !important;
    }

    .tr-get-fast-and-easy-saving-htels-deals-main-title {
        font-style: normal;
        font-weight: 700;
        font-size: 26px;
        line-height: 100%;
        letter-spacing: -0.02em;
        color: #0C0D25;
        font-family: "Cera PRO";
    }

    .tr-get-fast-and-easy-saving-htels-deals-second-title {
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        line-height: 24px;
        letter-spacing: -0.02em;
        color: #66678F;
        m-0 pb-2
    }

    .swiper-button-next {
        background-color: white;
        color: #0C0D25 !important;
        border-radius: 100%;
        box-shadow: 0px 5px 5px rgba(102, 103, 143, 0.04);
        margin-right: -60px;
        width: 40px;
        height: 40px;
        border: 1px solid rgba(102, 103, 143, 0.1);
    }

    .swiper-button-prev {
        background-color: white;
        color: #0C0D25 !important;
        border-radius: 100%;
        box-shadow: 0px 5px 5px rgba(102, 103, 143, 0.04);
        margin-left: -60px;
        width: 40px;
        height: 40px;
        border: 1px solid rgba(102, 103, 143, 0.1);
    }

    .swiper-button-next::after {
        font-size: 10px !important;
        font-weight: bold;
        color: #66678F !important;
        display: none !important;
    }

    .swiper-button-prev::after {
        font-size: 10px !important;
        font-weight: bold;
        color: #66678F !important;
        display: none !important;
    }

    .tr-get-fast-and-easy-hotels-each-item-imag {
        width: 100%;
        height: 250px;
        background-position: center center;
        background-size: cover;
        background-repeat: no-repeat;
        border-radius: 8px;
    }

    .tr-get-fast-and-easy-hotels-each-item-location-text {
        color: #007AFF;
        font-size: 12px;
        font-weight: bold;
        font-family: "Cera PRO";
    }

    .tr-get-fast-and-easy-hotels-each-item-hotel-name {
        color: #0C0D25;
        font-size: 20px;
        font-family: "Cera PRO";
    }

    .tr-get-fast-and-easy-hotels-each-item-tax {
        color: #66678F;
        font-size: 12px;
        font-family: "Cera PRO";
    }

    .tr-get-fast-and-easy-hotels-each-item-price {
        color: #0C0D25;
        font-weight: bold;
        font-family: "Cera PRO";
    }

    .tr-get-fast-and-easy-hotels-each-item-rate-container {
        background-color: #fff;
        font-size: 14px;
        padding: 5px;
        border: 1px solid rgba(68, 69, 96, 0.1) !important;
        border-radius: 8px !important;
        font-family: "Cera PRO";
        font-weight: 500;
    }

    .tr-get-fast-and-easy-hotels-each-item-pay-later {
        color: #00AD45;
        font-size: 12px;
        font-family: "Cera PRO";
    }

    .swiper-container {
        width: 100% !important;
        overflow: hidden;

    }

    .swiper-container-pointer-events {
        margin: 0px !important;
    }

</style>
<script type="module">
    var swiperEasyAndFastHotel = new Swiper('.tr-get-fast-easy-saving-hotel-swiper-slide', {
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
        },
        slidesPerView: 4,
        spaceBetween: 10,
        breakpoints: {

            960: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            720: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            540: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            320: {
                slidesPerView: 1.5,
                spaceBetween: 10
            },
        }
    });
</script>
