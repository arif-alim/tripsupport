<section class="ts-py">
    <div class="ts-container">
        <div class="ts-head-tbl">
            <div class="ts-d-flex">
                <div class="ts-col-tbl-40">From</div>
                <div class="ts-col-tbl-15">Depart</div>
                <div class="ts-col-tbl-15">Return</div>
                <div class="ts-col-tbl-15 ts-text-center">Fare*</div>
                <div class="ts-col-tbl-15">As low as</div>
            </div>
        </div>

        <div class="ts-body-tbl">
            <?php foreach ($destinations as $destination): ?>

                <div class="ts-row-tbl">
                    <div class="ts-d-flex">
                        <div class="ts-col-tbl-40">
                            <span class="ts-airport-code"><?php echo $destination->city ?></span>
                            <span class="ts-airport-name"><?php echo $destination->fromAirportCode ?></span>
                        </div>
                        <div class="ts-col-tbl-15 ts-depart"> <?php echo $this->getCurrentDate($destination->departureDate_DaysFromNow, 'M d,Y') ?> </div>
                        <div class="ts-col-tbl-15 ts-return"> <?php echo $this->getCurrentDate($destination->returnDate_DaysFromNow, 'M d,Y') ?> </div>
                        <div class="ts-col-tbl-15 ts-text-center ts-fare"> CA$<?php echo $destination->price ?> </div>
                        <div class="ts-col-tbl-15 ts-as-low"> CA$<?php echo round($destination->price / 3) ?></div>
                    </div>
                </div>

            <?php endforeach; ?>
        </div>
    </div>

</section>