<?php


namespace Tr\Feature\Vacation;


class Enqueue
{

    public function add()
    {
        $this->featureVacationTicketCss()
            ->featureVacationBootstrapCss()
            ->featureVacationBootstrapJs()
            ->addCeraFont()
            ->flickitySlider()
            ->swiperSlider()
            ->addSnackbar();
    }

    public function flickitySlider()
    {
        wp_register_script(
            'tr_flickity_slider',
            'https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js',
            ['jquery'],
            '2.0',
            true);
        wp_enqueue_script('tr_flickity_slider');

        wp_register_style('tr_flickity_style', 'https://unpkg.com/flickity@2/dist/flickity.min.css');
        wp_enqueue_style('tr_flickity_style');

        return $this;
    }

    public function swiperSlider()
    {
        wp_register_script(
            'tr_swiper_slider',
            'https://unpkg.com/swiper/swiper-bundle.min.js',
            ['jquery'],
            '2.0',
            false);
        wp_enqueue_script('tr_swiper_slider');

        wp_register_style('tr_swiper_style', 'https://unpkg.com/swiper/swiper-bundle.min.css');
        wp_enqueue_style('tr_swiper_style');

        return $this;
    }

    public function addCeraFont()
    {
        wp_register_style('tr_cera_font_css', TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . 'assets/css/font.css');
        wp_enqueue_style('tr_cera_font_css');

        return $this;
    }

    /**
     * @return $this
     */
    public function featureVacationBootstrapJs()
    {
        wp_enqueue_script('tr_popper_js',
            'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js',
            ['jquery'],
            '1.14.6',
            true);

        wp_enqueue_script('tr_bootstrap_js',
            'https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js',
            ['jquery'],
            '4.2.1',
            true);

        return $this;
    }

    /**
     * @return $this
     */
    public function featureVacationTicketJs()
    {
        wp_register_script('tr_feature_vacation_ticket_js',
            TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . '/assets/js/ticket.js');
        wp_enqueue_script('tr_feature_vacation_ticket_js');

        return $this;
    }

    /**
     * @return $this
     */
    public function featureVacationOwlCarouselJs()
    {
        wp_register_script('tr_feature_vacation_ticket_js',
            TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . '/assets/js/owl.carousel.min.js', ['jquery']);
        wp_enqueue_script('tr_feature_vacation_ticket_js');

        return $this;
    }

    public function featureVacationBootstrapCss()
    {
        //wp_register_style('tr_bootstrap_css', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css');
        wp_register_style('tr_bootstrap_css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css');
        wp_enqueue_style('tr_bootstrap_css');

        return $this;
    }

    /**
     * @return $this
     */
    public function featureVacationOwlCss()
    {
        wp_register_style('tr_feature_vacation_ticket_css',
            TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . '/assets/css/owl.carousel.min.css'
        );
        wp_enqueue_style('tr_feature_vacation_owl_carousel_css');

        return $this;
    }

    /**
     * @return $this
     */
    public function featureVacationTicketCss()
    {
        wp_register_style('tr_feature_vacation_ticket_css',
            TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . '/assets/css/main.css'
        );
        wp_enqueue_style('tr_feature_vacation_ticket_css');

        return $this;
    }

    /**
     * @return $this
     */
    public function featureVacationDatepickerCss()
    {
        wp_register_style('tr_feature_vacation_ticket_css',
            TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . '/assets/css/owl.datepicker.css'
        );
        wp_enqueue_style('tr_feature_vacation_owl_carousel_css');

        return $this;
    }

    public function addSnackbar()
    {
        wp_register_style('tr_snackbar_css', TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . '/assets/css/snackbar.css');
        wp_enqueue_style('tr_snackbar_css');
        wp_register_script('tr_snackbar_js', TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL . '/assets/js/snackbar.js', ['jquery'], '1.0.0', false);
        wp_enqueue_script('tr_snackbar_js');

        return $this;
    }
}