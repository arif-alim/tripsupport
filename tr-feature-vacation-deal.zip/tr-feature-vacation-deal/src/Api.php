<?php


namespace Tr\Feature\Vacation;


class Api
{
    const NAMEPACE = 'trip-support-endpoints/v1';

    public function add()
    {
        add_action('rest_api_init', array($this, 'getUserLocationById'));
    }

    public function getUserLocationById() {
        register_rest_route(self::NAMEPACE, '/user/geolocation', array(
            'method' => \WP_REST_Server::READABLE,
            'callback' => array($this, 'getUserLocationByIdCallback')
        ));
    }

    /**
     * @return array
     */
    public function getUserLocationByIdCallback() {
        $userIp = (new UserGeolocationService())->get();
        return ['data' => json_decode($userIp)];
    }
}