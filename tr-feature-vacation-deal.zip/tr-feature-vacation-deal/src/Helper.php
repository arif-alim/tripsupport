<?php


namespace Tr\Feature\Vacation;


use Carbon\Carbon;

class Helper
{
    /**
     * @var Database
     */
    private $DB;

    /**
     * Helper constructor.
     */
    public function __construct()
    {
        $this->DB = new Database();
    }

    /**
     * @param $date
     * @return bool
     */
    public function isMoreThanOneWeekAgo($date)
    {
        if (Carbon::now()->subWeek()->gt($date)) {
            return true;
        }

        return false;
    }

    /**
     * @param $fieldName
     * @return array|object|null
     */
    public function getCacheDataFrom($fieldName)
    {
        return $this->DB->get("SELECT * FROM wp_tr_cache_table WHERE name = '$fieldName'");
    }

    public function setNewDataForCache($data, $fieldName)
    {
        $this->DB->update(
            'wp_tr_cache_table',
            [
                'value' => $data,
                'updated_at' => Carbon::now()->format('Y-m-d h:i:s')
            ],
            ['name' => $fieldName]
        );
    }

    /**
     * @param $postId
     * @param $metaName
     * @return mixed
     */
    public function getCityId($postId, $metaName) {
        return get_post_meta($postId, $metaName, true);
    }
}