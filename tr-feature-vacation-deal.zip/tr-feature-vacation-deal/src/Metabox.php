<?php


namespace Tr\Feature\Vacation;


class Metabox
{
    public $view;

    public function __construct()
    {
        $this->view = new View();
    }

    public function add() {
        add_action('add_meta_boxes', array($this, 'flightIdMetaBox'));
        add_action('add_meta_boxes', array($this, 'vacationIdMetaBox'));
        add_action('add_meta_boxes', array($this, 'hotelIdMetaBox'));
        add_action('add_meta_boxes', array($this, 'vacationSearchUrlMetaBox'));
        add_action('add_meta_boxes', array($this, 'flightAirportMetaBox'));
    }

    public function save() {
        $this->saveFlightPostType();
    }

    public function flightIdMetaBox() {
        $args = array();

        add_meta_box(
            'tr_flight_city_id',
            __( 'City Name Flight ', 'City Name Flight' ),
            array($this, 'flightIdMetaBoxCallback'),
            ['flights', 'hotel', 'vacation', 'hotelflight', 'page'],
            'side',
            'high',
            $args
        );
    }

    public function vacationIdMetaBox() {
        $args = array();

        add_meta_box(
            'tr_vacation_city_id',
            __( 'City Vacation ID', 'City Vacation ID' ),
            array($this, 'vacationIdMetaBoxCallback'),
            ['flights', 'hotel', 'vacation', 'hotelflight', 'page'],
            'side',
            'high',
            $args
        );
    }

    public function hotelIdMetaBox() {
        $args = array();

        add_meta_box(
            'tr_hotel_city_id',
            __( 'City Hotel ID', 'City Hotel ID' ),
            array($this, 'hotelIdMetaBoxCallback'),
            ['flights', 'hotel', 'vacation', 'hotelflight', 'page'],
            'side',
            'high',
            $args
        );
    }

	public function vacationSearchUrlMetaBox() {
		$args = array();

		add_meta_box(
			'vacation_search_url',
			__( 'Vacation Search URL', 'Vacation Search URL' ),
			array($this, 'vacationSearchUrlMetaBoxCallback'),
			 ['vacation'],
			'normal',
			'high',
			$args
		);
	}

    public function flightAirportMetaBox() {
        $args = array();

        add_meta_box(
            'flight_airport',
            __( 'Flight Airport', 'Flight Airport' ),
            array($this, 'flightAirportMetaBoxCallback'),
            ['flights'],
            'normal',
            'high',
            $args
        );
    }

    public function flightIdMetaBoxCallback() {
        $this->view->metabox('cities_id')->render('flightId');
    }

    public function vacationIdMetaBoxCallback() {
        $this->view->metabox('cities_id')->render('vacationId');
    }

    public function hotelIdMetaBoxCallback() {
        $this->view->metabox('cities_id')->render('hotelId');
    }

	public function vacationSearchUrlMetaBoxCallback() {
		$this->view->metabox('vacation')->render('vacation-search-url');
	}

    public function flightAirportMetaBoxCallback() {
        $this->view->metabox('flight')->render('flight-metabox');
    }

    public function saveFlightPostType() {
        global $post;

        if (wp_is_post_autosave($post->ID)) {
            return;
        }

        if (wp_is_post_revision($post->ID)) {
            return;
        }

        if (!current_user_can('edit_page', $post->ID)) {
            return;
        }

        if (isset($_POST['tr_flight_post_id'])) {
            $cityId = $_POST['tr_flight_post_id'];
            update_post_meta($post->ID, 'tr_flight_id', $cityId);
        }

        if (isset($_POST['tr_vacation_post_id'])) {
            $cityId = $_POST['tr_vacation_post_id'];
            update_post_meta($post->ID, 'tr_vacation_id', $cityId);
        }

        if (isset($_POST['tr_hotel_post_id'])) {
            $cityId = $_POST['tr_hotel_post_id'];
            update_post_meta($post->ID, 'tr_hotel_id', $cityId);
        }

	    if (isset($_POST['vacation_search_url'])) {
		    $vacation_search_url = $_POST['vacation_search_url'];
		    update_post_meta($post->ID, 'vacation_search_url', $vacation_search_url);
	    }
	    if (isset($_POST['vacation_search_title'])) {
            $vacation_search_title = $_POST['vacation_search_title'];
            update_post_meta($post->ID, 'vacation_search_title', $vacation_search_title);
        }
        if (isset($_POST['vacation_search_description'])) {
            $vacation_search_description = $_POST['vacation_search_description'];
            update_post_meta($post->ID, 'vacation_search_description', $vacation_search_description);
        }

        if (isset($_POST['flight_departure_airport'])) {
            $flight_departure_airport = $_POST['flight_departure_airport'];
            update_post_meta($post->ID, 'flight_departure_airport', $flight_departure_airport);
        }
        if (isset($_POST['flight_arrival_airport'])) {
            $flight_arrival_airport = $_POST['flight_arrival_airport'];
            update_post_meta($post->ID, 'flight_arrival_airport', $flight_arrival_airport);
        }

    }
}