<section class="ts-section-slider ts-py">
    <div class="ts-container ts-slider" >
        <div class="owl-carousel owl-theme">
            <?php foreach ($destinations as $destination): ?>
            <div class="item">
                <div class="ts-slider-box">
                    <div class="ts-slider-box-part1">
                        <div class="ts-part1-segment1">
                            <div>
                                <span class="ts-segment1-from"><?php echo $destination->city ?> to</span>
                                <span class="ts-segment1-to"><?php echo $this->getCurrentFormatOfCityName() ?></span>
                            </div>
                            <div>
                                    <img class="ts-segment1-img" style="width: 38px" src="https://image.flaticon.com/icons/svg/214/214338.svg">
                            </div>
                        </div>
                        <div class="ts-part1-segment2">
                            <?php echo $this->getCurrentDate($destination->departureDate_DaysFromNow, 'M d,Y') ?> -
                            <?php echo $this->getCurrentDate($destination->returnDate_DaysFromNow, 'M d,Y') ?>
                        </div>
                    </div>
                    <div class="ts-slider-box-part2">
                        <div class="ts-part2-price"> $ <?php echo $destination->price ?></div>
                        <div class="ts-part2-type">Round Trip</div>
                        <a class="ts-part2-book">Book Now</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
    jQuery('.owl-carousel').owlCarousel({
        loop: true,
        margin: 30,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3
            }
        }
    });
</script>
