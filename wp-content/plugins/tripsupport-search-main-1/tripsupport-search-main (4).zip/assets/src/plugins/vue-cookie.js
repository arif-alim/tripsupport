import Vue from 'vue';
import VueCookie from 'vue-cookie';

// Tell Vue to use the plugin
Vue.use(VueCookie);
