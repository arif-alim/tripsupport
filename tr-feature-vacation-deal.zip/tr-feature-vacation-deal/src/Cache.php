<?php


namespace Tr\Feature\Vacation;


use Phpfastcache\Exceptions\PhpfastcacheSimpleCacheException;
use Phpfastcache\Helper\Psr16Adapter;
use Psr\Cache\InvalidArgumentException;

class Cache
{
    const DRIVER = 'Files';
    public $cache;

    public function __construct()
    {
        $this->cache = new Psr16Adapter(self::DRIVER);
    }

    /**
     * @param $data
     * @param $name
     * @param int $ttl
     * @return mixed|null
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function set($data, $name, $ttl = 10000)
    {
       return $this->cache->set($name, $data, $ttl);
    }

    public function get($name)
    {
        return $this->cache->get($name);
    }

    public function delete($name)
    {
        $this->cache->delete($name);
    }

    public function clear() {
        $this->cache->clear();
    }
}