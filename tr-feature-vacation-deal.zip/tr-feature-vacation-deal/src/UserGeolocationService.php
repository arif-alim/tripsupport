<?php


namespace Tr\Feature\Vacation;


class UserGeolocationService
{
    const API_KEY = 'bf7a5adabaf9481296f66058b96fa055';

    /**
     * @return mixed
     */
    public function get()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $this->userGeolocationFromIp($ip);
    }

    /**
     * @param $ip
     * @return mixed
     */
    private function userGeolocationFromIp($ip)
    {
        return wp_remote_get('https://api.ipgeolocation.io/ipgeo?apiKey=' . self::API_KEY . '&ip=' . $ip)['body'];
    }
}