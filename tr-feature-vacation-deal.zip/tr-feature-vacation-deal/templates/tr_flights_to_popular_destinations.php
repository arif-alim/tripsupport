<div class="tr-flights-to-popular-destinations-main-container p-2 p-md-5">
    <div class="col-12 row p-0 d-none d-sm-flex">
        <div class="col-8">
            <p class="m-0 tr-flights-to-popular-destinations-main-title">Flights to popular destinations under our
                wing</p>
        </div>
        <div class="col-4 pt-3">
            <span class="float-right tr-flight-to-popular-destinations-view-all">View all featured deals
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11.7818 6.57222L7.11497 11.6747C6.72887 12.0639 6.10977 12.101 5.70337 11.8014C5.297 11.5018 5.23004 10.8963 5.56284 10.5304L8.88583 6.9005H1.00003C0.447733 6.9005 0 6.49737 0 6.00009C0 5.50278 0.447733 5.09965 1.00003 5.09965H8.88583L5.56284 1.46976C5.23004 1.10391 5.30494 0.506855 5.70337 0.198756C6.11424 -0.118977 6.78227 -0.0404836 7.11497 0.325453L11.7818 5.42792C12.0856 5.81255 12.0596 6.20028 11.7818 6.57222Z"
                          fill="#ED1B2E"/>
                </svg>
            </span>
        </div>
    </div>
    <div class="col-12 p-0 d-block d-sm-none">
        <p style="font-size: 20px" class="m-0 tr-flights-to-popular-destinations-main-title">Flights to popular
            destinations under our
            wing</p>
    </div>
    <p class="m-0 tr-flights-to-popular-destinations-second-title pt-2 pb-2">Whether it's a last minute getaway or a
        planned
        family
        holiday, we've got cheap flights to take you to your dream destination at a <br> price that won't break the
        bank. </p>

    <div class="swiper-container tr_flights-to-popular-destinations-btns-container pt-2 pb-2">
        <div class="swiper-wrapper">
            <span id="canada" class="swiper-slide tr-flights-to-popular-destinations-btn tr-flights-to-popular-destinations-btn-active">Canada</span>
            <span id="europe" class="swiper-slide tr-flights-to-popular-destinations-btn">Europe</span>
            <span id="asia" class="swiper-slide tr-flights-to-popular-destinations-btn">Asia</span>
            <span id="united states" class="swiper-slide tr-flights-to-popular-destinations-btn">United States</span>
           <!-- <span id="Caribbean" class="swiper-slide tr-flights-to-popular-destinations-btn">Caribbean</span>
            <span id="mexico" class="swiper-slide tr-flights-to-popular-destinations-btn">Mexico</span>
            <span id="cuba" class="swiper-slide tr-flights-to-popular-destinations-btn">Cuba</span>
          -->
            <div class="spinner-border d-none" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
    <div class="col-md-12 row p-0 m-0">

        <?php

        if ($destinations != null):
            $counter = 1;
            foreach ($destinations as $destination): ?>
                <?php if ($counter <= 24): ?>
                    <div class="col-6 col-md-2 tr-flight-to-popular-destination-each-section p-1 <?php if ($counter > 12) {
                        echo 'd-none';
                    } ?>">
                        <?php $domain=$_SERVER['SERVER_NAME'] ?>
                        <?php if ($domain == 'tripsupport.ca') { ?>
                        <a href="https://secure.tripsupport.ca/flight/roundtrip;<?php echo $destination->searchLink ?>"
                        <?php } else if($domain == 'tripsupport.com') { ?>
                            <a href="https://secure.tripsupport.com/flight/roundtrip;<?php echo $destination->searchLink ?>"
                        <?php } ?>
                           target="_blank" style="text-decoration: none">
                            <div class="col-12 p-0 m-0 tr-flight-to-popular-destination-each-container p-2 pt-3">
                                <img src="https://secure.tripsupport.com/assets/AirlineLogos/<?php echo $destination->airlineLogo ?>"
                                     style="height: 25px">
                                <p class="m-0 pt-2 tr-flight-to-popular-destination-each-main-text">
                                    <?php echo $destination->departureCityFriendlyName ?>
                                    (<?php echo $destination->departureAirportCode ?>)
                                    to</p>
                                <p class="m-0 mb-4 tr-flight-to-popular-destination-each-main-text">
                                    <?php echo $destination->arrivalCityFriendlyName ?>
                                    (<?php echo $destination->arrivalAirportCode ?>)</p>
                                <p class="m-0 tr-flight-to-popular-destination-each-price">CA
                                    $<?php echo substr($destination->price, 0, strpos($destination->price, ".")) ?></p>
                                <p class="m-0 tr-flight-to-popular-destination-each-date">
                                    <?php echo $destination->departureDate ?>
                                    –
                                    <?php echo $destination->returnDate ?>
                                </p>
                                <p class="m-0 tr-flight-to-popular-destination-each-info">Round-trip + taxes and
                                    fees</p>
                            </div>
                        </a>
                    </div>
                    <?php $counter++ ?>
                <?php endif ?>
            <?php endforeach; ?>
        <?php else: ?>
            <?php echo "no destination found from {$cityName} \n" ?>
        <?php endif; ?>

    </div>
    <div class="d-none d-sm-flex swiper-button-prev swiper-button-prev-flight-to-popular-destination ">
        <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0.861978 8.68671L6.46214 14.8097C6.92546 15.2767 7.66838 15.3213 8.15605 14.9617C8.64369 14.6022 8.72405 13.8756 8.32469 13.4365L4.3371 9.08065H16.2001C16.8628 9.08065 17.4001 8.59689 17.4001 8.00015C17.4001 7.40338 16.8628 6.91963 16.2001 6.91963H4.3371L8.32469 2.56376C8.72405 2.12474 8.63418 1.40827 8.15605 1.03856C7.66302 0.657276 6.86138 0.751468 6.46214 1.19059L0.861978 7.31355C0.497418 7.77511 0.528538 8.24038 0.861978 8.68671Z"
                  fill="#66678F"/>
        </svg>
    </div>
    <div class="d-none d-sm-flex swiper-button-next swiper-button-next-flight-to-popular-destination">
        <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M17.138 8.68671L11.5379 14.8097C11.0745 15.2767 10.3316 15.3213 9.84395 14.9617C9.35631 14.6022 9.27595 13.8756 9.67531 13.4365L13.6629 9.08065H1.79994C1.13718 9.08065 0.599899 8.59689 0.599899 8.00015C0.599899 7.40338 1.13718 6.91963 1.79994 6.91963H13.6629L9.67531 2.56376C9.27595 2.12474 9.36582 1.40827 9.84395 1.03856C10.337 0.657276 11.1386 0.751468 11.5379 1.19059L17.138 7.31355C17.5026 7.77511 17.4715 8.24038 17.138 8.68671Z"
                  fill="#66678F"/>
        </svg>
    </div>
    <div class="text-center d-block d-sm-none pt-3 pb-3">
        <span class="tr-flight-to-popular-destinations-view-all-mobile">View all featured deals
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M11.7818 6.57222L7.11497 11.6747C6.72887 12.0639 6.10977 12.101 5.70337 11.8014C5.297 11.5018 5.23004 10.8963 5.56284 10.5304L8.88583 6.9005H1.00003C0.447733 6.9005 0 6.49737 0 6.00009C0 5.50278 0.447733 5.09965 1.00003 5.09965H8.88583L5.56284 1.46976C5.23004 1.10391 5.30494 0.506855 5.70337 0.198756C6.11424 -0.118977 6.78227 -0.0404836 7.11497 0.325453L11.7818 5.42792C12.0856 5.81255 12.0596 6.20028 11.7818 6.57222Z"
                      fill="#ED1B2E"/>
            </svg>
        </span>
    </div>
</div>

<style>
    .swiper-button-prev-flight-to-popular-destination {
        background-color: white;
        color: #0C0D25 !important;
        border-radius: 100%;
        box-shadow: 0px 5px 5px rgba(102, 103, 143, 0.04);
        margin-left: -30px;
        margin-top: 60px;
        width: 40px;
        height: 40px;
        border: 1px solid rgba(102, 103, 143, 0.1);
    }

    .swiper-button-next-flight-to-popular-destination {
        background-color: white;
        color: #0C0D25 !important;
        border-radius: 100%;
        box-shadow: 0px 5px 5px rgba(102, 103, 143, 0.04);
        margin-right: -30px;
        margin-top: 60px;
        width: 40px;
        height: 40px;
        border: 1px solid rgba(102, 103, 143, 0.1);
    }

    .swiper-button-next-flight-to-popular-destination::after {
        font-size: 10px !important;
        font-weight: bold;
        color: #66678F !important;
        display: none !important;
    }

    .swiper-button-prev-flight-to-popular-destination::after {
        font-size: 10px !important;
        font-weight: bold;
        color: #66678F !important;
        display: none !important;
    }

    .swiper-button-next, .swiper-container-rtl .swiper-button-prev ,.swiper-button-prev, .swiper-container-rtl .swiper-button-next {background-image:unset}

    .tr-flights-to-popular-destinations-main-container {
        background-image: linear-gradient(to bottom left, #fef6f6, #e7f3ff, #e7f3ff);
    }

    .tr-flights-to-popular-destinations-main-title {
        color: #0C0D25;
        font-size: 26px;
        font-weight: 700;
        line-height: 26px;
        font-family: "Cera PRO";
    }

    .tr-flights-to-popular-destinations-second-title {
        color: #66678F;
        font-size: 16px;
        font-family: "Cera PRO";
    }

    .tr-flight-to-popular-destination-each-container {
        border: 1px solid rgba(102, 103, 143, 0.1);
        box-shadow: 0px 2px 2px rgba(102, 103, 143, 0.04);
        border-radius: 8px;
        color: #0C0D25;
        background-color: white;
        transition: 200ms;
    }

    .tr-flight-to-popular-destination-each-price {
        font-style: normal;
        font-weight: 700;
        font-size: 20px;
        line-height: 25px;
        color: #0C0D25;
        font-family: "Cera PRO";
    }

    .tr-flight-to-popular-destination-each-main-text {
        color: #0C0D25;
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: normal;
        font-size: 1rem;
        line-height: 22px;
        letter-spacing: -0.02em;
    }

    .tr-flight-to-popular-destination-each-date {
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: 600;
        font-size: 0.8rem;
        line-height: 17px;
        color: #0C0D25;
    }

    .tr-flight-to-popular-destination-each-info {
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 15px;
        color: #66678F;
    }

    .tr-flights-to-popular-destinations-btn-active {
        background: #66678F !important;
        border-radius: 18px !important;
        padding-left: 10px !important;
        padding-right: 10px !important;
        color: #fff !important;
        cursor: pointer;
    }

    .tr-flights-to-popular-destinations-btn {
        background-color: #e8e8ef;
        border-radius: 18px;
        color: #66678F;
        padding-left: 5px;
        padding-right: 5px;
        width: auto !important;
        cursor: pointer;
    }

    .tr-flight-to-popular-destinations-view-all-mobile {
        color: #ED1B2E;
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 100%;
        letter-spacing: -0.02em;
        font-family: "Cera PRO";
    }

    .tr-flight-to-popular-destinations-view-all {
        color: #ED1B2E;
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 100%;
        letter-spacing: -0.02em;
        font-family: "Cera PRO";
        position: absolute;
        top: -10px;
        right: 0px;
    }

    .spinner-border {
        width: 1rem;
        height: 1rem;
        color: #66678F
    }

    .tr-flight-to-popular-destination-each-container:hover {
        box-shadow: 0px 18px 42px rgba(102, 103, 143, 0.24);
    }
</style>

<script>
    var city = 'london';
    var flightToDestinationsContainers = document.querySelectorAll('.tr-flight-to-popular-destination-each-container');
    console.log(city);
    var allSpinners = document.querySelectorAll('.spinner-border');
    var popularDestinationsBtns = document.querySelectorAll('.tr-flights-to-popular-destinations-btn');

    function formatDate(date) {
        const monthName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        //if (month.length < 2)
        // month = '0' + month;
        //if (day.length < 2)
        //  day = '0' + day;

        month = monthName[--month];

        return [month, day].join(' ');
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    popularDestinationsBtns.forEach(popularDestinationsBtn => {
        popularDestinationsBtn.addEventListener('click', () => {
            popularDestinationsBtns.forEach(removeActiveClass => {
                removeActiveClass.classList.remove('tr-flights-to-popular-destinations-btn-active');
            });
            allSpinners.forEach(spinner => {
                spinner.classList.remove('d-none');
            });
            popularDestinationsBtn.classList.add('tr-flights-to-popular-destinations-btn-active');
            city = popularDestinationsBtn.getAttribute('id');
            console.log('css : ' + city);

            jQuery(document).ready(function ($) {
                var data = {
                    'action': 'tr_flight_to_popular_destination',
                    'city': city
                };
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                jQuery.post(ajaxurl, data, function (response) {
                    receiveData = JSON.parse(response);
                    console.log(receiveData);
                    flightToDestinationsContainers.forEach((flightToDestinationsContainer, index) => {
                        if (receiveData[index] != undefined) {
                            flightToDestinationsContainer.classList.remove('d-none');
                            console.log(flightToDestinationsContainer.childNodes);
                            <?php if ($domain == 'tripsupport.ca') { ?>
                            flightToDestinationsContainer.parentNode.href = 'https://secure.tripsupport.ca/flight/roundtrip;' + receiveData[index].searchLink;
                            <?php } else if($domain == 'tripsupport.com') { ?>
                            flightToDestinationsContainer.parentNode.href = 'https://secure.tripsupport.com/flight/roundtrip;' + receiveData[index].searchLink;
                            <?php } ?>
                            flightToDestinationsContainer.childNodes[1].src = 'https://secure.tripsupport.com/assets/AirlineLogos/' + receiveData[index].airlineLogo;
                            flightToDestinationsContainer.childNodes[3].innerText = receiveData[index].departureCityFriendlyName + ' (' + receiveData[index].departureAirportCode + ') ' + ' to';
                            flightToDestinationsContainer.childNodes[5].innerText = receiveData[index].arrivalCityFriendlyName + "(" + receiveData[index].arrivalAirportCode + ")";
                            flightToDestinationsContainer.childNodes[7].innerText = "CA $" + receiveData[index].price.toString().split('.')[0];
                            flightToDestinationsContainer.childNodes[9].innerText = receiveData[index].departureDate + '-' + receiveData[index].returnDate;
                        } else {
                            flightToDestinationsContainer.classList.add('d-none');
                        }
                        allSpinners.forEach(spinner => {
                            spinner.classList.add('d-none');
                        });
                    });
                });
            });
        });
    });


    var swiperButtonPrevFlightToPopularDestination = document.querySelector('.swiper-button-prev-flight-to-popular-destination');
    var swiperButtonNextFlightToPopularDestination = document.querySelector('.swiper-button-next-flight-to-popular-destination');
    var flightToPopularDestinationMainContainers = document.querySelectorAll('.tr-flight-to-popular-destination-each-section');

    swiperButtonPrevFlightToPopularDestination.addEventListener('click', () => {
        flightToPopularDestinationMainContainers.forEach(flightToDestinationsContainer => {
            flightToDestinationsContainer.classList.toggle('d-none')
        });
    });

    swiperButtonNextFlightToPopularDestination.addEventListener('click', () => {
        flightToPopularDestinationMainContainers.forEach(flightToDestinationsContainer => {
            flightToDestinationsContainer.classList.toggle('d-none')
        });
    });

</script>

<script>
    var swiperFlightsToPopularDestinationsBtnsContainer = new Swiper('.tr_flights-to-popular-destinations-btns-container', {
        breakpoints: {
            960: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            720: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            540: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            320: {
                slidesPerView: 3,
                spaceBetween: 10
            },
        }
    });
</script>