<div class="container p-0">
    <?php $domain=$_SERVER['SERVER_NAME'] ?>
    <div class="btn-group mr-1">
        <div class="btn-group mr-1">
            <button type="button" class="btn btn-default dropdown-toggle tr-login-btn" data-toggle="dropdown">
                Login
            </button>
            <div class="dropdown-menu tr-login-dropdown p-3" style="margin-right:10rem" role="menu">
                <p class="text-center tr-register-login-form-title">Login</p>
                <label class="tr-register-login-form-label">Email Address</label>
                <input type="email" placeholder="Enter Email Address"
                       style="direction:ltr"
                       class="form-control tr-register-login-form-input tr-login-user-email p-3 mb-3">
                <label class="tr-register-login-form-label">Password</label>
                <input type="password" placeholder="*********"
                       style="direction:ltr"
                       class="form-control tr-login-user-password tr-register-login-form-input p-3 mb-3">
                <button class="btn btn-block tr-register-login-form-btn" id="tr-login-action-btn">Login</button>
                <hr>
                <a class="tr-register-login-form-forgot-link" id="tr-forgot-password">forgot password</a>
            </div>
        </div>

        <div class="btn-group mr-1">
            <button type="button" class="btn btn-default dropdown-toggle tr-register-btn" data-toggle="dropdown">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 0C6.41775 0 4.87103 0.469192 3.55544 1.34824C2.23985 2.22729 1.21447 3.47672 0.608967 4.93853C0.00346629 6.40034 -0.15496 8.00887 0.153721 9.56072C0.462403 11.1126 1.22433 12.538 2.34315 13.6569C3.46197 14.7757 4.88743 15.5376 6.43928 15.8463C7.99113 16.155 9.59966 15.9965 11.0615 15.391C12.5233 14.7855 13.7727 13.7602 14.6518 12.4446C15.5308 11.129 16 9.58225 16 8C15.9978 5.87894 15.1542 3.84539 13.6544 2.34558C12.1546 0.845769 10.1211 0.00220599 8 0ZM4.66667 13.765V13.3333C4.66667 12.4493 5.01786 11.6014 5.64298 10.9763C6.2681 10.3512 7.11595 10 8 10C8.88406 10 9.7319 10.3512 10.357 10.9763C10.9821 11.6014 11.3333 12.4493 11.3333 13.3333V13.765C10.3217 14.3556 9.17138 14.6668 8 14.6668C6.82863 14.6668 5.67828 14.3556 4.66667 13.765ZM6 6.66667C6 6.2711 6.1173 5.88442 6.33706 5.55553C6.55683 5.22663 6.86918 4.97028 7.23464 4.81891C7.60009 4.66753 8.00222 4.62792 8.39018 4.7051C8.77814 4.78227 9.13451 4.97275 9.41422 5.25245C9.69392 5.53216 9.8844 5.88852 9.96157 6.27648C10.0387 6.66445 9.99914 7.06658 9.84776 7.43203C9.69639 7.79748 9.44004 8.10984 9.11114 8.3296C8.78224 8.54937 8.39557 8.66667 8 8.66667C7.46957 8.66667 6.96086 8.45595 6.58579 8.08088C6.21072 7.70581 6 7.1971 6 6.66667ZM12.6317 12.785C12.5417 12.0295 12.2685 11.3075 11.8356 10.6817C11.4028 10.056 10.8236 9.54562 10.1483 9.195C10.6709 8.75453 11.0454 8.16408 11.2212 7.50364C11.397 6.84321 11.3655 6.1447 11.131 5.50275C10.8966 4.8608 10.4704 4.30643 9.9104 3.91474C9.35034 3.52306 8.68343 3.31299 8 3.31299C7.31657 3.31299 6.64966 3.52306 6.08961 3.91474C5.52956 4.30643 5.10344 4.8608 4.86897 5.50275C4.63451 6.1447 4.60303 6.84321 4.77881 7.50364C4.95458 8.16408 5.32912 8.75453 5.85167 9.195C5.17645 9.54562 4.5972 10.056 4.16437 10.6817C3.73154 11.3075 3.45826 12.0295 3.36834 12.785C2.4129 11.8621 1.75495 10.6748 1.47889 9.37545C1.20283 8.07607 1.32124 6.72384 1.81894 5.49222C2.31664 4.2606 3.17093 3.20574 4.27223 2.46295C5.37353 1.72017 6.67162 1.32332 8 1.32332C9.32838 1.32332 10.6265 1.72017 11.7278 2.46295C12.8291 3.20574 13.6834 4.2606 14.1811 5.49222C14.6788 6.72384 14.7972 8.07607 14.5211 9.37545C14.2451 10.6748 13.5871 11.8621 12.6317 12.785Z"
                          fill="white"/>
                </svg>
                Register
            </button>
            <div class="dropdown-menu tr-register-dropdown p-3" style="margin-right:10rem" role="menu">
                <p class="text-center tr-register-login-form-title">Create Account</p>
                <label class="tr-register-login-form-label">First Name</label>
                <input type="email" placeholder="Enter First Name"
                       style="direction:ltr"
                       class="form-control tr-register-login-form-input tr-create-new-account-fr-name p-3 mb-3">
                <label class="tr-register-login-form-label">Last Name</label>
                <input type="email" placeholder="Enter Last Name"
                       style="direction:ltr"
                       class="form-control tr-register-login-form-input tr-create-new-account-ln-name p-3 mb-3">
                <label class="tr-register-login-form-label">Email Address</label>
                <input type="email" placeholder="Enter Email Address"
                       style="direction:ltr"
                       class="form-control tr-register-login-form-input tr-create-new-account-email p-3 mb-3">
                <label class="tr-register-login-form-label">Password</label>
                <input type="password" placeholder="*******"
                       style="direction: ltr"
                       class="form-control tr-register-login-form-input p-3 mb-3 tr-create-new-account-password">
                <button class="btn btn-block tr-register-login-form-btn" id="tr-create-account-btn">Create Account
                </button>
                <hr>
                <span>Already have an account?</span>
                <a class="tr-register-login-form-forgot-link" id="tr-already-have-account">Sign In</a>
            </div>
        </div>

        <div class="btn-group mr-1">
            <button type="button" class="btn btn-default dropdown-toggle tr-profile-btn" data-toggle="dropdown">
                john doe
            </button>
            <div class="dropdown-menu tr-login-dropdown p-3" style="margin-right:10rem" role="menu">
                <a href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/user/bookings' : 'https://secure.tripsupport.com/user/bookings'; ?>">My bookings</a><br>
                <a href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/user/profile' : 'https://secure.tripsupport.com/user/profile'; ?>">My profile</a><br>
                <a href="javascript:void(0);" class="tr-logout-btn">Logout</a><br>
            </div>
        </div>

        <div class="btn-group mr-1">
            <button type="button" class="btn btn-default dropdown-toggle tr-forgot-btn bg-white" style="cursor: context-menu;"
                    data-toggle="dropdown">

            </button>
            <div class="dropdown-menu tr-login-dropdown p-3" style="margin-right:10rem" role="menu">
                <p class="text-center tr-register-login-form-title">Forgot Password</p>
                <label class="tr-register-login-form-label">Email Address</label>
                <input type="email" placeholder="Enter Email Address"
                       style="direction:ltr"
                       class="form-control tr-register-login-form-input tr-reset-user-email p-3 mb-3">
                <button class="btn btn-block tr-register-login-form-btn" id="tr-rest-password-btn">Reset Password
                </button>
                <hr>
            </div>
        </div>
    </div>

</div>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script !src="">



    const loginBaseUrl = 'https://myprofileapi.tripsupport.com/api/myprofile/userlogindetails';
    const registerBaseUrl = 'https://myprofileapi.tripsupport.com/api/myprofile/userregistration';
    const resetPasswordBaseUrl = 'https://myprofileapi.tripsupport.com/api/myprofile/forgotpassword?Email=';

    var trAlreadyHaveAccount = document.getElementById('tr-already-have-account');

    var trLoginBtn = document.querySelector('.tr-login-btn');
    var trRegisterBtn = document.querySelector('.tr-register-btn');
    var trProfileBtn = document.querySelector('.tr-profile-btn');
    var trLogoutProfile = document.querySelector('.tr-logout-btn');
    var trLoginActionBtn = document.getElementById('tr-login-action-btn');

    var trBtnCreateAccount = document.getElementById('tr-create-account-btn');

    // Create new  account params
    var newAccountFirstName = document.querySelector('.tr-create-new-account-fr-name');
    var newAccountLastName = document.querySelector('.tr-create-new-account-ln-name');
    var newAccountEmail = document.querySelector('.tr-create-new-account-email');
    var newAccountPassword = document.querySelector('.tr-create-new-account-password');

    checkUserStorageStatus();
    // Check user set in localstorage
    function checkUserStorageStatus() {
        if (localStorage.getItem('user') == null) {
            trLoginBtn.classList.remove('d-none');
            trRegisterBtn.classList.remove('d-none');
            trProfileBtn.classList.add('d-none');
        } else {
            var data = JSON.parse(localStorage.getItem('user'));
            var name =((data.result == null) ? data.firstname : data.result.firstname);
            trLoginBtn.classList.add('d-none');
            trRegisterBtn.classList.add('d-none');
            trProfileBtn.innerText= 'Welcome ' + name;
            trProfileBtn.classList.remove('d-none');
        }
    }

    // Logout btn action
    trLogoutProfile.addEventListener('click', () => {
        console.log('trLogoutProfile');
        localStorage.removeItem('user');
        checkUserStorageStatus();
        swal("Message", "You are logged out", "success");

    });

    // Create new account send request
    trBtnCreateAccount.addEventListener('click', () => {
        jQuery.ajax({
            url: registerBaseUrl,
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                email: newAccountEmail.value,
                password: newAccountPassword.value,
                firstname: newAccountFirstName.value,
                lastname: newAccountLastName.value
            }),
            success: function (res) {
                // set localstorage if new account created successfully
                if (res.message == 'registration successful') {
                    createdUserData = {
                        email: newAccountEmail.value,
                        password: newAccountPassword.value,
                        firstname: newAccountFirstName.value,
                        lastname: newAccountLastName.value
                    };
                    localStorage.setItem('user', JSON.stringify(createdUserData));
                    checkUserStorageStatus();
                    swal("Message",  "New account created, you are logged in successfully", "success");

                }
                else{
                    swal("Error",  res.message, "error");
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    });

    // Login params
    var loginUserPassword = document.querySelector('.tr-login-user-password');
    var loginUserEmail = document.querySelector('.tr-login-user-email');

    // login request process
    trLoginActionBtn.addEventListener('click', () => {
        jQuery.ajax({
            url: loginBaseUrl,
            type: 'POST',
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({
                email: loginUserEmail.value,
                password: loginUserPassword.value
            }),
            success: function (res) {
                if (res.hasResult == false) {
                    swal("Error", res.errorDetails.errorMsg , "error");
                }

                if (res.hasResult == true) {
                    localStorage.setItem('user', JSON.stringify(res));
                    checkUserStorageStatus();
                    swal("Message", "You are logged in successfully" , "success");

                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    });

    trAlreadyHaveAccount.addEventListener('click', () => {
        setTimeout(() => {
            trLoginBtn.click();
        }, 10)
    });


    //forgot password btns
    var trForgotBtn = document.querySelector('.tr-forgot-btn');
    var registerFormForgotPassword = document.querySelector('#tr-forgot-password');
    var resetPasswordBtn = document.querySelector('#tr-rest-password-btn');
    var resetUserEmail = document.querySelector('.tr-reset-user-email');

    registerFormForgotPassword.addEventListener('click', () => {
        setTimeout(() => {
            trForgotBtn.click();
        }, 10)
    });

    resetPasswordBtn.addEventListener('click', () => {
        jQuery.ajax({
            url: resetPasswordBaseUrl + resetUserEmail.value,
            type: 'GET',
            dataType: "json",
            contentType: "application/json",
            success: function (res) {
                console.log(res);
                swal("Message", "Reset password email sent" , "info");

            },
            error: function (err) {
                console.log(err);
            }
        });
    })
</script>

<style>
    .tr-forgot-btn::after {
        display: none;
    }

    .tr-register-login-form-forgot-link {
        color: #007AFF !important;
    }

    .tr-register-login-form-btn {
        background-color: #ED1B2E !important;
        font-family: "Cera PRO";
        color: #fff;
    }

    .tr-register-login-form-btn:hover {
        background-color: #ED2D3A !important;
        color: #fff;
    }

    .tr-register-login-form-label {
        color: #66678F;
        font-size: 14px;
        font-family: "Cera PRO";
    }

    .tr-register-login-form-input:focus {
        box-shadow: none !important;
    }

    .tr-register-login-form-input::placeholder {
        color: #ABABC4 !important;
    }

    .tr-register-login-form-input {
        background-color: #fff !important;
        border: 0.5px solid lightgray !important;
    }

    .tr-register-login-form-title {
        color: #0C0D25;
        font-family: "Cera PRO";
        font-size: 18px;
        font-weight: 600;
    }

    .tr-login-btn, .tr-register-btn {
        background-color: #fff;
        color: #66678F;
        font-family: "Cera PRO";
    }

    .tr-login-btn::after, .tr-register-btn::after {
        display: none !important;
    }

    .tr-login-dropdown, .tr-register-dropdown {
        width: 20rem !important;
        border-radius: 8px !important;
        border: none !important;
        box-shadow: 0 0 5px lightgray;
        z-index: 1000000;
    }

    .tr-register-btn {
        background-color: #ED1B2E !important;
        color: white !important;
        border-radius: 4px !important;
    }
</style>