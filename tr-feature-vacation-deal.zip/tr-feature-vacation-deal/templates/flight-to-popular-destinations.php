<p class="mb-2 tr-flight-to-popular-destination-main-title">Our Best Flight Deals for the Day</p>
<p class="tr-flight-to-popular-destination-side-title">We're focused on making travel better for everyone. Find the
    right flight and book with confidence.</p>
<div class="row col-md-12 mb-3">
    <div class="swiper-container tr-flight-to-popular-destination-items-swiper">
        <div class="swiper-wrapper">
            <span id="canada"
                  class="swiper-slide tr-flight-to-popular-destination-btns
                  <?php if ($cityName == 'canada') {echo 'tr-flight-to-popular-destination-btns-active';} ?>">Canada</span>
            <span id="europe" class="swiper-slide tr-flight-to-popular-destination-btns
                   <?php if ($cityName == 'europe') {echo 'tr-flight-to-popular-destination-btns-active';} ?>">Europe</span>
            <span id="asia" class="swiper-slide tr-flight-to-popular-destination-btns
                   <?php if ($cityName == 'asia') {echo 'tr-flight-to-popular-destination-btns-active';} ?>">Asia</span>
            <span id="united-states" class="swiper-slide tr-flight-to-popular-destination-btns
                   <?php if ($cityName == 'united-states') {echo 'tr-flight-to-popular-destination-btns-active';} ?>">United States</span>
            <span id="caribbean" class="swiper-slide tr-flight-to-popular-destination-btns
                   <?php if ($cityName == 'caribbean') {echo 'tr-flight-to-popular-destination-btns-active';} ?>">Caribbean</span>
            <span id="mexico" class="swiper-slide tr-flight-to-popular-destination-btns
                    <?php if ($cityName == 'mexico') {echo 'tr-flight-to-popular-destination-btns-active';} ?>">Mexico</span>
            <span id="cuba" class="swiper-slide tr-flight-to-popular-destination-btns
                    <?php if ($cityName == 'cuba') {echo 'tr-flight-to-popular-destination-btns-active';} ?>">Cuba</span>
            <div class="spinner-border tr-flight-landing-spinner d-none" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12 row p-0 m-0">

    <?php
     $count=0;
    if ($destinations != null):
        foreach ($destinations as $destination): ?>
            <div class="col-6 col-md-2 tr-flight-to-popular-destination-each-section p-2">
                <a href="https://secure.tripsupport.com/flight/roundtrip;<?php echo $destination->searchLink ?>"
                   target="_blank" style="text-decoration: none">
                    <div class="col-12 p-0 m-0 tr-flight-to-popular-destination-each-container p-2 pt-3 pb-3">
                        <img src="https://secure.tripsupport.com/assets/AirlineLogos/<?php echo $destination->airlineLogo ?>"
                             style="height: 25px">
                        <p class="m-0 tr-flight-to-popular-destination-each-main-text">
                            <?php echo $destination->departureCityFriendlyName ?>
                            (<?php echo $destination->departureAirportCode ?>)
                            to
                        </p>
                        <p class="m-0 mb-5 tr-flight-to-popular-destination-each-main-text">
                            <?php echo $destination->arrivalCityFriendlyName ?>
                            (<?php echo $destination->arrivalAirportCode ?>)
                        </p>
                        <p class="m-0 tr-flight-to-popular-destination-each-price">CA $
                            <?php echo substr($destination->price, 0, strpos($destination->price, ".")) ?></p>
                        <p class="m-0 tr-flight-to-popular-destination-each-date">
                            <?php echo $destination->departureDate ?>
                            –
                            <?php echo $destination->returnDate ?>
                        </p>
                        <p class="m-0 tr-flight-to-popular-destination-each-info">Round-trip + taxes and fees</p>
                    </div>
                </a>
            </div>
        <?php $count++; if($count==18) break; endforeach; ?>
    <?php else: ?>
        <?php echo "no destination found from {$cityName} \n" ?>
    <?php endif; ?>

</div>

<style>
    .spinner-border {
        width: 1rem;
        height: 1rem;
        color: #66678F;
    }
    .tr-flight-to-popular-destination-main-title {
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: normal;
        font-size: 26px;
        line-height: 100%;
        color: #0C0D25;
        letter-spacing: -0.02em;
    }

    .tr-flight-to-popular-destination-btns {
        background: rgba(102, 103, 143, 0.1);
        border-radius: 18px;
        padding-left: 10px;
        padding-right: 10px;
        color: #66678F !important;
        cursor: pointer;
        font-family: "Cera PRO";
    }

    .tr-flight-to-popular-destination-btns-active {
        background: #66678F !important;
        border-radius: 18px !important;
        padding-left: 10px !important;
        padding-right: 10px !important;
        color: #fff !important;
        cursor: pointer;
    }

    .tr-flight-to-popular-destination-side-title {
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 26px;
        /* identical to box height, or 162% */

        letter-spacing: -0.01em;

        /* Secondary - Main */

        color: #66678F;
    }

    .tr-flight-to-popular-destination-each-container {
        border: 1px solid rgba(102, 103, 143, 0.1);
        box-shadow: 0px 2px 2px rgba(102, 103, 143, 0.04);
        border-radius: 8px;
        color: #0C0D25;
        transition: 200ms;
    }

    .tr-flight-to-popular-destination-each-price {
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: bold;
        font-size: 20px;
        line-height: 25px;
        color: #0C0D25;
    }

    .tr-flight-to-popular-destination-each-main-text {
        color: #0C0D25;
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 22px;
        letter-spacing: -0.02em;
    }

    .tr-flight-to-popular-destination-each-date {
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: normal;
        font-size: 14px;
        line-height: 17px;
        color: #0C0D25;
    }

    .tr-flight-to-popular-destination-each-info {
        font-family: "Cera PRO";
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 15px;
        color: #66678F;
    }

    .swiper-container-pointer-events {
        margin: 0px !important;
    }

    .swiper-slide {
        width: auto !important;
    }

    .tr-flight-to-popular-destination-each-container:hover {
        box-shadow: 0px 18px 42px rgba(102, 103, 143, 0.24);
    }
    .swiper-button-next, .swiper-container-rtl .swiper-button-prev ,.swiper-button-prev, .swiper-container-rtl .swiper-button-next {background-image:unset}

</style>

<script type="module">
    var swiper = new Swiper('.tr-flight-to-popular-destination-items-swiper', {
        breakpoints: {
            960: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            720: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            540: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            320: {
                slidesPerView: 3,
                spaceBetween: 10
            },
        }
    });
</script>

<script !src="">
    var cityForPopularDestinationsName = 'london';
    var trPopularDestinationSelector = document.querySelectorAll('.tr-flight-to-popular-destination-btns');
    var flightToDestinationsContainersLanding = document.querySelectorAll('.tr-flight-to-popular-destination-each-container');
    var allSpinners = document.querySelector('.tr-flight-landing-spinner');

    function formatDate(date) {
        const monthName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        //if (month.length < 2)
        // month = '0' + month;
        //if (day.length < 2)
        //  day = '0' + day;

        month = monthName[--month];

        return [month, day].join(' ');
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    trPopularDestinationSelector.forEach(destinationSelector => {
        destinationSelector.addEventListener('click', () => {
            trPopularDestinationSelector.forEach(eachDestinationSelector => {
                eachDestinationSelector.classList.remove('tr-flight-to-popular-destination-btns-active');
            });
            destinationSelector.classList.add('tr-flight-to-popular-destination-btns-active');
            cityForPopularDestinationsName = destinationSelector.getAttribute('id');
            allSpinners.classList.remove('d-none');
            jQuery(document).ready(function ($) {
                var data = {
                    'action': 'tr_flight_to_popular_destination_landing',
                    'city': cityForPopularDestinationsName
                };
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                jQuery.post(ajaxurl, data, function (response) {
                    var receiveData = JSON.parse(response);
                    flightToDestinationsContainersLanding.forEach((flightToDestinationsContainer, index) => {
                        if (receiveData[index] != undefined) {
                            flightToDestinationsContainer.classList.remove('d-none');
                            console.log(flightToDestinationsContainer.childNodes);
                            flightToDestinationsContainer.parentNode.href = 'https://secure.tripsupport.com/flight/roundtrip;' + receiveData[index].searchLink;
                            flightToDestinationsContainer.childNodes[1].src = 'https://secure.tripsupport.com/assets/AirlineLogos/' + receiveData[index].airlineLogo;
                            flightToDestinationsContainer.childNodes[3].innerText = receiveData[index].departureCityFriendlyName + ' (' + receiveData[index].departureAirportCode + ') ' + ' to';
                            flightToDestinationsContainer.childNodes[5].innerText = receiveData[index].arrivalCityFriendlyName + "(" + receiveData[index].arrivalAirportCode + ")";
                            flightToDestinationsContainer.childNodes[7].innerText = "CA $" + receiveData[index].price.toString().split('.')[0];
                            flightToDestinationsContainer.childNodes[9].innerText = receiveData[index].departureDate + '-' + receiveData[index].returnDate;
                        } else {
                            flightToDestinationsContainer.classList.add('d-none');
                        }
                        allSpinners.classList.add('d-none');
                    });
                });
            });
        });
    });
</script>