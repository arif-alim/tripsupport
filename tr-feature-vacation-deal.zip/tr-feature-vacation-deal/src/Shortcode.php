<?php

namespace Tr\Feature\Vacation;

use Automattic\WooCommerce\Proxies\LegacyProxy;
use Carbon\Carbon;
use Phpfastcache\Exceptions\PhpfastcacheSimpleCacheException;
use PHPMailer\PHPMailer\Exception;
use Psr\Cache\InvalidArgumentException;

class Shortcode
{
    const LOGIN_FORM_TEMPLATE_NOT_FOUND_MESSAGE = 'requested login form template not found';
    const LANDING_PAGE_BASE_UR = 'https://myprofileapi.tripsupport.com/api/admin/getlandingpage';
    const FEATURE_VACATION_BASE_URL = 'https://vacationapi.tripsupport.ca/api/Vacation/FullSearch';

    const ZONE = [
        'Mexico' => [
            [1, 'Acapulco'], [2, 'Cancun'], [77, 'Los Cabos'], [9, 'Puerto Vallarta'], [24, 'Riviera Maya']
        ],
        'Cuba' => [
            [92, 'Cayo Coco'], [3, 'Cayo Largo'], [47, 'Havana'], [6, 'Holguin'], [15, 'Varadero']
        ],
        'Dominican Republic' => [
            [73, 'La Romana'], [8, 'Puerto Plata'], [10, 'Punta Cana'], [40, 'Samana'], [14, 'Santo Domingo']
        ],
        'Jamaica' => [
            [1341882, 'Whitehouse'], [18, 'Montego Bay'], [4244, 'Negril'], [1843, 'Ocho Rios'], [1341400, 'Runaway Bay']
        ],
        'Caribbean' => [
            [62, 'Turks And Caicos'], [29, 'Aruba'], [27, 'Antigua'], [25, 'Nassau'], [30, 'Barbados']
        ],
        'Florida' => [
            [32, 'Orlando'], [51, 'Miami']
        ],
        'Hawaii' => [
            [79, 'Honolulu'], [81, 'Maui'], [80, 'Kona']
        ]
    ];
    public $view;


    public $post;
    /**
     * @var Database
     */
    private $DB;
    /**
     * @var Helper
     */
    private $helper;
    /**
     * @var Cache
     */
    private $phpFastCache;

    /**
     * Shortcode constructor.
     */
    public function __construct()
    {
        global $post;
        $this->post = $post;
        $this->DB = new Database();
        $this->helper = new Helper();
        $this->phpFastCache = new Cache();
        $this->view = new View();
    }

    /**
     * add plugin required shortcodes
     */
    public function add()
    {
        add_shortcode('tr_feature_vacations_tickets', array($this, 'trFeatureVacationsTicketsCallback'));
        add_shortcode('tr_feature_vacations_table', array($this, 'trFeatureVacationsTableCallback'));

        add_shortcode('tr_feature_vacation', array($this, 'trFeatureVacation'));
        add_shortcode('ts-vacation-landing', array($this, 'trFeatureVacation'));

        add_shortcode('tr_feature_vacation_landing_page', array($this, 'trFeatureVacationLandingPage'));
        add_shortcode('ts-vacation-city', array($this, 'trFeatureVacationLandingPage'));

        add_shortcode('ts_vacation_single_page', array($this, 'trFeatureVacationSinglePage'));


        add_shortcode('tr_flight_to_popular_destinations', array($this, 'trFlightToPopularDestinations'));
        add_shortcode('tr_flights_airport', array($this, 'trFlightsAirport'));
        add_shortcode('ts-flights-city', array($this, 'trFlightToPopularDestinations'));

        add_shortcode('tr_get_fast_and_easy_saving_hotels_deals', array($this, 'trGetFastAndEasySavingHotelsDealsCallback'));

        add_shortcode('tr_flights_to_popular_destinations', array($this, 'trFlightsToPopularDestinations'));
        add_shortcode('ts-flights-landing', array($this, 'trFlightsToPopularDestinations'));

        add_shortcode('tr_plan_your_trip', array($this, 'trPlanYourTrip'));

        add_shortcode('tr_trending_hotel_destination', array($this, 'trTrendingHotelDestination'));
        add_shortcode('ts-hotel-landing', array($this, 'trTrendingHotelDestination'));

        add_shortcode('tr_looking_for_particular_type_of_hotel', array($this, 'trLookingForParticularTypeOfHotel'));
        add_shortcode('tr_dont_miss_these_package_deals', array($this, 'trDontMissThesePackageDeals'));

        add_shortcode('ts-hotel-city', array($this, 'trHotelCity'));

        //login shortcode
        add_shortcode('trip_support_login_form_shortcode', array($this, 'loginFormCallback'));

        //new design login shortcode
        add_shortcode('trip_support_login_form_shortcode_new_design', array($this, 'tripSupportLoginFormShortcodeNewDesign'));
        add_shortcode('trip_support_login_mobile', array($this, 'tripSupportLoginMobile'));

        add_shortcode('trip_support_message', array($this, 'tripSupportMessage'));
    }

    public function trHotelCity()
    {
        ob_start();
        $fastCache = $this->phpFastCache->get('trending_hotel_destination_main');
        if ($fastCache == null) {
            try {
                $data = wp_remote_post('https://hotelapi.tripsupport.ca/api/Reservation/Availability', [
                    'headers' => [
                        'accept' => 'text/plain',
                        'Content-Type' => 'application/json-patch+json'
                    ],
                    'body' => json_encode(array(
                        'destination' =>
                            array(
                                'id' => 3089,
                                'name' => 'Paris',
                                'secondaryName' => 'Île de France, France',
                                'type' => 0,
                            ),
                        'checkIn' => Carbon::now()->addDays(30)->toISOString(),
                        'checkOut' => Carbon::now()->addDays(40)->toISOString(),
                        'nationality' => 'Canada',
                        'currency' => 'ca',
                        'occupancies' =>
                            array(
                                0 =>
                                    array(
                                        'adultCount' => 1,
                                        'childCount' => 0,
                                    ),
                            ),
                    )),
                ]);
            } catch (Exception $exception) {
                return false;
            }
            $hotels = json_decode($data['body']);
            $this->phpFastCache->set($data['body'], 'trending_hotel_destination_main');
        } else {
            $hotels = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/hotel-city-template.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     */
    public function loginFormCallback()
    {
        ob_start();

        if (file_exists(TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/login/login-form-template.php')) {
            require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/login/login-form-template.php';
        } else {
            echo self::LOGIN_FORM_TEMPLATE_NOT_FOUND_MESSAGE;
        }

        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trDontMissThesePackageDeals()
    {
        ob_start();
        $fastCache = $this->phpFastCache->get('dont_miss_these_package_deals_main5');
        if ($fastCache == null) {
            try {
                $data = wp_remote_post('https://flighthotelapi.tripsupport.com/api/Reservation/Availability', [
                    'headers' => [
                        'accept' => 'text/plain',
                        'Content-Type' => 'application/json-patch+json'
                    ],
                    'body' => json_encode(array(
                        'destination' =>
                            array(
                                'id' => 6087892,
                                'name' => 'string',
                                'secondaryName' => 'string',
                                'type' => 0,
                            ),
                        'departureDate' => '2021-08-03',
                        'returnDate' => '2021-08-06',
                        'nationality' => 'US',
                        'currency' => 'USD',
                        'occupancies' =>
                            array(
                                0 =>
                                    array(
                                        'adultCount' => 1,
                                        'childCount' => 0,
                                        'childAges' =>
                                            array(),
                                    ),
                            ),
                        'departureFrom' =>
                            array(
                                'code' => 'YTO',
                                'name' => 'Toronto All airports',
                                'cityCode' => 'YTO',
                                'cityName' => 'Toronto',
                                'countryCode' => 'CA',
                                'countryName' => 'Canada',
                            ),
                        'checkIn' => '2021-08-03',
                        'checkOut' => '2021-08-06',
                        'class' => 1,
                        'directFlightOnly' => false,
                    ))
                ]);
            } catch (Exception $exception) {
                return false;
            }
            $flightHotels = json_decode($data['body']);
            $this->phpFastCache->set($data['body'], 'dont_miss_these_package_deals_main5');
        } else {
            $flightHotels = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/dont_miss_these_package_deals.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trLookingForParticularTypeOfHotel()
    {
        ob_start();
        $fastCache = $this->phpFastCache->get('looking_for_particular_type_of_hotel_main');
        if ($fastCache == null) {
            try {
                $data = wp_remote_post('https://hotelapi.tripsupport.ca/api/Reservation/Availability', [
                    'headers' => [
                        'accept' => 'text/plain',
                        'Content-Type' => 'application/json-patch+json'
                    ],
                    'body' => json_encode(array(
                        'destination' =>
                            array(
                                'id' => 3089,
                                'name' => 'Paris',
                                'secondaryName' => 'Île de France, France',
                                'type' => 0,
                            ),
                        'checkIn' => Carbon::now()->toISOString(),
                        'checkOut' => Carbon::now()->addDays(10)->toISOString(),
                        'nationality' => 'Canada',
                        'currency' => 'ca',
                        'occupancies' =>
                            array(
                                0 =>
                                    array(
                                        'adultCount' => 1,
                                        'childCount' => 0,
                                    ),
                            ),
                    ))
                ]);
            } catch (Exception $exception) {
                return false;
            }
            $hotels = json_decode($data['body']);
            $this->phpFastCache->set($data['body'], 'looking_for_particular_type_of_hotel_main');
        } else {
            $hotels = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/looking_for_particular_hotel.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trTrendingHotelDestination()
    {
        ob_start();
        $fastCache = $this->phpFastCache->get('trending_hotel_destination_main5');
        if ($fastCache == null) {
            try {
                $data = wp_remote_post('https://hotelapi.tripsupport.ca/api/Reservation/Availability', [
                    'headers' => [
                        'accept' => 'text/plain',
                        'Content-Type' => 'application/json-patch+json'
                    ],
                    'body' => json_encode(array(
                        'destination' =>
                            array(
                                'id' => 6167865,
                                'name' => 'string',
                                'secondaryName' => 'string',
                                'type' => 0,
                            ),
                        'checkIn' => Carbon::now()->addDays(30)->toISOString(),
                        'checkOut' => Carbon::now()->addDays(40)->toISOString(),
                        'nationality' => 'string',
                        'currency' => 'string',
                        'occupancies' =>
                            array(
                                0 =>
                                    array(
                                        'adultCount' => 1,
                                        'childCount' => 0,
                                    ),
                            ),
                    )),
                ]);
            } catch (Exception $exception) {
                return false;
            }
            $hotels = json_decode($data['body']);
            $this->phpFastCache->set($data['body'], 'trending_hotel_destination_main5');
        } else {
            $hotels = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/trending_hotel_destination.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trPlanYourTrip()
    {
        ob_start();
        $startDate = Carbon::now()->toISOString();
        $dataFiveStarVacation=$this->trPlanYourTripFiveStar()[0];
        $url_vacations_five_star=$this->trPlanYourTripFiveStar()[1];

        $dataWinterVacationDeals = $this->trPlanYourTripWinter()[0];
        $url_vacations_winter = $this->trPlanYourTripWinter()[1];

        $dataHoneymoonDeals = $this->trPlanYourTripHoneymoon()[0];
        $url_vacations_honeymoon = $this->trPlanYourTripHoneymoon()[1];

//        $fastCache = $this->phpFastCache->get('plan_your_trip_main');
//        if ($fastCache == null) {
//            $vacationsData = wp_remote_get('https://vacationapi.tripsupport.ca/api/Vacation/GetFeaturedVacations');
//            $vacations = json_decode($vacationsData['body']);
//            $fiveStarVacation = $vacations->data->{"5 Star Vacations"};
//            $winterVacationDeals = $vacations->data->{"Winter Vacation Deals"};
//            $honeymoonDeals = $vacations->data->{"Honeymoon Deals"};
//            $this->phpFastCache->set(json_encode($vacations), 'plan_your_trip_main');
//        } else {
//            // $vacations = json_decode($cache[0]->value);
//            $vacations = json_decode($fastCache);
//            $fiveStarVacation = $vacations->data->{"5 Star Vacations"};
//            $winterVacationDeals = $vacations->data->{"Winter Vacation Deals"};
//            $honeymoonDeals = $vacations->data->{"Honeymoon Deals"};
//        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tr_plan_your_trip.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trPlanYourTripFiveStar()
    {
        $dayName = Carbon::now()->format('l'); // Monday
        $nextMonth= Carbon::now()->addDays(30)->toISOString();
        $fastCacheFiveStar = $this->phpFastCache->get('plan_your_trip_five_star18');
        $url_vacations_five_star="https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=27%2C29%2C25%2C30%2C60%2C33%2C568546%2C16%2C70%2C64%2C569962%2C21%2C2974%2C92%2C3049121%2C87%2C47%2C15%2C76%2C13%2C73%2C8%2C10%2C40%2C14%2C12%2C34%2C28%2C18%2C4244%2C1843%2C1341400%2C1341882%2C2%2C17%2C44%2C3049105%2C7%2C77%2C69%2C3049111%2C2488%2C9%2C24%2C156%2C36%2C237%2C62&DepartureDate=".$nextMonth."&Durations=5%2C6%2C7%2C8%2C9%2C10&AllInclusive=true&NumberOfRooms=1&NumberOfAdults=2&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true";
        if($dayName=="Monday" && $fastCacheFiveStar != null)
        {
            $url_vacations_five_star="https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=27%2C29%2C25%2C30%2C60%2C33%2C568546%2C16%2C70%2C64%2C569962%2C21%2C2974%2C92%2C3049121%2C87%2C47%2C15%2C76%2C13%2C73%2C8%2C10%2C40%2C14%2C12%2C34%2C28%2C18%2C4244%2C1843%2C1341400%2C1341882%2C2%2C17%2C44%2C3049105%2C7%2C77%2C69%2C3049111%2C2488%2C9%2C24%2C156%2C36%2C237%2C62&DepartureDate=".$nextMonth."&Durations=5%2C6%2C7%2C8%2C9%2C10&AllInclusive=true&NumberOfRooms=1&NumberOfAdults=2&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true";
        }

        $resultVacationsFiveStar='';
        if ($fastCacheFiveStar == null) {
            $vacationsDataFiveStar = wp_remote_get($url_vacations_five_star);
            $responseBody = wp_remote_retrieve_body( $vacationsDataFiveStar);
            $resultVacationsFiveStar = json_decode( $responseBody ,true);
            $this->phpFastCache->set($resultVacationsFiveStar, 'plan_your_trip_five_star18');
        } else {
            $resultVacationsFiveStar = $fastCacheFiveStar;
        }
        return ([$resultVacationsFiveStar['data'],$url_vacations_five_star]) ;
    }
    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trPlanYourTripWinter()
    {
        $fastCacheWinter = $this->phpFastCache->get('plan_your_trip_winter4');
        $url_vacations_winter='https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=27%2C29%2C25%2C30%2C60%2C33%2C568546%2C16%2C70%2C64%2C569962%2C21%2C2974%2C92%2C3049121%2C87%2C47%2C15%2C76%2C13%2C73%2C8%2C10%2C40%2C14%2C12%2C34%2C28%2C18%2C4244%2C1843%2C1341400%2C1341882%2C2%2C17%2C44%2C3049105%2C7%2C77%2C69%2C3049111%2C2488%2C9%2C24%2C156%2C36%2C237%2C62&DepartureDate=2021-10-15T00%3A00%3A00.0000000&Durations=5%2C6%2C7%2C8%2C9%2C10&AllInclusive=true&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=3&FlexibleDate=true';
        $vacationsWinter='';
        if ($fastCacheWinter == null) {
            $vacationsDataWinter = wp_remote_get($url_vacations_winter);
            $responseBodyWinter = wp_remote_retrieve_body( $vacationsDataWinter);
            $vacationsWinter = json_decode($responseBodyWinter,true);
            $this->phpFastCache->set($vacationsWinter, 'plan_your_trip_winter4');
        } else {
            $vacationsWinter = $fastCacheWinter;
        }
        return ([$vacationsWinter['data'],$url_vacations_winter]) ;
    }
    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trPlanYourTripHoneymoon()
    {
        $dayName_ = Carbon::now()->format('l'); // Monday
        $nextMonth_= Carbon::now()->addDays(30)->toISOString();
        $fastCacheHoneymoon = $this->phpFastCache->get('plan_your_trip_honeymoon2');
        $url_vacations_honeymoon="https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=27%2C29%2C25%2C30%2C60%2C33%2C568546%2C16%2C70%2C64%2C569962%2C21%2C2974%2C92%2C3049121%2C87%2C47%2C15%2C76%2C13%2C73%2C8%2C10%2C40%2C14%2C12%2C34%2C28%2C18%2C4244%2C1843%2C1341400%2C1341882%2C2%2C17%2C44%2C3049105%2C7%2C77%2C69%2C3049111%2C2488%2C9%2C24%2C156%2C36%2C237%2C62&DepartureDate=".$nextMonth_."&Durations=5%2C6%2C7%2C8%2C9%2C10&AllInclusive=true&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=1299&Stars=3&FlexibleDate=true";
        if($dayName_=="Monday" && $fastCacheHoneymoon != null)
        {
            $url_vacations_honeymoon="https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=27%2C29%2C25%2C30%2C60%2C33%2C568546%2C16%2C70%2C64%2C569962%2C21%2C2974%2C92%2C3049121%2C87%2C47%2C15%2C76%2C13%2C73%2C8%2C10%2C40%2C14%2C12%2C34%2C28%2C18%2C4244%2C1843%2C1341400%2C1341882%2C2%2C17%2C44%2C3049105%2C7%2C77%2C69%2C3049111%2C2488%2C9%2C24%2C156%2C36%2C237%2C62&DepartureDate=".$nextMonth_."&Durations=5%2C6%2C7%2C8%2C9%2C10&AllInclusive=true&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=1299&Stars=3&FlexibleDate=true";
        }

        $vacationsHoneymoon='';
        if ($fastCacheHoneymoon == null) {
            $vacationsDataHoneymoon = wp_remote_get($url_vacations_honeymoon);
            $responseBodyHoneymoon = wp_remote_retrieve_body( $vacationsDataHoneymoon);
            $vacationsHoneymoon = json_decode($responseBodyHoneymoon,true);
            $this->phpFastCache->set($vacationsHoneymoon, 'plan_your_trip_honeymoon2');
        } else {
            $vacationsHoneymoon = $fastCacheHoneymoon;
        }
        return ([$vacationsHoneymoon['data'],$url_vacations_honeymoon]) ;


    }

    /**
     * @param $variables
     * @return false|string
     * @throws PhpfastcacheSimpleCacheException
     * @throws InvalidArgumentException
     */
    public function trFlightsToPopularDestinations($variables)
    {
        if (isset($variables['city'])) {
            $cityName = $variables['city'];
        } else {
            $cityName = 'canada';
        }
        ob_start();
        $fastCache = $this->phpFastCache->get('flights_to_popular_destinations_canada');
        if ($fastCache == null) {
            $destinations = wp_remote_get('https://adminapi.tripsupport.com/api/marketing/mroutes/ca/' . 'canada')['body'];
            $this->phpFastCache->set($destinations, 'flights_to_popular_destinations_canada');
            $destinations = json_decode($destinations);
        } else {
            $destinations = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tr_flights_to_popular_destinations.php';
        return ob_get_clean();
    }

    /**
     * @return bool|false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trGetFastAndEasySavingHotelsDealsCallback()
    {
        ob_start();
        global $post;
        $postId = $this->helper->getCityId($post->ID, 'tr_hotel_id') != false ? $this->helper->getCityId($post->ID, 'tr_hotel_id') : '6167865';
        $fastCache = $this->phpFastCache->get('get_fast_and_easy_saving_hotels_deals_main2' . $postId);
        if ($fastCache == null) {
            try {
                $data = wp_remote_post('https://hotelapi.tripsupport.ca/api/Reservation/Availability', [
                    'headers' => [
                        'accept' => 'text/plain',
                        'Content-Type' => 'application/json-patch+json'
                    ],
                    'body' => json_encode(array(
                        'destination' =>
                            array(
                                'id' => $postId,
                                'name' => 'Toronto',
                                'secondaryName' => 'Ontario, Canada',
                                'type' => 0,
                            ),
                        'checkIn' => Carbon::now()->addDays(5)->toISOString(),
                        'checkOut' => Carbon::now()->addDays(10)->toISOString(),
                        'nationality' => 'string',
                        'currency' => 'string',
                        'occupancies' =>
                            array(
                                0 =>
                                    array(
                                        'adultCount' => 1,
                                        'childCount' => 0,
                                    ),
                            ),
                    ))
                ]);
            } catch (Exception $exception) {
                return false;
            }
            $hotels = json_decode($data['body']);
            $this->phpFastCache->set($data['body'], 'get_fast_and_easy_saving_hotels_deals_main2' . $postId);
        } else {
            $hotels = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tr-get-fast-and-easy-saving-hotels-deals.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trFlightToPopularDestinations()
    {
        global $post;
        $cityName = $this->helper->getCityId($post->ID, 'tr_flight_id');
        if ($this->helper->getCityId($post->ID, 'tr_flight_id')) {
            $cityName = $this->helper->getCityId($post->ID, 'tr_flight_id');
        } else {
            $cityName = 'canada';
        }
        $fastCache = $this->phpFastCache->get('flights_to_popular_destinations_' . $cityName);
        if ($fastCache == null) {
            $destinations = wp_remote_get('https://adminapi.tripsupport.com/api/marketing/mroutes/ca/' . $cityName)['body'];
            $this->phpFastCache->set($destinations, 'flights_to_popular_destinations_' . $cityName);
            $destinations = json_decode($destinations);
        } else {
            $destinations = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/flight-to-popular-destinations.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trFlightsAirport()
    {
        global $post;
        $departure_airport = get_post_meta($post->ID, 'flight_departure_airport', true);
        $arrival_airport = get_post_meta($post->ID, 'flight_arrival_airport', true);
        $url="";
        $destinations="";
        if(!empty($departure_airport)&&empty($arrival_airport)){
            $url="https://adminapi.tripsupport.com/api/marketing/mroutes?departureAirportCode=".$departure_airport;
            $fastCache = $this->phpFastCache->get('flights_airport_'. $departure_airport.'departure' );
            if ($fastCache == null) {
                $destinations = wp_remote_get($url)['body'];
                $this->phpFastCache->set($destinations, 'flights_airport_'. $departure_airport.'departure');
                $destinations = json_decode($destinations);
            } else {
                $destinations = json_decode($fastCache);
            }

        }
        elseif (empty($departure_airport)&&!empty($arrival_airport)){
            $url="https://adminapi.tripsupport.com/api/marketing/mroutes?arrivalAirportCode=".$arrival_airport;
            $fastCache = $this->phpFastCache->get('flights_airport_'. $arrival_airport.'arrival' );
            if ($fastCache == null) {
                $destinations = wp_remote_get($url)['body'];
                $this->phpFastCache->set($destinations, 'flights_airport_'. $arrival_airport.'arrival');
                $destinations = json_decode($destinations);
            } else {
                $destinations = json_decode($fastCache);
            }
        }


        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tr-flights_airport.php';
        return ob_get_clean();
    }


    /**
     * @return false|string
     * @throws InvalidArgumentException
     */
    public function trFeatureVacationSinglePage()
    {
        ob_start();
        global $post;
        $modified= str_ireplace(array( ' ', '-',
            ':' ), "_", $post->post_modified);
        $search_url = get_post_meta($post->ID, 'vacation_search_url', true);
        $url = explode("From=", $search_url);
        $airport= explode('&', $url[1], 2);
        $cookie_name = "userLocation";
        $cookie_airport="";
        if(isset($_COOKIE[$cookie_name])) {
            $str_cookie=	$_COOKIE[$cookie_name];
            $cookie_value = explode(",", $str_cookie);
            $cookie_value_new= explode(':', $cookie_value[1]);
            $cookie_airport= str_ireplace( array( '\\', '"',
                ',' , ';', '{', '}' ), '', $cookie_value_new[1]);
        }
        $search_url_airport = str_replace($airport[0], $cookie_airport, $search_url);
        $startDate = Carbon::now()->addDays(30)->toISOString();
        $fastCache = $this->phpFastCache->get('feature_vacation_single_page_' . $post->ID . $modified . $cookie_airport);
        if ($fastCache == null) {
            $defaultVacations = (new HttpClient())
                ->get($search_url_airport)
                ->body();
            if(empty($defaultVacations->response->data)){
                $defaultVacations = (new HttpClient())
                    ->get($search_url)
                    ->body();
            }
            $defaultVacations = $defaultVacations->response->data;
            $this->phpFastCache->set(json_encode($defaultVacations), 'feature_vacation_single_page_' . $post->ID . $modified . $cookie_airport);
        } else {
            $defaultVacations = json_decode($fastCache);
        }
        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tr-feature-vacation-single_page.php';
        return ob_get_clean();

    }


    /**
     * @param $value
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trFeatureVacationsTicketsCallback($value)
    {
        ob_start();
        if (!isset($value['city'])) {
            $cityName = $this->getCurrentCityFromUrl();
        } else {
            $cityName = $value['city'];
        }
        $fastCache = $this->phpFastCache->get('feature_vacations_tickets_main');
        if ($fastCache == null) {
            $destinations = (new HttpClient())
                ->get(self::LANDING_PAGE_BASE_UR . '?url=flights-to-' . $cityName . '&countryCode=CA')
                ->body()
                ->getResult()
                ->getDestinationPageRoute()
                ->response;
            $this->phpFastCache->set($destinations, 'feature_vacations_tickets_main');
        } else {
            $destinations = $fastCache;
        }
        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tickets.php';

        return ob_get_clean();
    }

    /**
     * Get city name from url
     * First split all url by / delimiter
     * Next split last index of result array by -  delimiter
     *
     * @return mixed
     */
    public function getCurrentCityFromUrl()
    {
        $result = explode('/', get_permalink());
        $result = array_filter($result);
        $result = explode('-', end($result));
        $result = end($result);

        return str_replace('_', '-', $result);
    }

    /**
     * @return false|string
     */
    public function trFeatureVacationsTableCallback($value)
    {
        ob_start();
        if (!isset($value['city'])) {
            $cityName = $this->getCurrentCityFromUrl();
        } else {
            $cityName = $value['city'];
        }
        $destinations = (new HttpClient())
            ->get(self::LANDING_PAGE_BASE_UR . '?url=flights-to-' . $cityName . '&countryCode=CA')
            ->body()
            ->getResult()
            ->getDestinationPageRoute()
            ->response;
        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/table.php';

        return ob_get_clean();
    }

    public function trFeatureVacationLandingPage()
    {
        ob_start();
        global $post;
        $cityId = $this->helper->getCityId($post->ID, 'tr_vacation_id');
        if ($cityId == null) {
            $cityId = 2;
        }
        $startDate = Carbon::now()->addDays(30)->toISOString();
        $fastCache = $this->phpFastCache->get('feature_vacation_landing_page_' . $cityId);
        if ($fastCache == null) {
            $defaultVacations = (new HttpClient())
                ->get('https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=' . $cityId . '&DepartureDate=' . $startDate . '&Durations=10&AllInclusive=false&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true&PageNumber=1')
                ->body();
            $defaultVacations = $defaultVacations->response->data;
            $this->phpFastCache->set(json_encode($defaultVacations), 'feature_vacation_landing_page_' . $cityId);
        } else {
            $defaultVacations = json_decode($fastCache);
        }
        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tr-feature-vacation-landing-page.php';
        return ob_get_clean();
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     * @throws PhpfastcacheSimpleCacheException
     */
    public function trFeatureVacation()
    {
        ob_start();
        $startDate = Carbon::now()->addDays(30)->toISOString();
        $fastCache = $this->phpFastCache->get('feature_vacation_main1');
        if ($fastCache == null) {
            $defaultVacations = (new HttpClient())
                ->get(self::FEATURE_VACATION_BASE_URL . '?From=YYZ&To=2' . '&DepartureDate=' . $startDate . '&Durations=7,8&AllInclusive=false&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true&PageNumber=1')
                ->body();

            $defaultVacations = $defaultVacations->response->data;
            $this->phpFastCache->set(json_encode($defaultVacations), 'feature_vacation_main1');
        } else {
            $defaultVacations = json_decode($fastCache);
        }

        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/feature-vacation.php';

        return ob_get_clean();
    }

    public function tripSupportLoginFormShortcodeNewDesign()
    {
        ob_start();
        $this->view->login()->render('new-design');
        return ob_get_clean();
    }
    public function tripSupportLoginMobile()
    {
        ob_start();
        $this->view->login()->render('login-form-mobile');
        return ob_get_clean();
    }

    public function tripSupportMessage()
    {
       $cookie_name = "userLocation";
        $country="";
        if(isset($_COOKIE[$cookie_name])) {
            $str_cookie=	$_COOKIE[$cookie_name];
            $cookie_value = explode("cc", $str_cookie);
            $country= str_ireplace( array( '\\', '"',
                ':' , ',' , ';', '{', '}' ), '', $cookie_value[1]);
        }
        $options = get_option( 'trip_settings' );
        $Locations=isset($options['opt-group-user']) ? $options['opt-group-user'] : '';
        if(!empty($Locations) ) {
            foreach (  $Locations as $location ) {
                if ($country == $location['opt-location']) {

                    echo  "<p class='tr-message'>".  $location['opt-message'] . " </p>";

                }
            }
        }
        ob_start();
        require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/tr-location-message.php';
        return ob_get_clean();

    }



    /**
     * @param $days
     * @param $format
     * @return false|string
     */
    public function getCurrentDate($days, $format)
    {
        //"D, d M"
        $date = date_create();
        date_modify($date, "+" . $days . " days");

        return date_format($date, $format);
    }

    /**
     * @return string
     */
    public function getCurrentFormatOfCityName()
    {
        $result = $this->getCurrentCityFromUrl();
        $result = str_replace('flights-to-', '', $result);

        return ucwords($result);
    }
}