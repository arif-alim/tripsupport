<div class="container p-0">
    <p class="font-weight-bold tr-feature-vacation-text mb-0 pb-2">
        <?php
         $title = get_post_meta($post->ID, 'vacation_search_title', true);
         $description = get_post_meta($post->ID, 'vacation_search_description', true);
        echo (!empty($title)) ? $title : 'Vacation Single Page'; ?>
        </p>
    <div class="col-md-12 row p-0 m-0">
        <div class="col-md-9 p-0">
            <span class="font-weight-light tr-feature-vacation-small-text">
                <?php echo (!empty($description)) ? $description : 'Plan your vacation at one of our beautiful resorts across the United States, Canada, Caribbean and Latin America'; ?>
            </span>
            <br>
        </div>

    </div>
    <div class="tr-select-destination-desktop">

    </div>

    <div class="tr-destinations-wide d-none d-sm-block">
        <div class="col-md-12 row p-0 m-0">
            <?php $domain=$_SERVER['SERVER_NAME'] ?>
            <?php  for ($turn = 0; $turn < 6; $turn++): ?>
                <?php if ($defaultVacations[$turn]): ?>
                    <div class="col-md-4 p-1 pb-3 ">
                        <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $defaultVacations[$turn]->id : 'https://secure.tripsupport.com/vacation/view-details?id='. $defaultVacations[$turn]->id; ?> "></a>
                        <div class="col-md-12 p-0 m-0 tr-feature-vacation-each-item-container p-1 tr-each-feature-vacation-container-desktop">
                    <span class="tr-feature-vacation-score-container p-1 bg-white"> <i class="fas fa-star"
                                                                                       style="color:#FFB54C"></i> <?php echo $defaultVacations[$turn]->hotel->star ?></span>
                            <img class="img-fluid tr-feature-vacation-img pb-2 w-100"
                                 src="<?php echo $defaultVacations[$turn]->hotel->image ?>">
                            <span class="tr-feature-vacation-type pl-2 pr-2 p-2"><?php echo $defaultVacations[$turn]->hotel->star ?> Star Vacation</span>
                            <p class="tr-feature-vacation-desc pl-2 pr-2 pt-3 mb-0 pb-2"><?php echo ucfirst(strtolower($defaultVacations[$turn]->hotel->meal->description)) ?>
                                | <?php echo ucfirst(strtolower($defaultVacations[$turn]->hotel->room->description)) ?></p>
                            <?php $url=explode("?",$search_url);?>
                            <a class="tr-feature-vacation-title pl-2 pr-2 mb-0 pb-2"><?php echo $defaultVacations[$turn]->hotel->name ?></a>
                            <p class="tr-feature-vacation-price pl-2 pr-2 mb-0">

                                <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                                <?php echo $defaultVacations[$turn]->price->totalPrice ?></p>
                            <p class="tr-feature-vacation-duration pl-2 pr-2 mb-0"><?php echo date("M j, Y", strtotime($defaultVacations[$turn]->departureDate));  ?> (<?php echo $defaultVacations[$turn]->duration ?> days)</p>
                            <p class="tr-feature-vacation-tax pl-2 pr-2">price includes taxes and fees</p>
                            <?php $from=explode(",",$defaultVacations[$turn]->flights[0]->departure->cityName) ?>
                            <?php $to=explode(",",$defaultVacations[$turn]->flights[0]->arrival->cityName); ?>

                            <p class="tr-feature-vacation-origin-destination pl-2 pr-2"><?php echo $from[0] ?> to <?php echo $to[0] ?> , <?php echo $defaultVacations[$turn]->flights[0]->arrival->country ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endfor; ?>

        </div>
    </div>

    <div class="tr-destinations-mobile d-block d-sm-none">
    <div class="carousel bg-white" data-flickity='{ "freeScroll": true, "contain": true,
    "groupCells": true, "pageDots": false, "prevNextButtons": false }'>

        <?php for ($turn = 0; $turn < 6; $turn++): ?>
            <?php if ($defaultVacations[$turn]): ?>
                <div style="width:66%; margin-left:10px">
                    <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $defaultVacations[$turn]->id : 'https://secure.tripsupport.com/vacation/view-details?id='. $defaultVacations[$turn]->id; ?> "></a>
                    <div class="col-md-12 p-0 m-0">
                        <div class="col-md-12 p-0 m-0 tr-each-feature-vacation-container-mobile tr-feature-vacation-each-item-container">
                        <span class="tr-feature-vacation-score-container p-2 bg-white"> <i class="fas fa-star"
                                                                                           style="color:#FFB54C"></i> <?php echo $defaultVacations[$turn]->hotel->star ?></span>
                            <img class="img-fluid tr-feature-vacation-img pb-2 w-100"
                                 src="<?php echo $defaultVacations[$turn]->hotel->image ?>">
							 <div class="px-3">
                            <span class="tr-feature-vacation-type p-2"><?php echo $defaultVacations[$turn]->hotel->star ?> Star Vacation</span>
                            <p class="tr-feature-vacation-desc pt-3 mb-0"><?php echo ucfirst(strtolower($defaultVacations[$turn]->hotel->meal->description)) ?>
                                | <?php echo ucfirst(strtolower($defaultVacations[$turn]->hotel->room->description)) ?></p>
                            <?php $url=explode("?",$search_url);?>
                            <a class="tr-feature-vacation-title mb-0"><?php echo $defaultVacations[$turn]->hotel->name ?></a>
                            <p class="tr-feature-vacation-price mb-0">

                                <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                            <?php echo $defaultVacations[$turn]->price->totalPrice ?></p>
                            <p class="tr-feature-vacation-duration mb-0"><?php echo date("M j, Y", strtotime($defaultVacations[$turn]->departureDate));  ?> (<?php echo $defaultVacations[$turn]->duration ?> days)</p>
                            <p class="tr-feature-vacation-tax">price includes taxes and fees</p>
                            <?php $from=explode(",",$defaultVacations[$turn]->flights[0]->departure->cityName) ?>
                            <?php $to=explode(",",$defaultVacations[$turn]->flights[0]->arrival->cityName); ?>

                            <p class="tr-feature-vacation-origin-destination"><?php echo $from[0] ?> to <?php echo $to[0] ?> , <?php echo $defaultVacations[$turn]->flights[0]->arrival->country ?></p>
							</div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endfor; ?>

    </div>
</div>

</div>

<script>
    var trFeatureVacationsZone = document.querySelectorAll('.tr-feature-vacation-zone');
    var trFeatureVacationCountry = document.querySelectorAll('.tr-feature-vacation-country');
    var trFeatureVacationCities = document.querySelectorAll('.tr-feature-vacation-cities');

    var trFeatureVacationZoneName = document.querySelector('.tr-fearute-vacation-zone-name');
    var trFeatureVacationCountryName = document.querySelector('.tr-fearute-vacation-country-name');

    var trEachFeatureVacationContainerDesktop = document.querySelectorAll('.tr-each-feature-vacation-container-desktop');
    var trEachFeatureVacationContainerMobile = document.querySelectorAll('.tr-each-feature-vacation-container-mobile');

    var trFeatureVacationsBaseUrl = 'https://secure.tripsupport.com/vacation' + '?From=YYZ&To=2' + '&DepartureDate=' + '<?php echo $startDate ?>' + '&Durations=10&AllInclusive=false&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true&PageNumber=1&sid=';


    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    // Zone click event listener
    trFeatureVacationsZone.forEach(featureZone => {
        featureZone.addEventListener('click', () => {
            trFeatureVacationsZone.forEach(zoneRemoveSelected => {
                zoneRemoveSelected.classList.remove('tr-feature-vacation-zone-selected');
            });
            featureZone.classList.add('tr-feature-vacation-zone-selected');
            trFeatureVacationCountryName.innerHTML = capitalizeFirstLetter(featureZone.getAttribute('value')) + '  <i class="fas fa-angle-double-right"></i>';
            trFeatureVacationCities.forEach(city => {
                console.log(featureZone.textContent);
                if (city.getAttribute('zone') == featureZone.getAttribute('value')) {
                    city.classList.remove('d-none');
                } else {
                    city.classList.add('d-none');
                }

                trFeatureVacationCountry.forEach(countryEach => {
                    // countryEach.classList.remove('tr-feature-vacation-country-selected');
                });
                //country.classList.add('tr-feature-vacation-country-selected')
            })
        })
    });

    jQuery(document).ready(function ($) {
        var data = {
            'action': 'tr_feature_vacation_single_page',
            'id':<?php echo get_the_ID(); ?>
        };
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
        // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
        jQuery.post(ajaxurl, data, function (response) {
            console.log('recieve from server');
            //console.log(response);
            var data = JSON.parse(response);
            var counter = 0;
            trEachFeatureVacationContainerDesktop.forEach(desktopContainer => {
                //console.log(desktopContainer.childNodes);
                console.log(desktopContainer.childNodes);
                desktopContainer.childNodes[3].style.filter = 'blur(0px)';
                if (JSON.parse(data.body).data[counter]) {
                    desktopContainer.classList.remove('d-none');
                    desktopContainer.childNodes[3].setAttribute("src", JSON.parse(data.body).data[counter].hotel.image);
                    desktopContainer.childNodes[5].innerText = JSON.parse(data.body).data[counter].hotel.star + ' Star Vacation';
                    desktopContainer.childNodes[9].innerText = JSON.parse(data.body).data[counter].hotel.name;
                    desktopContainer.childNodes[9].setAttribute('href', trFeatureVacationsBaseUrl + JSON.parse(data.body).data[counter].hotel.sid);
                    desktopContainer.childNodes[11].innerText = "CA $" + JSON.parse(data.body).data[counter].price.totalPrice;

                } else {
                    desktopContainer.classList.add('d-none');
                }
                counter++;
            });
            counter = 0;
            var MobileCounter = 0;
            trEachFeatureVacationContainerMobile.forEach(mobileContainer => {
                mobileContainer.childNodes[3].style.filter = 'blur(0px)';
                if (JSON.parse(data.body).data[MobileCounter]) {
                    mobileContainer.classList.remove('d-none');
                    mobileContainer.childNodes[3].setAttribute("src", JSON.parse(data.body).data[MobileCounter].hotel.image);
                    mobileContainer.childNodes[5].innerText = JSON.parse(data.body).data[MobileCounter].hotel.star + ' Star Vacation';
                    mobileContainer.childNodes[9].innerText = JSON.parse(data.body).data[MobileCounter].hotel.name;
                    mobileContainer.childNodes[9].setAttribute('href', trFeatureVacationsBaseUrl + JSON.parse(data.body).data[counter].hotel.sid);
                    mobileContainer.childNodes[11].innerText = "CA $" + JSON.parse(data.body).data[MobileCounter].price.totalPrice;
                } else {
                    mobileContainer.classList.add('d-none');
                }
                MobileCounter++;
            });
            MobileCounter = 0;
        });
    });


    var trDestinationsWide = document.querySelector('.tr-destinations-wide');
    var trDestinationsMobile = document.querySelector('.tr-destinations-wide');

    selectViewInWidthChange();

    window.addEventListener('resize', () => {
        selectViewInWidthChange();
    });

    function selectViewInWidthChange() {
        if (window.innerWidth > 576) {
            trDestinationsWide.classList.add('d-none');
            trDestinationsMobile.classList.remove('d-none');
        } else {
            trDestinationsWide.classList.remove('d-none');
            trDestinationsMobile.classList.add('d-none');
        }
    }
</script>

<style>
    div.scrollmenu {
        background-color: #fff;
        overflow: auto;
        white-space: nowrap;
    }

    div.scrollmenu a {
        display: inline-block;
        color: white;
        text-align: center;
        padding: 14px;
        text-decoration: none;
        background-color: #ccc;
    }

    div.scrollmenu a:hover {
        background-color: #777;
    }

    .scrollmenu::-webkit-scrollbar {
        display: none;
    }

    .scrollmenu {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }

    .tr-feature-vacation-country-selected {
        background-color: #66678f !important;
        color: #d9d9e3 !important;
        border-radius: 100px;
        font-size: 14px;
    }

    .tr-feature-vacation-cities-selected {
        background-color: #66678f !important;
        color: #d9d9e3 !important;
        border-radius: 100px;
        font-size: 14px;
    }

    .tr-feature-vacation-zone-selected {
        background-color: #66678f !important;
        color: #d9d9e3 !important;
        border-radius: 100px;
        font-size: 14px;
    }

    .tr-feature-vacation-country {
        color: #66678f;
        border-radius: 100px;
        font-size: 14px;
    }

    .tr-feature-vacation-zone {
        color: #66678f;
        border-radius: 100px;
        font-size: 12px;
        background: #e8e8ef;
        padding: 3px 10px !important;
    }

    .tr-feature-vacation-cities {
        background-color: #e8e8ef;
        border-radius: 18px;
        color: #66678F;
        padding-left: 5px;
        padding-right: 5px;
        width: auto !important;
        cursor: pointer;
    }

    .tr-feature-vacation-img {
        border-radius: 5px !important;
        height: 200px;
    }

    .tr-feature-vacation-score-container {
        color: #66678F;
        border-radius: 6px !important;
        position: absolute;
        box-shadow: 0 0 3px gray;
        top: 12px;
        right: 12px;
        z-index: 10;
        font-family: "Cera PRO";
        font-size: 14px;
    }

    .tr-feature-vacation-type {
        font-size: 10px;
        font-weight: bold;
        color: #8E43E7;
        text-transform: uppercase;
        background-color: #fbf8fe;
    }

    .tr-feature-vacation-desc {
        color: #66678F !important;
        font-size: 10px;
        font-family: "Cera PRO";
    }

    .tr-feature-vacation-title {
        color: #0C0D25;
        font-weight: normal;
        font-size: 18px;
        line-height: 22px;
        font-family: "Cera PRO";
        text-decoration: none !important;
        height: 4rem !important;
        display: block;
    }

    .tr-feature-vacation-price {
        font-size: 16px;
        color: #0C0D25;
        font-weight: bold;
        font-family: "Cera PRO";
    }

    .tr-feature-vacation-duration {
        font-size: 14px;
        font-family: "Cera PRO";
    }

    .tr-feature-vacation-tax {
        color: #66678F;
        font-size: 12px;
        font-weight: 100;
        font-family: "Cera PRO";
    }

    .tr-feature-vacation-origin-destination {
        color: #007AFF;
        font-size: 12px;
        font-weight: 400;
        font-family: "Cera PRO";
        font-weight: 700;
        padding-bottom: 10px;
    }


    .carousel {
        background: #EEE;
    }

    .swiper-slide {
        width: auto !important;
        cursor: pointer;
        font-family: "Cera PRO";
        padding-bottom: 3px;
        padding-top: 3px;
        padding-left: 10px;
        padding-right: 10px;
        font-size: 12px;

    }

    .tr-each-feature-vacation-container-mobile {
        background: white;
    }

    .swiper-container-pointer-events {
        margin: 0px !important;
    }


    .tr_trending_hotel_destination_items-container {
        width: 100% !important;
    }

    .tr-feature-vacation-selected {
        background-color: #66678f;
        color: #d9d9e3 !important;
    }

    .tr-feature-vacation-each-item-container {
        background: #FFFFFF;
        border: 1px solid rgba(102, 103, 143, 0.1);
        box-shadow: 0px 2px 2px rgba(102, 103, 143, 0.04);
        border-radius: 8px;
    }

    .tr-feature-vacation-text {
        font-family: Cera PRO;
        font-style: normal;
        font-weight: normal;
        font-size: 23px;
        line-height: 100%;
        letter-spacing: -0.02em;
        color: #0C0D25;
    }

    .tr-feature-vacation-small-text {
        font-family: Cera PRO;
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 24px;
        letter-spacing: -0.02em;
        color: #66678F;
    }

    .tr-select-location {
        background-color: white !important;
        border-radius: 4px;
        box-shadow: 0 0 3px lightgray;
        font-family: "Cera PRO";
    }

    .tr-feature-vacation-select-location-text {
        font-family: Cera PRO;
        font-style: normal;
        font-weight: 700;
        font-size: 12px;
        line-height: 16px;
        letter-spacing: -0.02em;
    }
    .tr-link-box{
        display: block;
        width: 100%;
        height: 90%;
        position: absolute;
        z-index: 1000;
    }
</style>

<script>
    var swiperFeatureVacation = new Swiper('.swiper-container-feature-vacation', {
        breakpoints: {
            960: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            720: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            540: {
                slidesPerView: 1.5,
                spaceBetween: 10
            },
            320: {
                slidesPerView: 1.5,
                spaceBetween: 10
            },
        },
    });
</script>