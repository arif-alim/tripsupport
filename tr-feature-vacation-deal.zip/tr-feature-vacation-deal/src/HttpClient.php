<?php


namespace Tr\Feature\Vacation;


class HttpClient
{
    /**
     * @var
     */
    public $response;

    /**
     * @param $url
     * @param string $args
     * @return $this
     */
    public function get($url, $args = '')
    {
        $this->response = wp_remote_get($url, $args);
        return $this;
    }

    /**
     * @return $this
     */
    public function body()
    {
        $this->response = json_decode($this->response['body']);
        return $this;
    }

    /**
     * @return $this
     */
    public function getResult()
    {
        $this->response = $this->response->result;
        return $this;
    }

    /**
     * @return $this
     */
    public function getDestinationPageRoute()
    {
        $this->response = $this->response->destinationpageroute;
        return $this;
    }
}