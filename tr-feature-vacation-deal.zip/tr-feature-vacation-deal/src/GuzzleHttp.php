<?php


namespace Tr\Feature\Vacation;


use GuzzleHttp\Client;

class GuzzleHttp
{
    /**
     * @var Client|object
     */
    private $httpClient;

    /**
     * GuzzleHttp constructor.
     */
    public function __construct()
    {
        $this->httpClient = new Client();
    }

    /**
     * @param $method
     * @param $url
     * @param $options
     * @return string
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function request(string $method, string $url, array $options)
    {
        $data = $this->httpClient->request($method, $url, $options);

        return (string)$data->getBody();
    }
}