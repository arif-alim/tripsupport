<script>

    jQuery(window).load(function () {
        var data = {
            'action': 'get_location_message'
        };
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

        jQuery.post(ajaxurl, data, function (response) {
            if (jQuery( "p" ).hasClass( "tr-message" )){
                jQuery('.tr-message').html(response);
            }
            else{
                jQuery('body').prepend("<p class='tr-message'></p>");
                jQuery('.tr-message').html(response);
            }
            if(response==""){
                if (jQuery( "p" ).hasClass( "tr-message" )){
                    jQuery('.tr-message').remove();
                }
            }



        });

    });


</script>
