<?php
global $post;
$postCityIdMetaBoxValue = get_post_meta($post->ID, 'tr_flight_id', true);
?>

<label>City Name : </label>
<input type="text" placeholder="canada" name="tr_flight_post_id" value="<?php echo $postCityIdMetaBoxValue ?>">