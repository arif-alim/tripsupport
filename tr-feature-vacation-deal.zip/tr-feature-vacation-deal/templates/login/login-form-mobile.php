<?php $domain=$_SERVER['SERVER_NAME'] ?>
<div class="tr-login-form-mobile d-block d-md-none">

    <div class="pt-1 tr-login-mobile">
        <button type="button" class="dropdown-toggle tr-login-btn-m border-0" data-toggle="dropdown">
            <img class="pt-3" src="https://tripsupport.ca/wp-content/themes/TripSuport/assets/img/icon-user-black.svg">
        </button>
        <div class="dropdown-menu tr-300 tr-login-dropdown p-3" style="margin-right:10rem" role="menu">
            <p class="text-center tr-register-login-form-title">Login</p>
            <label class="tr-register-login-form-label">Email Address</label>
            <input type="email" placeholder="Enter Email Address"
                   style="direction:ltr"
                   class="form-control tr-register-login-form-input tr-login-user-email-m p-3 mb-3">
            <label class="tr-register-login-form-label">Password</label>
            <input type="password" placeholder="*********"
                   style="direction:ltr"
                   class="form-control tr-login-user-password-m tr-register-login-form-input p-3 mb-3">
            <button class="btn btn-block tr-register-login-form-btn" id="tr-login-action-btn-m">Login</button>
            <hr>
            <a class="tr-register-login-form-forgot-link" id="tr-forgot-password-m">forgot password</a>
            <span>|</span>
            <a class="tr-register-login-form-forgot-link d-inline d-md-none" id="tr-create-account-mobile">Create Account</a>
        </div>
    </div>

    <div class="btn-group">
        <button type="button" class="dropdown-toggle tr-register-btn-m bg-transparent border-0" data-toggle="dropdown">
        </button>
        <div class="dropdown-menu tr-300 tr-register-dropdown p-3" style="margin-right:10rem" role="menu">
            <p class="text-center tr-register-login-form-title">Create Account</p>
            <label class="tr-register-login-form-label">First Name</label>
            <input type="email" placeholder="Enter First Name"
                   style="direction:ltr"
                   class="form-control tr-register-login-form-input tr-create-new-account-fr-name-m p-3 mb-3">
            <label class="tr-register-login-form-label">Last Name</label>
            <input type="email" placeholder="Enter Last Name"
                   style="direction:ltr"
                   class="form-control tr-register-login-form-input tr-create-new-account-ln-name-m p-3 mb-3">
            <label class="tr-register-login-form-label">Email Address</label>
            <input type="email" placeholder="Enter Email Address"
                   style="direction:ltr"
                   class="form-control tr-register-login-form-input tr-create-new-account-email-m p-3 mb-3">
            <label class="tr-register-login-form-label">Password</label>
            <input type="password" placeholder="*******"
                   style="direction: ltr"
                   class="form-control tr-register-login-form-input p-3 mb-3 tr-create-new-account-password-m">
            <button class="btn btn-block tr-register-login-form-btn" id="tr-create-account-btn-m">Create Account
            </button>
            <hr>
            <span>Already have an account?</span>
            <a class="tr-register-login-form-forgot-link" id="tr-already-have-account-m">Sign In</a>
        </div>
    </div>

    <div class="btn-group">
        <button type="button" class="dropdown-toggle tr-profile-btn-m border-0 bg-transparent" data-toggle="dropdown">

        </button>
        <div class="dropdown-menu tr-200 tr-login-dropdown p-3" style="margin-right:10rem" role="menu">

            <a href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/user/bookings' : 'https://secure.tripsupport.com/user/bookings'; ?>">My bookings</a><br>
            <a href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/user/profile' : 'https://secure.tripsupport.com/user/profile'; ?>">My profile</a><br>
            <a href="javascript:void(0);" class="tr-logout-btn-m">Logout</a><br>
        </div>
    </div>

    <div class="btn-group">
        <button type="button" class=" dropdown-toggle  tr-forgot-btn-m bg-white border-0" style="cursor: context-menu;"
                data-toggle="dropdown">
        </button>
        <div class="dropdown-menu tr-300 tr-login-dropdown p-3" style="margin-right:10rem" role="menu">
            <p class="text-center tr-register-login-form-title">Forgot Password</p>
            <label class="tr-register-login-form-label">Email Address</label>
            <input type="email" placeholder="Enter Email Address"
                   style="direction:ltr"
                   class="form-control tr-register-login-form-input tr-reset-user-email-m p-3 mb-3">
            <button class="btn btn-block tr-register-login-form-btn" id="tr-rest-password-btn-m">Reset Password
            </button>
            <hr>
        </div>
    </div>

</div>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script !src="">

    const loginBaseUrlM = 'https://myprofileapi.tripsupport.com/api/myprofile/userlogindetails';
    const registerBaseUrlM = 'https://myprofileapi.tripsupport.com/api/myprofile/userregistration';
    const resetPasswordBaseUrlM = 'https://myprofileapi.tripsupport.com/api/myprofile/forgotpassword?Email=';

    var trAlreadyHaveAccountM = document.getElementById('tr-already-have-account-m');
    var trAlreadyCreateAccount = document.getElementById('tr-create-account-mobile');
    var trLoginBtnM = document.querySelector('.tr-login-btn-m');
    var trRegisterBtnM = document.querySelector('.tr-register-btn-m');
    var trProfileBtnM = document.querySelector('.tr-profile-btn-m');
    var trLogoutProfileM = document.querySelector('.tr-logout-btn-m');
    var trLoginActionBtnM = document.getElementById('tr-login-action-btn-m');

    var trBtnCreateAccountM = document.getElementById('tr-create-account-btn-m');

    // Create new  account params
    var newAccountFirstNameM = document.querySelector('.tr-create-new-account-fr-name-m');
    var newAccountLastNameM = document.querySelector('.tr-create-new-account-ln-name-m');
    var newAccountEmailM = document.querySelector('.tr-create-new-account-email-m');
    var newAccountPasswordM = document.querySelector('.tr-create-new-account-password-m');

    checkUserStorageStatusM();
    // Check user set in localstorage
    function checkUserStorageStatusM() {
        if (localStorage.getItem('user') == null) {
            trLoginBtnM.classList.remove('d-none');
            trRegisterBtnM.classList.remove('d-none');
            trProfileBtnM.classList.add('d-none');
        } else {
            var dataM = JSON.parse(localStorage.getItem('user'));
            var nameM =((dataM.result == null) ? dataM.firstname : dataM.result.firstname);
            trLoginBtnM.classList.add('d-none');
            trRegisterBtnM.classList.add('d-none');
            trProfileBtnM.innerText= 'Welcome ' + nameM;
            trProfileBtnM.classList.remove('d-none');
        }
    }

    // Logout btn action
    trLogoutProfileM.addEventListener('click', () => {
        localStorage.removeItem('user');
        checkUserStorageStatusM();
        swal("Message", "You are logged out", "success");

    });

    // Create new account send request
    trBtnCreateAccountM.addEventListener('click', () => {
        jQuery.ajax({
            url: registerBaseUrlM,
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                email: newAccountEmailM.value,
                password: newAccountPasswordM.value,
                firstname: newAccountFirstNameM.value,
                lastname: newAccountLastNameM.value
            }),
            success: function (res) {
                // set localstorage if new account created successfully
                if (res.message == 'registration successful') {
                    createdUserData = {
                        email: newAccountEmailM.value,
                        password: newAccountPasswordM.value,
                        firstname: newAccountFirstNameM.value,
                        lastname: newAccountLastNameM.value
                    };
                    localStorage.setItem('user', JSON.stringify(createdUserData));
                    checkUserStorageStatusM();
                    swal("Message",  "New account created, you are logged in successfully", "success");
                }
                else {
                    swal("Error",  res.message, "error");
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    });

    // Login params
    var loginUserPasswordM = document.querySelector('.tr-login-user-password-m');
    var loginUserEmailM = document.querySelector('.tr-login-user-email-m');

    // login request process
    trLoginActionBtnM.addEventListener('click', () => {
        jQuery.ajax({
            url: loginBaseUrlM,
            type: 'POST',
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({
                email: loginUserEmailM.value,
                password: loginUserPasswordM.value
            }),
            success: function (res) {
                if (res.hasResult == false) {
                    swal("Error", res.errorDetails.errorMsg , "error");
                }

                if (res.hasResult == true) {
                    localStorage.setItem('user', JSON.stringify(res));
                    checkUserStorageStatusM();
                    swal("Message", "You are logged in successfully" , "success");

                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    });

    trAlreadyHaveAccountM.addEventListener('click', () => {
        setTimeout(() => {
            trLoginBtnM.click();
        }, 10)
    });


    trAlreadyCreateAccount.addEventListener('click', () => {
        setTimeout(() => {
            trRegisterBtnM.click();
        }, 10)
    });

    //forgot password btns
    var trForgotBtnM = document.querySelector('.tr-forgot-btn-m');
    var registerFormForgotPasswordM = document.querySelector('#tr-forgot-password-m');
    var resetPasswordBtnM = document.querySelector('#tr-rest-password-btn-m');
    var resetUserEmailM = document.querySelector('.tr-reset-user-email-m');

    registerFormForgotPasswordM.addEventListener('click', () => {
        setTimeout(() => {
            trForgotBtnM.click();
        }, 10)
    });

    resetPasswordBtnM.addEventListener('click', () => {
        jQuery.ajax({
            url: resetPasswordBaseUrlM + resetUserEmailM.value,
            type: 'GET',
            dataType: "json",
            contentType: "application/json",
            success: function (res) {
                console.log(res);
                swal("Message", "Reset password email sent" , "info");

            },
            error: function (err) {
                console.log(err);
            }
        });
    })
</script>

<style>
    .tr-login-form-mobile .tr-300.dropdown-menu.show{
        transform: translate3d(-300px, 36px, 0px)!important;
    }
    .tr-login-form-mobile .tr-200.dropdown-menu.show{
        transform: translate3d(-200px, 36px, 0px)!important;
    }
    .tr-login-mobile{
        position: absolute;
        right: 15px;
    }
    .tr-forgot-btn-m::after {
        display: none;
    }

    .tr-register-login-form-forgot-link {
        color: #007AFF !important;
    }

    .tr-register-login-form-btn {
        background-color: #ED1B2E !important;
        font-family: "Cera PRO";
        color: #fff;
    }

    .tr-register-login-form-btn:hover {
        background-color: #ED2D3A !important;
        color: #fff;
    }

    .tr-register-login-form-label {
        color: #66678F;
        font-size: 14px;
        font-family: "Cera PRO";
    }

    .tr-register-login-form-input:focus {
        box-shadow: none !important;
    }

    .tr-register-login-form-input::placeholder {
        color: #ABABC4 !important;
    }

    .tr-register-login-form-input {
        background-color: #fff !important;
        border: 0.5px solid lightgray !important;
    }

    .tr-register-login-form-title {
        color: #0C0D25;
        font-family: "Cera PRO";
        font-size: 18px;
        font-weight: 600;
    }

    .tr-login-btn-m {
        background-color: #fff;
        color: #66678F;
        font-family: "Cera PRO";
    }

    .tr-login-btn-m::after, .tr-register-btn-m::after {
        display: none !important;
    }

    .tr-login-dropdown, .tr-register-dropdown {
        width: 20rem !important;
        border-radius: 8px !important;
        border: none !important;
        box-shadow: 0 0 5px lightgray;
        z-index:1000000;
    }


</style>