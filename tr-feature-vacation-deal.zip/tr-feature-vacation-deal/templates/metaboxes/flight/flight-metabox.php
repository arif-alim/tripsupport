<?php
global $post;
$post_departure_airport = get_post_meta($post->ID, 'flight_departure_airport', true);
$post_arrival_airport = get_post_meta($post->ID, 'flight_arrival_airport', true);
?>

<label>Departure Airport : </label>
<input type="text" style="width: 100%;" name="flight_departure_airport" value="<?php echo $post_departure_airport ?>">

<label>Arrival Airport :</label>
<input type="text" style="width: 100%;" name="flight_arrival_airport" value="<?php echo $post_arrival_airport ?>">

