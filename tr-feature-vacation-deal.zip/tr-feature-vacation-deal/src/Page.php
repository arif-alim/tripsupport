<?php


namespace Tr\Feature\Vacation;


class Page
{
    public $view;

    public $cache;

    public function __construct()
    {
        $this->cache = new Cache();
        $this->view = new View();
    }

    public function addClearCachePage() {
        add_menu_page(
            'Clear Cache',
            'Clear Cache',
            'manage_options',
            'clear-cache',
            array($this, 'addClearCachePageCallback')
        );
    }

    public function addClearCachePageCallback() {
        $this->submit();
        $this->view->page()->render('cache');
    }

    public function submit() {
        if (isset($_POST['celar-tr-plugin-cache'])) {
           $this->cache->clear();
           echo '<p style="color:green;padding: 5px 30px">Cache data cleared successfully</p>';
        }
    }
}

