<template>
  <div>
    <p>test component hi</p>
  </div>
</template>

<script>
export default {
  name: "test",
};
</script>

<style scoped>
</style>