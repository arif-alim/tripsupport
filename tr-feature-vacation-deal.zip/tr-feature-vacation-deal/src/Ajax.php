<?php

namespace Tr\Feature\Vacation;

use Carbon\Carbon;

class Ajax
{
    private $cache;

    public function __construct()
    {
        $this->cache = new Cache();

        add_action('wp_ajax_get_location_message', array($this, 'get_location_message'));
        add_action('wp_ajax_nopriv_get_location_message', array($this, 'get_location_message'));

        add_action('wp_ajax_get_feature_vacation_country', array($this, 'get_feature_vacation_country'));
        add_action('wp_ajax_nopriv_get_feature_vacation_country', array($this, 'get_feature_vacation_country'));

        add_action('wp_ajax_get_feature_vacation', array($this, 'get_feature_vacation'));
        add_action('wp_ajax_nopriv_get_feature_vacation', array($this, 'get_feature_vacation'));

        add_action('wp_ajax_tr_feature_vacation_single_page', array($this, 'tr_feature_vacation_single_page'));
        add_action('wp_ajax_nopriv_tr_feature_vacation_single_page', array($this, 'tr_feature_vacation_single_page'));

        add_action('wp_ajax_trending_hotel_destination', array($this, 'trending_hotel_destination'));
        add_action('wp_ajax_nopriv_trending_hotel_destination', array($this, 'trending_hotel_destination'));

        add_action('wp_ajax_dont_miss_these_package_deals', array($this, 'dont_miss_these_package_deals'));
        add_action('wp_ajax_nopriv_dont_miss_these_package_deals', array($this, 'dont_miss_these_package_deals'));

        add_action('wp_ajax_tr_flight_to_popular_destination', array($this, 'tr_flight_to_popular_destination'));
        add_action('wp_ajax_nopriv_tr_flight_to_popular_destination', array($this, 'tr_flight_to_popular_destination'));

        add_action('wp_ajax_tr_flight_to_popular_destination_landing', array($this, 'tr_flight_to_popular_destination_landing'));
        add_action('wp_ajax_tr_nopriv_flight_to_popular_destination_landing', array($this, 'tr_flight_to_popular_destination_landing'));
    }

    public function get_feature_vacation()
    {
        $startDate = Carbon::now()->addDays(30)->toISOString();
        $cache = $this->cache->get('feature_vacation_ajax' . $_POST['city']);
        if ($cache == null) {
            $domain=$_SERVER['SERVER_NAME'] ;
            ($domain == 'tripsupport.ca') ? $vacations = wp_remote_get('https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=' . $_POST['city'] . '&DepartureDate=' . $startDate . '&Durations=7,8&AllInclusive=false&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true&PageNumber=1')
            : $vacations = wp_remote_get('https://vacationapi.tripsupport.com/api/Vacation/FullSearch?From=YYZ&To=' . $_POST['city'] . '&DepartureDate=' . $startDate . '&Durations=7,8&AllInclusive=false&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true&PageNumber=1');

        $result=array('data' => json_encode($vacations), 'city' => $_POST['city']);
        echo json_encode($result);
        } else {
            echo json_decode(json_encode($cache));
        }
        wp_die();
    }
    public function get_feature_vacation_country()
    {
        $country=implode(",",$_POST['cities-id']);
        $startDate = Carbon::now()->addDays(30)->toISOString();
        $cache = $this->cache->get('feature_vacation_ajax' . $_POST['country']);
        if ($cache == null) {
            $domain=$_SERVER['SERVER_NAME'] ;
            ($domain == 'tripsupport.ca') ? $vacations = wp_remote_get('https://vacationapi.tripsupport.ca/api/Vacation/FullSearch?From=YYZ&To=' . $country . '&DepartureDate=' . $startDate . '&Durations=7,8&AllInclusive=false&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true&PageNumber=1')
                : $vacations = wp_remote_get('https://vacationapi.tripsupport.com/api/Vacation/FullSearch?From=YYZ&To=' . $country . '&DepartureDate=' . $startDate . '&Durations=7,8&AllInclusive=false&NumberOfRooms=1&NumberOfAdults=1&MinPrice=1&MaxPrice=99999&Stars=5&FlexibleDate=true&PageNumber=1');

            $result=array('data' => json_encode($vacations), 'country' => $_POST['country']);
            echo json_encode($result);
        } else {
            echo json_decode(json_encode($cache));
        }
        wp_die();
    }

    public function tr_feature_vacation_single_page()
	{
		$id =$_POST['id'];
		$post_vacation_search_url = get_post_meta($id, 'vacation_search_url', true);
		if(!empty($post_vacation_search_url))
		{
			$vacations =wp_remote_get($post_vacation_search_url);
			$responseBody = wp_remote_retrieve_body( $vacations);
			$result = json_decode( $responseBody ,true);
			echo json_encode($result['data']);
		}
		wp_die();

	}

	public function get_location_message(){
       $cookie_name = "userLocation";
        $country="";
        if(isset($_COOKIE[$cookie_name])) {
            $str_cookie=	$_COOKIE[$cookie_name];
            $cookie_value = explode("cc", $str_cookie);
            $country= str_ireplace( array( '\\', '"',
                ':' , ',' , ';', '{', '}' ), '', $cookie_value[1]);
        }
        $options = get_option( 'trip_settings' );
        $Locations=isset($options['opt-group-user']) ? $options['opt-group-user'] : '';
        if(!empty($Locations) ) {
            foreach (  $Locations as $location ) {
                if ($country == $location['opt-location']) {
                     wp_send_json($location['opt-message']) ;
                }
            }
            wp_die();
        }
    }

    
 


    public function trending_hotel_destination()
    {
        $cache = $this->cache->get('trending_hotel_destination_main5' . $_POST['cityId']);
        if ($cache == null) {
            $data = wp_remote_post('https://hotelapi.tripsupport.ca/api/Reservation/Availability', [
                'headers' => [
                    'accept' => 'text/plain',
                    'Content-Type' => 'application/json-patch+json'
                ],
                'body' => json_encode(array(
                    'destination' =>
                        array(
                            'id' => $_POST['cityId'],
                            'name' => 'string',
                            'secondaryName' => 'string',
                            'type' => 0,
                        ),
                    'checkIn' => Carbon::now()->addDays(30)->toISOString(),
                    'checkOut' => Carbon::now()->addDays(40)->toISOString(),
                    'nationality' => 'string',
                    'currency' => 'string',
                    'occupancies' =>
                        array(
                            0 =>
                                array(
                                    'adultCount' => 1,
                                    'childCount' => 0,
                                ),
                        ),
                )),
            ]);
            $this->cache->set($data['body'], 'trending_hotel_destination_main5' . $_POST['cityId']);
            echo $data['body'];
        } else {
            echo json_decode(json_encode($cache));
        }

        wp_die();
    }

    public function tr_flight_to_popular_destination()
    {
        $cache = $this->cache->get('tr_flights_to_popular_destinations_' . $_POST['city']);
        if ($cache == null) {
            $destinations = wp_remote_get('https://adminapi.tripsupport.com/api/marketing/mroutes/ca/' . $_POST['city']);
            $this->cache->set($destinations['body'], 'flights_to_popular_destinations_' . $_POST['city']);
            echo $destinations['body'];
        } else {
            echo json_decode(json_encode($cache));
        }

        wp_die();
    }

    public function tr_flight_to_popular_destination_landing()
    {
        $cache = $this->cache->get('flights_to_popular_destinations_landing_' . $_POST['city']);
        if ($cache == null) {
            $destinations = wp_remote_get('https://adminapi.tripsupport.com/api/marketing/mroutes/ca/' . $_POST['city']);
            $this->cache->set($destinations['body'], 'flights_to_popular_destinations_' . $_POST['city']);
            echo $destinations['body'];
        } else {
            echo json_decode(json_encode($cache));
        }

        wp_die();
    }

    public function dont_miss_these_package_deals()
    {
        $cache = $this->cache->get('dont_miss_these_package_deals_' . $_POST['cityId']);
        if ($cache == null) {
            $data = wp_remote_post('https://flighthotelapi.tripsupport.com/api/Reservation/Availability', [
                'headers' => [
                    'accept' => 'text/plain',
                    'Content-Type' => 'application/json-patch+json'
                ],
                'body' => json_encode(array(
                    'destination' =>
                        array(
                            'id' => $_POST['cityId'],
                            'name' => 'string',
                            'secondaryName' => 'string',
                            'type' => 0,
                        ),
                    'departureDate' => '2021-08-03',
                    'returnDate' => '2021-08-06',
                    'nationality' => 'US',
                    'currency' => 'USD',
                    'occupancies' =>
                        array(
                            0 =>
                                array(
                                    'adultCount' => 1,
                                    'childCount' => 0,
                                    'childAges' =>
                                        array(),
                                ),
                        ),
                    'departureFrom' =>
                        array(
                            'code' => 'YTO',
                            'name' => 'Toronto All airports',
                            'cityCode' => 'YTO',
                            'cityName' => 'Toronto',
                            'countryCode' => 'CA',
                            'countryName' => 'Canada',
                        ),
                    'checkIn' => '2021-08-03',
                    'checkOut' => '2021-08-06',
                    'class' => 1,
                    'directFlightOnly' => false,
                ))
            ]);
            $this->cache->set($data['body'], 'dont_miss_these_package_deals_' . $_POST['cityId']);
            echo $data['body'];
        } else {
            echo json_decode(json_encode($cache));
        }
        wp_die();
    }
}
