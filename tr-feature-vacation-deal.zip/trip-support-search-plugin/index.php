<?php
// Slience is golden