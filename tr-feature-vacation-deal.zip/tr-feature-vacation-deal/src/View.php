<?php


namespace Tr\Feature\Vacation;


class View
{
    const BASE_PATH = TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/templates/';
    /**
     * @var
     */
    public $path;

    /**
     * @param $type
     * @return $this
     */
    public function metabox($type)
    {
        $this->path = self::BASE_PATH . 'metaboxes/' . $type . '/';

        return $this;
    }

    /**
     * @return $this
     */
    public function login()
    {
        $this->path = self::BASE_PATH . 'login/';

        return $this;
    }

    /**
     * @return $this
     */
    public function page()
    {
        $this->path = self::BASE_PATH . 'pages/';

        return $this;
    }

    /**
     * @param $file
     */
    public function render($file)
    {
        require $this->path . $file . '.php';
    }
}