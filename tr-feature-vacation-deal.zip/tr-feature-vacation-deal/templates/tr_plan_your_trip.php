<div class="custom-container tr_plan_your_perfect_trip_main_container">
    <div class="container  pt-md-5 pb-md-5">
        <p class="m-0 tr_plan_your_perfect_trip_main_title pb-2">Plan your perfect trip</p>
        <p class="tr_plan_your_perfect_trip_second_title">Travel together with us to benefit from exclusive perks and
            extras
            so you get the most out of your vacation together in paradise!</p>
        <div class="tr_plan_your_perfect_trip_desktop_view d-none d-sm-block">
            <div class="col-md-12 row p-0 m-0">
                <div class="col-md-4 pl-0">
                    <div class="tr_plan_your_perfect_trip_inside_container p-3">
                        <div class="row">
                            <div class="col-8 pl-3 pr-0 tr_plan_your_perfect_trip_each_section_title">5 Star Vacations
                            </div>
                            <div class="col-4 text-right tr_plan_your_perfect_trip_each_section_view_all pt-3">
                                <?php $domain = $_SERVER['SERVER_NAME'] ?>
                                <?php $url_five_star = explode("?", $url_vacations_five_star) ?>
                                <?php if ($domain == 'tripsupport.ca') { ?>
                                    <a href="<?php echo 'https://secure.tripsupport.ca/vacation?' . $url_five_star[1] ?>">View
                                        All</a>
                                <?php } else if ($domain == 'tripsupport.com') { ?>
                                    <a href="<?php echo 'https://secure.tripsupport.com/vacation?' . $url_five_star[1] ?>">View
                                        All</a>
                                <?php } ?>
                                <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.81814 5.47685L5.92914 9.7289C5.60739 10.0532 5.09147 10.0842 4.75281 9.83451C4.41417 9.58484 4.35836 9.08021 4.6357 8.77532L7.40486 5.75042H0.833361C0.373111 5.75042 0 5.41447 0 5.00007C0 4.58565 0.373111 4.24971 0.833361 4.24971H7.40486L4.6357 1.2248C4.35836 0.919924 4.42078 0.422379 4.75281 0.16563C5.0952 -0.0991477 5.65189 -0.0337364 5.92914 0.271211L9.81814 4.52326C10.0713 4.84379 10.0497 5.1669 9.81814 5.47685Z"
                                          fill="#ABABC4"/>
                                </svg>
                            </div>

                            <div class="p-3">
                                <?php $counter = 0 ?>
                                <?php $countOfWinterVacations = 3; ?>
                                <!-- mobile 5 star -->
                                <?php for ($i = 0; $i < 3; $i++): ?>
                                    <div  class="col-12 row p-0 pt-3 pb-3 m-0 <?php if ($counter != $countOfWinterVacations - 1) {
                                        echo 'tr_plan_your_perfect_trip_each_ticket_container';
                                    } ?>">
                                        <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $dataFiveStarVacation[$i]['id'] : 'https://secure.tripsupport.com/vacation/view-details?id='. $dataFiveStarVacation[$i]['id']; ?> "></a>
                                        <div class="col-4 p-0 text-center">
                                            <img src="<?php echo $dataFiveStarVacation[$i]['hotel']['image'] ?>"
                                                         alt=""
                                                         class="img-fluid tr_plan_your_perfect_trip_each_ticket_image">
                                                <div class="bt-block tr_plan_your_perfect_trip_each_ticket_badge text-center p-1 mt-1">
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                         xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                                              fill="#FFB310"/>
                                                    </svg>
                                                    <?php echo $dataFiveStarVacation[$i]['hotel']['star'] ?>
                                                </div>
                                        </div>
                                        <div class="col-8 pr-0 pt-1">
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_info">
                                                <?php echo ucfirst(strtolower($dataFiveStarVacation[$i]['hotel']['meal']['description'])) ?>
                                                |
                                                <?php echo ucfirst(strtolower($dataFiveStarVacation[$i]['hotel']['room']['description'])) ?>
                                            </p>

                                            <a class="mb-2 tr_plan_your_perfect_trip_each_ticket_title">
                                                <?php echo substr($dataFiveStarVacation[$i]['hotel']['name'], 0, 15) ?>
                                            </a>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price">
                                                <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                                                <?php echo $dataFiveStarVacation[$i]['price']['totalPrice'] ?>
                                                <span class="tr_plan_your_perfect_trip_each_ticket_info">per guest</span>
                                            </p>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_date"><?php echo \Carbon\Carbon::parse($dataFiveStarVacation[$i]['departureDate'])->format('M-d-Y') ?>
                                                (<?php echo $dataFiveStarVacation[$i]['duration'] ?> days)</p>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price_info">price
                                                includes
                                                taxes and fees</p>
                                            <div class="tr_plan_your_perfect_trip_each_ticket_location">
                                                <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                                                     xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                                          fill="#007AFF"/>
                                                </svg>
                                                <?php $from = explode(",", $dataFiveStarVacation[$i]['flights'][0]['departure']['cityName']) ?>
                                                <?php $to = explode(",", $dataFiveStarVacation[$i]['flights'][0]['arrival']['cityName']); ?>

                                                <span><?php echo $from[0] ?> to <?php echo $to[0] ?>
                                                    , <?php echo $dataFiveStarVacation[$i]['flights'][0]['arrival']['country'] ?></span>
                                            </div>
                                        </div>
                                        <hr>
                                    </div>
                                    <?php $counter++ ?>
                                <?php endfor ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 pl-0">
                    <div class="tr_plan_your_perfect_trip_inside_container p-3">
                        <div class="row">
                            <div class="col-8 pl-3 pr-0 tr_plan_your_perfect_trip_each_section_title">Winter Vacation
                                Deals
                            </div>
                            <div class="col-4 text-right tr_plan_your_perfect_trip_each_section_view_all pt-3">
                                <?php $url_winter = explode("?", $url_vacations_winter) ?>
                                <?php if ($domain == 'tripsupport.ca') { ?>
                                    <a href="<?php echo 'https://secure.tripsupport.ca/vacation?' . $url_winter[1] ?>">View
                                        All</a>
                                <?php } else if ($domain == 'tripsupport.com') { ?>
                                    <a href="<?php echo 'https://secure.tripsupport.com/vacation?' . $url_winter[1] ?>">View
                                        All</a>
                                <?php } ?>
                                <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.81814 5.47685L5.92914 9.7289C5.60739 10.0532 5.09147 10.0842 4.75281 9.83451C4.41417 9.58484 4.35836 9.08021 4.6357 8.77532L7.40486 5.75042H0.833361C0.373111 5.75042 0 5.41447 0 5.00007C0 4.58565 0.373111 4.24971 0.833361 4.24971H7.40486L4.6357 1.2248C4.35836 0.919924 4.42078 0.422379 4.75281 0.16563C5.0952 -0.0991477 5.65189 -0.0337364 5.92914 0.271211L9.81814 4.52326C10.0713 4.84379 10.0497 5.1669 9.81814 5.47685Z"
                                          fill="#ABABC4"/>
                                </svg>
                            </div>
                            <div class="p-3">
                                <?php $counter = 0 ?>
                                <?php $countOfWinterVacations = 3; ?>

                                <?php for ($j = 0; $j < 3; $j++): ?>
                                    <div class="col-12 row p-0 pt-3 pb-3 m-0 <?php if ($counter != $countOfWinterVacations - 1) {
                                        echo 'tr_plan_your_perfect_trip_each_ticket_container';
                                    } ?>">
                                        <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $dataWinterVacationDeals[$j]['id'] : 'https://secure.tripsupport.com/vacation/view-details?id='. $dataWinterVacationDeals[$j]['id']; ?> "></a>
                                        <div class="col-4 p-0 text-center">
                                            <?php $url_winter = explode("?", $url_vacations_winter) ?>

                                              <img src="<?php echo $dataWinterVacationDeals[$j]['hotel']['image'] ?>"
                                                         alt=""
                                                         class="img-fluid tr_plan_your_perfect_trip_each_ticket_image">

                                                <div class="bt-block tr_plan_your_perfect_trip_each_ticket_badge text-center p-1 mt-1">
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                         xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                                              fill="#FFB310"/>
                                                    </svg>
                                                    <?php echo $dataWinterVacationDeals[$j]['hotel']['star'] ?>
                                                </div>
                                        </div>
                                        <div class="col-8 pr-0 pt-1">
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_info">
                                                <?php echo ucfirst(strtolower($dataWinterVacationDeals[$j]['hotel']['meal']['description'])) ?>
                                                |
                                                <?php echo ucfirst(strtolower($dataWinterVacationDeals[$j]['hotel']['room']['description'])) ?>

                                            </p>
                                             <a class="mb-2 tr_plan_your_perfect_trip_each_ticket_title"><?php echo substr($dataWinterVacationDeals[$j]['hotel']['name'], 0, 15) ?></a>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price">
                                                <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                                                <?php echo $dataWinterVacationDeals[$j]['price']['totalPrice'] ?>
                                                <span class="tr_plan_your_perfect_trip_each_ticket_info">per guest</span>
                                            </p>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_date"><?php echo \Carbon\Carbon::parse($dataWinterVacationDeals[$j]['departureDate'])->format('M-d-Y') ?>
                                                (<?php echo $dataWinterVacationDeals[$j]['duration'] ?> days)</p>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price_info">price
                                                includes
                                                taxes and fees</p>
                                            <div class=" tr_plan_your_perfect_trip_each_ticket_location">
                                                <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                                                     xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                                          fill="#007AFF"/>
                                                </svg>
                                                <?php $from_w = explode(",", $dataWinterVacationDeals[$j]['flights'][0]['departure']['cityName']) ?>
                                                <?php $to_w = explode(",", $dataWinterVacationDeals[$j]['flights'][0]['arrival']['cityName']); ?>

                                                <span><?php echo $from_w[0] ?> to <?php echo $to_w[0] ?>
                                                    , <?php echo $dataWinterVacationDeals[$j]['flights'][0]['arrival']['country'] ?></span>

                                            </div>
                                        </div>
                                        <hr>
                                    </div>
                                    <?php $counter++ ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 pl-0">
                    <div class="tr_plan_your_perfect_trip_inside_container p-3">
                        <div class="row">
                            <div class="col-8 pl-3 pr-0 tr_plan_your_perfect_trip_each_section_title">Vacations Under
                                $1299
                            </div>
                            <div class="col-4 text-right tr_plan_your_perfect_trip_each_section_view_all pt-3">
                                <?php $url_honey = explode("?", $url_vacations_honeymoon) ?>
                                <?php if ($domain == 'tripsupport.ca') { ?>
                                    <a href="<?php echo 'https://secure.tripsupport.ca/vacation?' . $url_honey[1] ?>">View
                                        All</a>

                                <?php } else if ($domain == 'tripsupport.com') { ?>
                                    <a href="<?php echo 'https://secure.tripsupport.com/vacation?' . $url_honey[1] ?>">View
                                        All</a>
                                <?php } ?>
                                <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.81814 5.47685L5.92914 9.7289C5.60739 10.0532 5.09147 10.0842 4.75281 9.83451C4.41417 9.58484 4.35836 9.08021 4.6357 8.77532L7.40486 5.75042H0.833361C0.373111 5.75042 0 5.41447 0 5.00007C0 4.58565 0.373111 4.24971 0.833361 4.24971H7.40486L4.6357 1.2248C4.35836 0.919924 4.42078 0.422379 4.75281 0.16563C5.0952 -0.0991477 5.65189 -0.0337364 5.92914 0.271211L9.81814 4.52326C10.0713 4.84379 10.0497 5.1669 9.81814 5.47685Z"
                                          fill="#ABABC4"/>
                                </svg>
                            </div>
                            <div class="p-3">
                                <?php $counter = 0 ?>
                                <?php $countOfWinterVacations = 3; ?>
                                <?php for ($h = 0; $h < 3; $h++): ?>
                                    <div class="col-12 row p-0 pt-3 pb-3 m-0 <?php if ($counter != $countOfWinterVacations - 1) {
                                        echo 'tr_plan_your_perfect_trip_each_ticket_container';
                                    } ?>">
                                        <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $dataHoneymoonDeals[$h]['id'] : 'https://secure.tripsupport.com/vacation/view-details?id='. $dataHoneymoonDeals[$h]['id']; ?> "></a>
                                        <div class="col-4 p-0 text-center">
                                                <img src="<?php echo $dataHoneymoonDeals[$h]['hotel']['image'] ?>"
                                                         alt=""
                                                         class="img-fluid tr_plan_your_perfect_trip_each_ticket_image">

                                                <div class="bt-block tr_plan_your_perfect_trip_each_ticket_badge text-center p-1 mt-1">
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                         xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                                              fill="#FFB310"/>
                                                    </svg>
                                                    <?php echo $dataHoneymoonDeals[$h]['hotel']['star'] ?>
                                                </div>
                                        </div>
                                        <div class="col-8 pr-0 pt-1">
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_info">
                                                <?php echo ucfirst(strtolower($dataHoneymoonDeals[$h]['hotel']['meal']['description'])) ?>
                                                |
                                                <?php echo ucfirst(strtolower($dataHoneymoonDeals[$h]['hotel']['room']['description'])) ?>

                                            </p>
                                              <a class="mb-2 tr_plan_your_perfect_trip_each_ticket_title">
                                                <?php echo substr($dataHoneymoonDeals[$h]['hotel']['name'], 0, 15) ?>
                                            </a>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price">
                                                <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                                                <?php echo $dataHoneymoonDeals[$h]['price']['totalPrice'] ?>
                                                <span class="tr_plan_your_perfect_trip_each_ticket_info">per guest</span>
                                            </p>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_date"><?php echo \Carbon\Carbon::parse($dataHoneymoonDeals[$h]['departureDate'])->format('M-d-Y') ?>
                                                (<?php echo $dataHoneymoonDeals[$h]['duration'] ?> days)</p>
                                            <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price_info">price
                                                includes
                                                taxes and fees</p>
                                            <div class=" tr_plan_your_perfect_trip_each_ticket_location">
                                                <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                                                     xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                                          fill="#007AFF"/>
                                                </svg>
                                                <?php $from_h = explode(",", $dataHoneymoonDeals[$h]['flights'][0]['departure']['cityName']) ?>
                                                <?php $to_h = explode(",", $dataHoneymoonDeals[$h]['flights'][0]['arrival']['cityName']); ?>

                                                <span><?php echo $from_h[0] ?> to <?php echo $to_h[0] ?>
                                                    , <?php echo $dataHoneymoonDeals[$h]['flights'][0]['arrival']['country'] ?></span>

                                            </div>
                                        </div>
                                        <hr>
                                    </div>
                                    <?php $counter++ ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tr_plan_your_perfect_trip_mobile_view d-block d-sm-none">
            <div class="swiper-container tr_plan-your-trip-btns-container pt-2 pb-2">
                <div class="swiper-wrapper">
                    <span id="europe"
                          class="swiper-slide tr-plan-your-trip-btn tr-plan-your-trip-star-btn tr-plan-your-trip-btn-active">5 Star Vacations</span>
                    <span id="asia" class="swiper-slide tr-plan-your-trip-btn tr-plan-your-trip-honeymoon-btn">Vacations Under $1299</span>
                    <span id="united states" class="swiper-slide tr-plan-your-trip-btn tr-plan-your-trip-winter-btn">Winter Vacation Deals</span>
                </div>
                <div class="col-md-12 p-0">

                    <!-- mobile 5 star -->
                    <?php for ($i = 0; $i < 5; $i++): ?>
                        <div class="col-12 row p-0 pt-3 pb-3 m-0 tr-plan-your-trip-mobile-container tr-plan-your-trip-mobile-container-star">
                            <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $dataFiveStarVacation[$i]['id'] : 'https://secure.tripsupport.com/vacation/view-details?id='. $dataFiveStarVacation[$i]['id']; ?> "></a>
                            <div class="col-4 p-0 text-center">
                                <img src="<?php echo $dataFiveStarVacation[$i]['hotel']['image'] ?>"
                                     alt="" class="w-100 img-fluid tr_plan_your_perfect_trip_each_ticket_image">
                                <div class="bt-block tr_plan_your_perfect_trip_each_ticket_badge text-center p-1 mt-1">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                              fill="#FFB310"/>
                                    </svg>
                                    <?php echo $dataFiveStarVacation[$i]['hotel']['star'] ?>
                                </div>
                            </div>
                            <div class="col-8 pr-0 pt-1">
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_info">
                                    <?php echo ucfirst(strtolower($dataFiveStarVacation[$i]['hotel']['meal']['description'])) ?>
                                    |
                                    <?php echo ucfirst(strtolower($dataFiveStarVacation[$i]['hotel']['room']['description'])) ?>
                                </p>
                                 <a class="mb-2 tr_plan_your_perfect_trip_each_ticket_title">
                                    <?php echo substr($dataFiveStarVacation[$i]['hotel']['name'], 0, 10) ?>
                                </a>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price">
                                    <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                                    <?php echo $dataFiveStarVacation[$i]['price']['totalPrice'] ?>
                                    <span class="tr_plan_your_perfect_trip_each_ticket_info">per guest</span>

                                </p>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_date"><?php echo \Carbon\Carbon::parse($dataFiveStarVacation[$i]['departureDate'])->format('M-d-Y') ?>
                                    (<?php echo $dataFiveStarVacation[$i]['duration'] ?> days)</p>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price_info">price includes
                                    taxes and fees</p>
                                <div class="tr_plan_your_perfect_trip_each_ticket_location">
                                    <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                              fill="#007AFF"/>
                                    </svg>
                                    <?php $from = explode(",", $dataFiveStarVacation[$i]['flights'][0]['departure']['cityName']) ?>
                                    <?php $to = explode(",", $dataFiveStarVacation[$i]['flights'][0]['arrival']['cityName']); ?>

                                    <span><?php echo $from[0] ?> to <?php echo $to[0] ?>
                                        , <?php echo $dataFiveStarVacation[$i]['flights'][0]['arrival']['country'] ?></span>

                                </div>
                            </div>
                            <hr>
                        </div>
                    <?php endfor; ?>

                    <!-- mobile honeymoon -->
                    <?php for ($h = 0; $h < 5; $h++): ?>
                        <div class="col-12 d-none row p-0 pt-3 pb-3 m-0 tr-plan-your-trip-mobile-container tr-plan-your-trip-mobile-container-honeymoon">
                            <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $dataHoneymoonDeals[$h]['id'] : 'https://secure.tripsupport.com/vacation/view-details?id='. $dataHoneymoonDeals[$h]['id']; ?> "></a>
                            <div class="col-4 p-0 text-center">
                                <img src="<?php echo $dataHoneymoonDeals[$h]['hotel']['image'] ?>"
                                     alt="" class="w-100 img-fluid tr_plan_your_perfect_trip_each_ticket_image">
                                <div class="bt-block tr_plan_your_perfect_trip_each_ticket_badge text-center p-1 mt-1">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                              fill="#FFB310"/>
                                    </svg>
                                    <?php echo $dataHoneymoonDeals[$h]['hotel']['star'] ?>
                                </div>
                            </div>
                            <div class="col-8 pr-0 pt-1">
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_info">
                                    <?php echo ucfirst(strtolower($dataHoneymoonDeals[$h]['hotel']['meal']['description'])) ?>
                                    |
                                    <?php echo ucfirst(strtolower($dataHoneymoonDeals[$h]['hotel']['room']['description'])) ?>

                                </p>
                               <a class="mb-2 tr_plan_your_perfect_trip_each_ticket_title">
                                    <?php echo substr($dataHoneymoonDeals[$h]['hotel']['name'], 0, 10) ?>
                                </a>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price">
                                    <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                                    <?php echo $dataHoneymoonDeals[$h]['price']['totalPrice'] ?>
                                    <span class="tr_plan_your_perfect_trip_each_ticket_info">per guest</span>

                                </p>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_date"><?php echo \Carbon\Carbon::parse($dataHoneymoonDeals[$h]['departureDate'])->format('M-d-Y') ?>
                                    (<?php echo $dataHoneymoonDeals[$h]['duration'] ?> days)</p>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price_info">price includes
                                    taxes and fees</p>
                                <div class="tr_plan_your_perfect_trip_each_ticket_location">
                                    <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                              fill="#007AFF"/>
                                    </svg>
                                    <?php $from_h = explode(",", $dataHoneymoonDeals[$h]['flights'][0]['departure']['cityName']) ?>
                                    <?php $to_h = explode(",", $dataHoneymoonDeals[$h]['flights'][0]['arrival']['cityName']); ?>

                                    <span><?php echo $from_h[0] ?> to <?php echo $to_h[0] ?>
                                        , <?php echo $dataHoneymoonDeals[$h]['flights'][0]['arrival']['country'] ?></span>

                                </div>
                            </div>
                            <hr>
                        </div>
                    <?php endfor; ?>

                    <!-- mobile winter -->
                    <?php for ($j = 0; $j < 5; $j++): ?>
                        <div class="col-12 d-none row p-0 pt-3 pb-3 m-0 tr-plan-your-trip-mobile-container tr-plan-your-trip-mobile-container-winter">
                            <a class="tr-link-box" href="<?php echo ($domain == 'tripsupport.ca') ? 'https://secure.tripsupport.ca/vacation/view-details?id='. $dataWinterVacationDeals[$j]['id'] : 'https://secure.tripsupport.com/vacation/view-details?id='. $dataWinterVacationDeals[$j]['id']; ?> "></a>

                            <div class="col-4 p-0 text-center">
                                <img src="<?php echo $dataWinterVacationDeals[$j]['hotel']['image'] ?>"
                                     alt="" class="w-100 img-fluid tr_plan_your_perfect_trip_each_ticket_image">
                                <div class="bt-block tr_plan_your_perfect_trip_each_ticket_badge text-center p-1 mt-1">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                              fill="#FFB310"/>
                                    </svg>
                                    <?php echo $dataWinterVacationDeals[$j]['hotel']['star'] ?>
                                </div>
                            </div>
                            <div class="col-8 pr-0 pt-1">
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_info">
                                    <?php echo ucfirst(strtolower($dataWinterVacationDeals[$j]['hotel']['meal']['description'])) ?>
                                    |
                                    <?php echo ucfirst(strtolower($dataWinterVacationDeals[$j]['hotel']['room']['description'])) ?>

                                </p>
                                 <a class="mb-2 tr_plan_your_perfect_trip_each_ticket_title">
                                    <?php echo substr($dataWinterVacationDeals[$j]['hotel']['name'], 0, 10) ?>
                                </a>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price">
                                    <?php echo ($domain == 'tripsupport.ca') ? 'CA $' : '$'; ?>
                                    <?php echo $dataWinterVacationDeals[$j]['price']['totalPrice'] ?>
                                    <span class="tr_plan_your_perfect_trip_each_ticket_info">per guest</span>
                                </p>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_date"><?php echo \Carbon\Carbon::parse($dataWinterVacationDeals[$j]['departureDate'])->format('M-d-Y') ?>
                                    (<?php echo $dataWinterVacationDeals[$j]['duration'] ?> days)</p>
                                <p class="mb-1 tr_plan_your_perfect_trip_each_ticket_price_info">price includes
                                    taxes and fees</p>
                                <div class="tr_plan_your_perfect_trip_each_ticket_location">
                                    <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                              fill="#007AFF"/>
                                    </svg>
                                    <?php $from_w = explode(",", $dataWinterVacationDeals[$j]['flights'][0]['departure']['cityName']) ?>
                                    <?php $to_w = explode(",", $dataWinterVacationDeals[$j]['flights'][0]['arrival']['cityName']); ?>

                                    <span><?php echo $from_w[0] ?> to <?php echo $to_w[0] ?>
                                        , <?php echo $dataWinterVacationDeals[$j]['flights'][0]['arrival']['country'] ?></span>

                                </div>
                            </div>
                            <hr>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<style>

    .tr_plan_your_perfect_trip_each_ticket_container {
        border-bottom: 1px dashed #ABABC4;
    }

    .tr_plan_your_perfect_trip_each_ticket_badge {
        background: rgba(255, 179, 16, 0.1);
        border-radius: 4px;
    }

    .tr_plan_your_perfect_trip_each_ticket_image {
        width: 100%;
        border: 1px solid rgba(68, 69, 96, 0.1);
        box-sizing: border-box;
        border-radius: 4px;
        height: 6rem;
    }

    .tr_plan_your_perfect_trip_each_ticket_location {
        font-style: normal;
        font-weight: 500;
        font-size: 12px;
        line-height: 14px;
        letter-spacing: -0.02em;
        color: #007AFF;
        font-family: Cera-Pro-Medium;
    }

    .tr_plan_your_perfect_trip_each_ticket_price_info {
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 17px;
        letter-spacing: -0.03em;
        color: #66678b;
        font-family: "Cera PRO";
        padding-bottom: 0.2rem;
    }

    .tr_plan_your_perfect_trip_each_ticket_date {
        font-style: normal;
        font-weight: 500;
        font-size: 14px;
        line-height: 17px;
        letter-spacing: -0.03em;
        color: #0C0D25;
        font-family: "Cera PRO";
    }

    .tr_plan_your_perfect_trip_each_ticket_price {
        font-style: normal;
        font-weight: bold;
        font-size: 18px;
        line-height: 22px;
        letter-spacing: -0.03em;
        color: #0C0D25;
        font-family: Cera-Pro-Bold;
    }

    .tr_plan_your_perfect_trip_each_ticket_info {
        font-style: normal;
        font-weight: normal;
        font-size: 10px;
        line-height: 100%;
        letter-spacing: -0.02em;
        text-transform: capitalize;
        color: #66678F;
        font-family: "Cera PRO";
    }

    .tr_plan_your_perfect_trip_each_ticket_title {
        font-style: normal;
        font-weight: 500;
        font-size: 16px;
        line-height: 22px;
        letter-spacing: -0.01em;
        color: #0C0D25;
        font-family: "Cera PRO";

    }

    .tr_plan_your_perfect_trip_each_section_title {
        font-style: normal;
        font-weight: 500;
        font-family: "Cera PRO";
        font-size: 20px;
        line-height: 100%;
        letter-spacing: -0.02em;
        color: #0C0D25
    }

    .tr_plan_your_perfect_trip_each_section_view_all, .tr_plan_your_perfect_trip_each_section_view_all a {
        font-style: normal;
        font-weight: normal;
        font-size: 14px;
        line-height: 100%;
        letter-spacing: -0.02em;
        color: #ABABC4;
        font-family: "Cera PRO";
    }

    .tr_plan_your_perfect_trip_each_section_view_all a:hover {
        text-decoration: none;
        color: #ABABC4;
    }

    .tr_plan_your_perfect_trip_inside_container {
        background-color: #fff;
        border: 1px solid rgba(102, 103, 143, 0.1);
        box-shadow: 0px 2px 2px rgba(102, 103, 143, 0.04);
        border-radius: 8px;
    }

    .tr_plan_your_perfect_trip_main_title {
        color: #0C0D25;
        letter-spacing: -0.02em;
        font-style: normal;
        font-weight: normal;
        font-size: 26px;
        line-height: 100%;
    }

    .tr_plan_your_perfect_trip_second_title {
        color: #66678F;
        letter-spacing: -0.02em;
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 24px;
    }

    .tr_plan_your_perfect_trip_main_container {
        border-radius: 8px;
        background-color: #fcfcfd;
    }

    .tr-plan-your-trip-btn {
        background-color: #e8e8ef;
        border-radius: 18px;
        color: #66678F;
        padding-left: 5px;
        padding-right: 5px;
        width: auto !important;
        cursor: pointer;
    }

    .tr-plan-your-trip-btn-active {
        background: #66678F !important;
        border-radius: 18px !important;
        padding-left: 10px !important;
        padding-right: 10px !important;
        color: #fff !important;
        cursor: pointer;
    }

    .tr_plan_your_perfect_trip_each_ticket_title:hover {
        text-decoration: none !important;
    }
    .tr-link-box{
        display: block;
        width: 100%;
        height: 90%;
        position: absolute;
        z-index: 1000;
    }
</style>

<script>
    var swiperPlanYourTripBtnsContainer = new Swiper('.tr_plan-your-trip-btns-container', {
        breakpoints: {
            960: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            720: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            540: {
                slidesPerView: 6,
                spaceBetween: 10
            },
            320: {
                slidesPerView: 2,
                spaceBetween: 10
            },
        }
    });
</script>

<script !src="">
    var planYourTripBtns = document.querySelectorAll('.tr-plan-your-trip-btn');
    var planYourTripMobileViewContainers = document.querySelectorAll('.tr-plan-your-trip-mobile-container');
    var planYourTripMobileViewWinterContainers = document.querySelectorAll('.tr-plan-your-trip-mobile-container-winter');
    var planYourTripMobileViewStarContainers = document.querySelectorAll('.tr-plan-your-trip-mobile-container-star');
    var planYourTripMobileViewHoneymoonContainers = document.querySelectorAll('.tr-plan-your-trip-mobile-container-honeymoon');
    console.log(planYourTripMobileViewHoneymoonContainers);

    planYourTripBtns.forEach(planYourTripBtn => {
        planYourTripBtn.addEventListener('click', () => {
            planYourTripBtns.forEach(rmvActive => {
                rmvActive.classList.remove('tr-plan-your-trip-btn-active');
            });
            planYourTripBtn.classList.add('tr-plan-your-trip-btn-active');
            if (planYourTripBtn.classList.contains('tr-plan-your-trip-star-btn')) {
                changeVisibilityForMobileContainers('tr-plan-your-trip-mobile-container-star');
            }
            if (planYourTripBtn.classList.contains('tr-plan-your-trip-honeymoon-btn')) {
                changeVisibilityForMobileContainers('tr-plan-your-trip-mobile-container-honeymoon');
            }

            if (planYourTripBtn.classList.contains('tr-plan-your-trip-winter-btn')) {
                changeVisibilityForMobileContainers('tr-plan-your-trip-mobile-container-winter');
            }
        });
    });

    function changeVisibilityForMobileContainers(className) {
        planYourTripMobileViewContainers.forEach(planYourTripMobileViewContainer => {
            if (planYourTripMobileViewContainer.classList.contains(className)) {
                planYourTripMobileViewContainer.classList.remove('d-none');
            } else {
                planYourTripMobileViewContainer.classList.add('d-none');
            }
        })
    }
</script>