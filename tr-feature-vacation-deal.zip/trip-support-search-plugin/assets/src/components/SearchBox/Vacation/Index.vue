<style scoped>
.ts-field-wrapper {
  display: flex;
  align-items: center;
}
.ts-search-field-wrapper {
  flex: 0 0 70%;
  display: flex;
}
.ts-duration-wrapper {
  flex: 0 0 30%;
  display: flex;
  align-items: center;
}
.ts-date-picker,
.ts-duration {
  flex: 0 0 50%;
}
.ts-duration ::v-deep .ts-menu {
  top: 80px;
  right: 0;
}
.ts-origin,
.ts-destination {
  position: relative;
  width: 100%;
}
.ts-airplane-icon {
  position: absolute;
  left: 9px;
  bottom: 13px;
}
.ts-action-wrapper {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 37px;
  padding-bottom: 32px;
}
.ts-checkbox-wrapper {
  display: flex;
  align-items: center;
}
.ts-checkbox-wrapper > div {
  display: flex;
  align-items: center;
  margin-right: 19px;
}
.ts-checkbox-wrapper > div label {
  font-weight: 400;
  color: #66678f;
  font-size: 14px;
}
.ts-checkbox-item {
  display: flex;
  cursor: pointer;
  position: relative;
  align-items: center;
  margin-bottom: 0 !important;
}
.ts-checkbox-item > span {
  font-weight: 400;
  color: #66678f;
  font-size: 14px;
  margin-left: 8px;
}
.ts-checkbox-item > input {
  height: 18px;
  width: 18px;
  -webkit-appearance: none;
  -moz-appearance: none;
  -o-appearance: none;
  appearance: none;
  border: 1px solid rgba(171, 171, 196, 0.6);
  border-radius: 4px;
  outline: none;
  transition-duration: 0.3s;
  background-color: #fff;
  cursor: pointer;
}
.ts-checkbox-item > input:checked {
  border: 1px solid #ed1b2e;
  background-color: #ed1b2e;
}
.ts-checkbox-item > input:checked + span::before {
  content: "\2713";
  display: block;
  text-align: center;
  color: #fff;
  position: absolute;
  left: 5px;
  top: 1px;
}
.ts-button-wrapper {
  display: flex;
  align-items: center;
}
.ts-header-component {
  padding: 32px 0 24px;
  display: flex;
  justify-content: space-between;
}
.ts-title-component {
  font-size: 18px;
  font-weight: 400;
  color: #0c0d25;
}
.ts-other-components {
  display: flex;
  align-items: center;
}
.ts-passengers-component {
  padding-right: 24px;
}
.ts-airfare-component {
  display: flex;
  justify-content: flex-end;
}

@media only screen and (max-width: 768px) {
  ::v-deep .ts-icon-passenger {
    display: none;
  }
  .ts-passengers-component {
    padding-right: 8px;
  }
  .ts-header-component {
    display: block;
    padding: 20px 0 16px;
  }
  .ts-title-component {
    font-size: 16px;
    margin-bottom: 20px;
  }
  .ts-field-wrapper {
    display: block;
    position: relative;
  }
  .ts-action-wrapper {
    display: block;
    padding-top: 16px;
    padding-bottom: 27px;
  }
  .ts-button-wrapper {
    display: block;
  }
  .ts-checkbox-wrapper {
    display: none;
  }
  ::v-deep .vue-daterange-picker {
    min-width: 140px;
  }
  ::v-deep .ts-picker-wrapper > div {
    width: unset !important;
  }
  .ts-search-field-wrapper {
    display: block;
    width: 100%;
    flex: unset;
  }
  .ts-duration-wrapper {
    display: block;
    width: 100%;
    flex: unset;
  }
}
</style>
<style lang="scss" scoped>
.item {
  display: flex;
  width: 100%;
  align-items: center;
  &.indent-1 {
    padding-left: 16px;
  }
  &-icon {
    margin-right: 8px;
    display: flex;
  }
  &-text {
    color: #ababc4;
  }
  svg {
    fill: #ababc4;
  }
  &:hover,
  &.active {
    .item-text {
      color: #0c0d25;
    }
    svg {
      fill: #007aff;
    }
  }
}
</style>
<template>
  <section>
    <div class="ts-header-component">
      <div class="ts-title-component">Book your vacation now, pay later!</div>
      <div class="ts-other-components">
        <div class="ts-passengers-component">
          <Travellers @NumberOfPassangers="passanger" :rooms="NumberOfRooms" />
        </div>
        <div class="ts-airfare-component">
          <Rooms
            @NumberOfRooms="rooms"
            :children="Children"
            :error="roomsError"
          />
        </div>
      </div>
    </div>
    <div class="ts-field-wrapper">
      <div class="ts-search-field-wrapper">
        <div class="ts-origin">
          <Autocomplete
            ref="FromAutocomplete"
            v-model="getFromSearch"
            :items="FromsItemsDisplay"
            :placeholder="$t('VACATION.Departing_From')"
            :localStorage="localData.From"
            :from="true"
            mode="vacation"
            :userLocation="userLocation"
          >
            <template #item="{ item, active }">
              <div class="item" :class="{ active: active }">
                <span class="item-icon">
                  <svg
                    v-if="item.type == 'Hotel'"
                    height="18"
                    viewBox="0 0 640 512"
                    width="18"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <g _ngcontent-uhw-c21="">
                      <g
                        _ngcontent-uhw-c21=""
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          _ngcontent-uhw-c21=""
                          d="m347.829 38.679h-76.829v-38.679h-30v38.679h-76.829v42.815h183.658z"
                          data-original="#000000"
                        ></path>
                        <path
                          _ngcontent-uhw-c21=""
                          d="m392.647 482v-370.506h-273.294v370.506h-68.065v30h409.424v-30zm-153.458-332.885h33.622v30h-33.622zm0 67.62h33.622v30h-33.622zm0 67.621h33.622v30h-33.622zm-84.403-135.241h33.622v30h-33.622zm0 67.62h33.622v30h-33.622zm0 67.621h33.622v30h-33.622zm200.618 197.644h-30v-96.485h-54.404v96.485h-30v-96.485h-54.404v96.485h-30v-126.485h198.808zm1.811-167.644h-33.622v-30h33.622zm0-67.621h-33.622v-30h33.622zm0-67.62h-33.622v-30h33.622z"
                          data-original="#000000"
                        ></path>
                      </g>
                    </g>
                  </svg>
                  <svg
                    v-else
                    width="20"
                    height="20"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="20" height="20" fill="white" />
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      d="M24 8C27.1826 8 30.2348 9.26476 32.4853 11.516C34.7357 13.7673 36 16.8207 36 20.0045C36 24.4062 34.5333 25.8734 26.5333 38.5449C26.275 38.9877 25.9051 39.355 25.4606 39.6103C25.0161 39.8657 24.5125 40 24 40C23.4875 40 22.9839 39.8657 22.5394 39.6103C22.0949 39.355 21.725 38.9877 21.4667 38.5449C13.4667 25.8734 12 24.4062 12 20.0045C12 16.8207 13.2643 13.7673 15.5147 11.516C17.7652 9.26476 20.8174 8 24 8V8ZM24 24.5396C25.1316 24.5396 26.2168 24.0899 27.017 23.2894C27.8171 22.489 28.2667 21.4033 28.2667 20.2713C28.2667 19.1393 27.8171 18.0536 27.017 17.2532C26.2168 16.4527 25.1316 16.003 24 16.003C22.8684 16.003 21.7832 16.4527 20.983 17.2532C20.1829 18.0536 19.7333 19.1393 19.7333 20.2713C19.7333 21.4033 20.1829 22.489 20.983 23.2894C21.7832 24.0899 22.8684 24.5396 24 24.5396Z"
                    />
                  </svg>

                  <!-- <svg
                    v-else
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 18 18"
                    fill="none"
                  >
                    <path
                      d="M16.808 3.19729C16.5399 3.46359 15.2015 4.93888 13.9124 6.21937C13.9124 17.0109 14.2682 16.2008 12.4569 18L11.0211 11.9598L9.55414 10.5026C5.66686 14.3632 6.25266 11.3737 6.25266 15.0695C6.25636 15.8766 5.91536 16.4075 5.42637 16.8932L4.06597 13.8389L0.990894 12.4876C2.00029 11.4859 2.55178 11.6669 4.93967 11.6669C5.75236 10.0003 6.75696 9.28595 7.54295 8.50496L6.07896 7.05087L0 5.62688C1.71529 3.92299 0.663795 4.23739 11.8395 4.23739C13.1355 2.95009 14.5277 1.4671 14.7969 1.1997C15.5714 0.430509 17.5986 -0.235987 17.9174 0.0806108C18.2361 0.397209 17.5825 2.428 16.808 3.19729ZM15.4406 7.44417L14.6307 8.24686V10.6048C16.3815 8.84986 16.827 8.82816 15.4406 7.44417ZM10.6281 2.6519C9.26034 1.2867 9.36394 1.5691 7.41295 3.50889H9.77544L10.6281 2.6519Z"
                    />
                  </svg> -->
                </span>
                <span class="item-text">{{ item.name }}</span>
              </div>
            </template>
          </Autocomplete>
        </div>
        <div class="ts-destination">
          <Autocomplete
            ref="ToAutocomplete"
            v-model="getToSearch"
            :items="toItemsDisplay"
            :placeholder="$t('VACATION.Going_To')"
            :localStorage="localData.To"
            mode="vacationDestination"
          >
            <!-- :class="{ active: active, 'indent-1': item.type == 'City' }" -->
            <template #item="{ item, active }">
              <div class="item" :class="{ active: active, 'indent-1': item.type == 'City' }">
                <span class="item-icon">
                  <svg
                    v-if="item.type == 'Hotel'"
                    height="18"
                    viewBox="0 0 640 512"
                    width="18"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <g _ngcontent-uhw-c21="">
                      <g
                        _ngcontent-uhw-c21=""
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          _ngcontent-uhw-c21=""
                          d="m347.829 38.679h-76.829v-38.679h-30v38.679h-76.829v42.815h183.658z"
                          data-original="#000000"
                        ></path>
                        <path
                          _ngcontent-uhw-c21=""
                          d="m392.647 482v-370.506h-273.294v370.506h-68.065v30h409.424v-30zm-153.458-332.885h33.622v30h-33.622zm0 67.62h33.622v30h-33.622zm0 67.621h33.622v30h-33.622zm-84.403-135.241h33.622v30h-33.622zm0 67.62h33.622v30h-33.622zm0 67.621h33.622v30h-33.622zm200.618 197.644h-30v-96.485h-54.404v96.485h-30v-96.485h-54.404v96.485h-30v-126.485h198.808zm1.811-167.644h-33.622v-30h33.622zm0-67.621h-33.622v-30h33.622zm0-67.62h-33.622v-30h33.622z"
                          data-original="#000000"
                        ></path>
                      </g>
                    </g>
                  </svg>
                  <!-- <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 18 18"
                    v-else-if="item.type == 'City'"
                  >
                    <path
                      d="M10.293 5.005L7.61099 2.323C7.52241 2.23482 7.47007 2.11665 7.46429 1.99178C7.45851 1.86692 7.49971 1.74442 7.57977 1.64842C7.65983 1.55243 7.77294 1.4899 7.89681 1.47316C8.02068 1.45643 8.14633 1.4867 8.24899 1.558L8.31799 1.615L11.884 5.18501L11.934 5.255L11.961 5.311L11.984 5.379L11.989 5.399C11.9965 5.43417 12.0002 5.47005 12 5.506L11.995 5.432L11.998 5.46301V5.54801L11.983 5.634L11.963 5.697L11.923 5.773L11.868 5.84301L8.31799 9.39501C8.2298 9.48359 8.11163 9.53593 7.98677 9.54171C7.8619 9.54749 7.7394 9.50629 7.64341 9.42623C7.54741 9.34617 7.48489 9.23306 7.46815 9.10919C7.45142 8.98532 7.48168 8.85967 7.55299 8.757L7.61099 8.68701L10.293 6.006H5.99999C2.47799 6.006 0.114991 4.03 0.00399113 1.213L-8.58307e-06 1.005C-8.58307e-06 0.872397 0.0526695 0.74522 0.146438 0.651451C0.240206 0.557683 0.367383 0.505005 0.499991 0.505005C0.6326 0.505005 0.759777 0.557683 0.853545 0.651451C0.947313 0.74522 0.999991 0.872397 0.999991 1.005C0.999991 3.278 2.80699 4.909 5.73799 5L5.99999 5.005H10.293L7.61099 2.323L10.293 5.005Z"
                      fill="#007AFF"
                    />
                  </svg> -->
                  <svg
                    v-else
                    width="20"
                    height="20"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="20" height="20" fill="white" />
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      d="M24 8C27.1826 8 30.2348 9.26476 32.4853 11.516C34.7357 13.7673 36 16.8207 36 20.0045C36 24.4062 34.5333 25.8734 26.5333 38.5449C26.275 38.9877 25.9051 39.355 25.4606 39.6103C25.0161 39.8657 24.5125 40 24 40C23.4875 40 22.9839 39.8657 22.5394 39.6103C22.0949 39.355 21.725 38.9877 21.4667 38.5449C13.4667 25.8734 12 24.4062 12 20.0045C12 16.8207 13.2643 13.7673 15.5147 11.516C17.7652 9.26476 20.8174 8 24 8V8ZM24 24.5396C25.1316 24.5396 26.2168 24.0899 27.017 23.2894C27.8171 22.489 28.2667 21.4033 28.2667 20.2713C28.2667 19.1393 27.8171 18.0536 27.017 17.2532C26.2168 16.4527 25.1316 16.003 24 16.003C22.8684 16.003 21.7832 16.4527 20.983 17.2532C20.1829 18.0536 19.7333 19.1393 19.7333 20.2713C19.7333 21.4033 20.1829 22.489 20.983 23.2894C21.7832 24.0899 22.8684 24.5396 24 24.5396Z"
                    />
                  </svg>

                  <!-- <svg
                    v-else
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 18 18"
                    fill="none"
                  >
                    <path
                      d="M16.808 3.19729C16.5399 3.46359 15.2015 4.93888 13.9124 6.21937C13.9124 17.0109 14.2682 16.2008 12.4569 18L11.0211 11.9598L9.55414 10.5026C5.66686 14.3632 6.25266 11.3737 6.25266 15.0695C6.25636 15.8766 5.91536 16.4075 5.42637 16.8932L4.06597 13.8389L0.990894 12.4876C2.00029 11.4859 2.55178 11.6669 4.93967 11.6669C5.75236 10.0003 6.75696 9.28595 7.54295 8.50496L6.07896 7.05087L0 5.62688C1.71529 3.92299 0.663795 4.23739 11.8395 4.23739C13.1355 2.95009 14.5277 1.4671 14.7969 1.1997C15.5714 0.430509 17.5986 -0.235987 17.9174 0.0806108C18.2361 0.397209 17.5825 2.428 16.808 3.19729ZM15.4406 7.44417L14.6307 8.24686V10.6048C16.3815 8.84986 16.827 8.82816 15.4406 7.44417ZM10.6281 2.6519C9.26034 1.2867 9.36394 1.5691 7.41295 3.50889H9.77544L10.6281 2.6519Z"
                    />
                  </svg> -->
                </span>
                <span class="item-text">
                  <template v-if="item.countryName">
                    {{ item.name }}, {{ item.countryName }}
                  </template>
                  <template v-else>{{ item.name }}</template>
                </span>
              </div>
            </template>
            <template #no-result>
              <span class="pl-3">
                {{ $t("VACATION.not_found") }}
              </span>
            </template>
          </Autocomplete>
        </div>
      </div>
      <div class="ts-duration-wrapper">
        <div class="ts-date-picker">
          <NewDatePicker
            ref="vacationDatePicker"
            @RangeSelectedDate="getRangeDate"
            @clearDate="clearDate"
            :singleDatePicker="true"
            :lastDate="lastDate"
            title="Departure"
            :placeHolder="{
              origin: 'Departure Date',
            }"
          />
        </div>
        <div class="ts-duration">
          <Duration
            :availableDurations="getToSearch && getToSearch.durations"
            @Durations="getDurations"
          />
        </div>
      </div>
    </div>
    <div class="ts-action-wrapper">
      <div class="ts-checkbox-wrapper">
        <div>
          <label class="ts-checkbox-item">
            <input type="checkbox" v-model="AllInclusive" />
            <span>All-Inclusive Only</span>
          </label>
        </div>
      </div>
      <div class="ts-button-wrapper">
        <SearchButton
          :buttonText="`${$t('VACATION.Search_Vacations')}`"
          @search="save"
          :activeButton="disabledButton"
        />
      </div>
    </div>
    <Toast v-model="showDialog" :toast="toast" />
  </section>
</template>

<script>
import Rooms from "./Rooms.vue";
import Travellers from "./Travellers.vue";
import Duration from "./Duration.vue";
import Passengers from "./../Common/Passengers.vue";
import AirfareType from "./../Common/AirfareType.vue";
import moment from "moment";

export default {
  components: {
    Rooms,
    Travellers,
    Duration,
    Passengers,
    AirfareType,
  },
  data() {
    return {
      toast: {
        toastText: "",
        color: "red",
      },
      showDialog: false,
      From: {},
      To: {},
      AllInclusive: false,
      FromsItems: [],
      FromsItemsDisplay: [],
      toItems: [],
      toItemsDisplay: [],
      NumberOfRooms: 1,
      NumberOfPassangers: 2,
      Adults: 2,
      ChildrenAges: [],
      DepartureDate: null,
      lastDate: null,
      Children: 0,
      Durations: "7,8",
      roomsError: false,
      selectedMultiple: [],
      previousSelectionTravellers: {},
      getFromSearch: {},
      firstTime: true,
      getToSearch: {},
      localData: {},
      userLocation: {},
    };
  },
  async mounted() {
    try {
      let { data } = await this.axios.get(
        `https://tripsupport.ca/wp-json/trip-support-endpoints/v1/user/geolocation`
      );

      await this.axios
        .get(`https://vacationapi.tripsupport.ca/api/Resource/GetDepartures`)
        .then((response) => {
          this.FromsItems = response.data.data;
          this.FromsItemsDisplay = response.data.data;
        });
      let userLocation = data.data.city.toLowerCase();
      this.querySearch(userLocation, this.FromsItems).then((res) => {
        if (res.length) {
          this.userLocation = res[0];
          this.$cookie.set(
            "userLocation",
            JSON.stringify({
              ct: res[0].name,
              ac: res[0].codes,
            })
          );
          this.From = res[0];
        } else {
          this.userLocation = res;
          this.$cookie.set(
            "userLocation",
            JSON.stringify({
              ct: "Toronto",
              ac: "YYZ",
            })
          );
          this.From = { codes: "YYZ", name: "Toronto" };
        }
      });
    } catch (e) {
      console.log(e);
    }

    let getLastVacationBooking = localStorage.getItem("lastVacationBooking");
    if (!getLastVacationBooking) {
      this.previousSelectionTravellers = {
        adults: 2,
        children: 0,
        childrenAges: [],
      };
      return;
    }
    this.localData = JSON.parse(getLastVacationBooking);
    this.From = this.localData.From;
    this.To = this.localData.To;
    this.NumberOfRooms = this.localData.NumberOfRooms;
    if (this.localData.date) {
      this.lastDate = this.localData.date;
      this.DepartureDate = this.changeFormat(this.localData.date.startDate);
    }
    if (this.localData.multiple.length) {
      this.selectedMultiple = this.localData.multiple;
    }
    if (this.localData.TravellersData) {
      let childAgesArray = [];
      this.localData.TravellersData.childrenAges.forEach((element) => {
        childAgesArray.push(element.child);
      });
      this.Adults = this.localData.TravellersData.adults;
      this.Children = this.localData.TravellersData.children;
      this.ChildrenAges = childAgesArray;
    }
  },
  watch: {
    getFromSearch: {
      handler: function (val) {
        this.From = val;
        this.querySearch(val, this.FromsItems).then((res) => {
          this.FromsItemsDisplay = res;
        });
        if (val.codes) {
          this.changeDestination(val.codes).then((res) => {
            this.toItems = res;
            this.toItemsDisplay = res.slice(0, 50);
            if (!this.isMobile && !this.firstTime) {
              this.$refs.FromAutocomplete.showMenu = false;
              this.$refs.ToAutocomplete.$el.querySelector("input").focus();
            }
            this.firstTime = false;
          });
        }
        if (
          this.isMobile &&
          val.name &&
          this.$refs.FromAutocomplete.openMobileDialog == true
        ) {
          setTimeout(() => {
            // this.$refs.ToAutocomplete.openMobileDialog = true;
          }, 1);
        } else {
          this.$refs.ToAutocomplete.openMobileDialog = false;
        }
      },
    },
    getToSearch: {
      handler: function (val) {
        this.To = val;
        // if (typeof val == "object") return;
        if (val == "") {
          this.toItemsDisplay = this.toItems.slice(0, 50);
          return;
        }
        this.querySearch(val, this.toItems).then((res) => {
          this.toItemsDisplay = res;
        });
        if (
          !this.isMobile &&
          val.name &&
          this.$refs.ToAutocomplete.showMenu == true
        ) {
          this.$refs.vacationDatePicker.showDatepicker();
        }
        if (
          this.isMobile &&
          val.name &&
          this.$refs.ToAutocomplete.openMobileDialog == true
        ) {
          // this.$refs.vacationDatePicker.showDatepicker();
        }
      },
    },
  },
  computed: {
    isMobile() {
      return window.innerWidth < 600;
    },
    disabledButton() {
      let checkAvailableRoom = this.Adults / this.NumberOfRooms;
      let getError = false;
      this.ChildrenAges.forEach((element) => {
        if (element == 0 || element == null || element > 17) {
          getError = true;
        }
      });
      if (
        !this.To.ids ||
        !this.To ||
        !this.From ||
        !this.From.codes ||
        !this.DepartureDate ||
        (this.Children > 0 && this.NumberOfRooms > 1) ||
        !Number.isInteger(checkAvailableRoom) ||
        this.NumberOfPassangers > 6 ||
        this.Adults == 0 ||
        getError
      ) {
        return true;
      }
    },
  },
  methods: {
    clearDate() {
      this.DepartureDate = null;
    },
    changeDestination(value) {
      return new Promise((resolve) => {
        if (value && !value.name) {
          this.axios
            .get(
              `https://vacationapi.tripsupport.ca/api/Resource/GetDestinations?codes=${value}`
            )
            .then((response) => {
              resolve(response.data.data);
            });
        }
      });
    },
    querySearch(value, arrayItems) {
      return new Promise((resolve) => {
        if (value.length) {
          let items = arrayItems.filter((e) => {
            let searchWord = value.toLowerCase().trim();
            return (
              e.name.toLowerCase().indexOf(searchWord) >= 0 ||
              (e.countryName &&
                e.countryName.toLowerCase().indexOf(searchWord) >= 0)
            );
          });
          resolve(items);
        } else {
          resolve(arrayItems);
        }
      });
    },
    getRangeDate(e) {
      this.lastDate = e;
      this.DepartureDate = this.changeFormat(e.startDate);
    },
    save() {
      let destination = [];
      if (!this.selectedMultiple.length) {
        destination.push(this.To.ids);
      } else {
        this.selectedMultiple.map((items) => {
          destination.push(items.id);
        });
      }
      if (!this.From || !this.From.codes || !destination[0]) {
        this.showDialog = true;
        this.toast = {
          color: "#cb3839",
          toastText: "Please Enter Departing From and Going To",
        };
        if (!this.From || !this.From.codes) {
          this.$gtag.event("Validation", {
            event_category: "Vacation",
            event_label: "User entered an invalid Departing From",
          });
        }
        if (!destination[0]) {
          this.$gtag.event("Validation", {
            event_category: "Vacation",
            event_label: "User entered an invalid Going To",
          });
        }
        return;
      }
      if (!this.DepartureDate) {
        this.showDialog = true;
        this.toast = {
          color: "#cb3839",
          toastText: "Please Enter departure date",
        };
        this.$gtag.event("Validation", {
          event_category: "Vacation",
          event_label: "User entered an invalid Departure",
        });
        return;
      }
      if (this.Children > 0 && this.NumberOfRooms > 1) {
        this.showDialog = true;
        this.toast = {
          color: "#cb3839",
          toastText:
            "Sorry, the adult occupancy must be consistent for all rooms in an online booking.",
        };
        this.$gtag.event("Validation", {
          event_category: "Vacation",
          event_label:
            "User entered Rooms do not match the number of passengers",
        });
        return;
      }
      let checkAvailableRoom = this.Adults / this.NumberOfRooms;
      if (!Number.isInteger(checkAvailableRoom)) {
        this.showDialog = true;
        this.toast = {
          color: "#cb3839",
          toastText:
            "Sorry, the adult occupancy must be consistent for all rooms in an online booking.",
        };
        this.$gtag.event("Validation", {
          event_category: "Vacation",
          event_label:
            "User entered Rooms do not match the number of passengers",
        });
        return;
      }
      if (this.NumberOfPassangers > 6) {
        this.showDialog = true;
        this.toast = {
          color: "#cb3839",
          toastText:
            "Sorry, you can only book a maximum of 6 passengers in an online booking.",
        };
        this.$gtag.event("Validation", {
          event_category: "Vacation",
          event_label: "User entered more than 6 passengers",
        });
        return;
      }
      if (this.Adults == 0) {
        this.showDialog = true;
        this.toast = {
          color: "#cb3839",
          toastText: "AdultCount should not be zero",
        };
        this.$gtag.event("Validation", {
          event_category: "Vacation",
          event_label: "User entered an invalid Traveller",
        });
        return;
      }
      let getError = false;
      this.ChildrenAges.forEach((element) => {
        if (element == 0 || element == null || element > 17) {
          getError = true;
        }
      });
      if (getError) {
        this.showDialog = true;
        this.toast = {
          color: "#cb3839",
          toastText:
            "Age should not be zero or empty or The maximum age must be 17 years old",
        };
        this.$gtag.event("Validation", {
          event_category: "Vacation",
          event_label:
            "User entered zero or empty or more than 17 years for children ages",
        });
        return;
      }
      let setVacationFilter = {
        From: this.From.codes,
        To: this.To.ids,
        DepartureDate: this.DepartureDate,
        Durations: this.Durations,
        AllInclusive: this.AllInclusive,
        NumberOfRooms: this.NumberOfRooms,
        NumberOfAdults: this.Adults,
        ChildrenAges: JSON.stringify(this.ChildrenAges),
      };
      let newLocalStorage = {
        From: this.From,
        To: this.To,
        NumberOfPassangers: this.NumberOfPassangers,
        NumberOfRooms: this.NumberOfRooms,
        DepartureDate: this.DepartureDate,
        AllInclusive: this.AllInclusive,
        ChildrenAges: this.ChildrenAges,
        Durations: this.Durations,
        multiple: this.selectedMultiple,
        date: this.lastDate,
        TravellersData: this.previousSelectionTravellers,
      };
      localStorage.setItem("vacationFilter", JSON.stringify(setVacationFilter));
      localStorage.setItem("adultsFilter", JSON.stringify(this.Adults));
      localStorage.setItem("childrenFilter", JSON.stringify(this.ChildrenAges));
      localStorage.setItem(
        "lastVacationBooking",
        JSON.stringify(newLocalStorage)
      );
      this.$gtag.event("Search", {
        event_category: "Vacation",
        event_label: "User submit new search",
      });
      let url = location.href;
      url = url.substring(url.indexOf(".")).split("/")[0];
      let href = `https://secure.tripsupport${url}/vacation?From=${this.From.codes}&To=${destination}&DepartureDate=${this.DepartureDate}&Durations=${this.Durations}&AllInclusive=${this.AllInclusive}&NumberOfRooms=${this.NumberOfRooms}&NumberOfAdults=${this.Adults}&ChildrenAges=[${this.ChildrenAges}]`;
      window.open(href, "_self");
    },
    changeFormat(val) {
      return moment(val).format("D MMM YYYY");
    },
    rooms(val) {
      this.NumberOfRooms = val;
      let checkAvailableRoom = this.Adults / this.NumberOfRooms;
      if (!Number.isInteger(checkAvailableRoom)) {
        this.roomsError = true;
      } else {
        this.roomsError = false;
      }
    },
    passanger(val, ChildrenAges, Children, Adults) {
      let childAgesArray = [];
      ChildrenAges.forEach((element) => {
        childAgesArray.push(element.child);
      });
      this.NumberOfPassangers = val;
      this.ChildrenAges = childAgesArray;
      this.Children = Children;
      this.Adults = Adults;
      this.previousSelectionTravellers = {
        adults: Adults,
        children: Children,
        childrenAges: ChildrenAges,
      };
      let checkAvailableRoom = this.Adults / this.NumberOfRooms;
      if (!Number.isInteger(checkAvailableRoom)) {
        this.roomsError = true;
      } else {
        this.roomsError = false;
      }
    },
    getDurations(val) {
      this.Durations = val;
    },
  },
};
</script>
