<?php
// Silence is gold