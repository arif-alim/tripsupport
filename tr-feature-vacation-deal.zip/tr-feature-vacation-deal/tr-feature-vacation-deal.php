<?php
/**
 * plugin name: trip support feature vacations
 * description: custom plugin for displaying trip support feature vacation
 * version: 2.1.4
 * author: hamyar
 */

use Tr\Feature\Vacation\Main;

/**
 * define plugin main file directory path
 */
define('TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH', plugin_dir_path(__FILE__));

/**
 * define plugin main file directory path
 */
define('TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_URL', plugin_dir_url(__FILE__));

/**
 * define plugin main file directory path
 */
define('TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_NAME', plugin_basename(__FILE__));


/**
 * require composer autoloader
 */
require TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_PATH . '/vendor/autoload.php';


add_filter('http_request_timeout', 'custom_http_request_timeout');

function custom_http_request_timeout()
{
    return 60;
}

/**
 * initialize plugin
 */
add_action('plugins_loaded', array((new Main()), 'boot'));