<?php
global $post;
$postCityIdMetaBoxValue = get_post_meta($post->ID, 'tr_vacation_id', true);
?>

<label>City ID : </label>
<input type="number" name="tr_vacation_post_id" value="<?php echo $postCityIdMetaBoxValue ?>">