import Vue from 'vue';
import HotelDatePicker from './src/DatePicker/HotelDatePicker.vue';
// import './src/assets/scss/index.scss';
import 'vue-hotel-datepicker/dist/vueHotelDatepicker.css';
Vue.component('HotelDatePicker', HotelDatePicker);
