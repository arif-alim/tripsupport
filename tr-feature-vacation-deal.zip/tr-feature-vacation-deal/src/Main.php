<?php

namespace Tr\Feature\Vacation;

class Main {

    public function boot()
    {
        if (!defined('ABSPATH')) {
            exit('you can not access directly');
        }

        $this->init();
        add_action('init',  array((new Api()), 'add'));
        add_action('admin_menu', array((new Page()), 'addClearCachePage'));
        add_action('admin_init', array((new Metabox()), 'add'));
        add_action('save_post', array((new Metabox()), 'save'));
        add_action('wp_enqueue_scripts', array((new Enqueue()), 'add'));
        add_action('init', array((new Shortcode()), 'add'));
        add_action('wp_ajax', array((new Ajax()), 'get_feature_vacation'));
    }

    public function init()
    {
        register_activation_hook(TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_NAME, array($this, 'active'));
        register_deactivation_hook(TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_NAME, array($this, 'deactivate'));
        register_uninstall_hook(TRIP_SUPPORT_FEATURE_VACATION_MAIN_FILE_NAME, array(Main::class, 'uninstall'));
    }

    public function active()
    {
        //
    }

    public function deactivate()
    {
        //
    }

    public static function uninstall()
    {
        //
    }
}
