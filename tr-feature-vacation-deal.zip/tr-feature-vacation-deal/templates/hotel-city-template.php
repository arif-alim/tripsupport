<div class="container bg-white tr_trending_hotel_destination_main_container pl-0 pr-0 p-md-5 pt-4 pb-5">
    <p class="m-0 tr_trending_hotel_destination_main_title">Top All-inclusive hotel deals in Vancouver</p>
    <p class="m-0 tr_trending_hotel_destination_second_title pb-3">Wishing for an escape that won't break the bank? These incredible deals are sure to fit the bill.</p>
    <div class="row col-md-12 mb-3 p-0 m-0 d-none d-sm-flex">
        <?php $counter = 1 ?>
        <?php foreach ($hotels->data as $hotel): ?>
            <?php if ($counter <= 8): ?>
                <div class="col-md-3 p-1">
                    <div class="swiper-slide col-md-12 bg-white p-2 tr_trending_hotel_destination_each_container">
                        <div class="tr_trending_hotel_destination_each_image mb-1"
                             style="background-image: url(<?php echo $hotel->hotel->mainImge ?>)">
                        <span class="bg-white pl-2 pr-2 float-right text-center mt-1 mr-1" style="border-radius: 4px">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                            <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                  fill="#FFB310"/>
                            </svg>
                            <?php echo $hotel->hotel->rating ?>(32)
                        </span>
                        </div>
                        <svg width="10" height="14" viewBox="0 0 10 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                  fill="#007AFF"/>
                        </svg>
                        <span class="tr_trending_hotel_destination_each_destination">
                             <?php echo $hotel->hotel->city->name ?>, <?php echo $hotel->hotel->city->destination->country->name ?>
                        </span>
                        <p class="tr_trending_hotel_destination_each_name"><?php echo $hotel->hotel->name ?></p>
                        <p class="tr_trending_hotel_destination_each_price">CA
                            $<?php echo $hotel->availableRooms[0]->price->amount ?> <span
                                    class="font-weight-normal">/ night</span></p>
                        <p class="tr_trending_hotel_destination_each_tax">price includes taxes and fees</p>
                        <p class="tr_trending_hotel_destination_each_cancel">Free Cancellation</p>
                        <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.3904 2.0133C4.27616 2.04447 4.17833 2.1185 4.1173 2.21998L4.11663 2.22131L4.10796 2.23731C4.04956 2.34437 4.03606 2.47025 4.07044 2.58726C4.10482 2.70428 4.18426 2.80285 4.29129 2.86131L8.45663 5.13064C8.57315 5.1928 8.6762 5.27744 8.75981 5.37966C8.84342 5.48188 8.90594 5.59967 8.94376 5.7262C8.98158 5.85273 8.99394 5.98551 8.98013 6.11685C8.96633 6.24819 8.92662 6.37549 8.86332 6.49139C8.80002 6.60729 8.71437 6.7095 8.61132 6.7921C8.50828 6.8747 8.38989 6.93606 8.26299 6.97263C8.13609 7.00919 8.0032 7.02025 7.872 7.00514C7.7408 6.99004 7.6139 6.94909 7.49863 6.88464L3.33396 4.61531C3.30374 4.59842 3.27374 4.58109 3.24396 4.56331C2.69661 4.23104 2.30053 3.6983 2.13998 3.07845C1.97944 2.4586 2.06711 1.80057 2.38434 1.24437C2.70157 0.688172 3.22332 0.277718 3.83857 0.100345C4.45382 -0.0770276 5.11399 -0.00731746 5.67863 0.294642L10.2533 2.75464C10.9259 3.11654 11.4349 3.72148 11.6766 4.44598L13.426 9.68731C13.5057 9.93783 13.4836 10.2097 13.3645 10.4441C13.2453 10.6784 13.0386 10.8564 12.7891 10.9395C12.5397 11.0226 12.2676 11.0041 12.0316 10.888C11.7957 10.7719 11.615 10.5676 11.5286 10.3193L9.77929 5.07664C9.69855 4.83512 9.52881 4.63344 9.30463 4.51264L4.73063 2.05264C4.62651 1.99623 4.50465 1.98213 4.3904 2.0133Z"
                                  fill="#ABABC4"/>
                            <path d="M11.091 12.0597C11.2147 12.015 11.346 11.9952 11.4773 12.0013H14.4773C14.5075 12 14.5375 12 14.5673 12.0013C14.8322 12.0132 15.0816 12.1299 15.2605 12.3257C15.4394 12.5215 15.5332 12.7804 15.5213 13.0453C15.5094 13.3103 15.3927 13.5596 15.1969 13.7385C15.0011 13.9174 14.7422 14.0112 14.4773 13.9993H11.4773C11.4475 14.0006 11.4177 14.0006 11.388 13.9993C11.2566 13.9937 11.1276 13.9622 11.0084 13.9067C10.8892 13.8512 10.7822 13.7727 10.6933 13.6758C10.6045 13.5788 10.5357 13.4653 10.4908 13.3417C10.4459 13.2181 10.4258 13.0869 10.4317 12.9556C10.4375 12.8242 10.4692 12.6953 10.525 12.5762C10.5808 12.4571 10.6594 12.3502 10.7566 12.2616C10.8537 12.1729 10.9673 12.1043 11.091 12.0597Z"
                                  fill="#ABABC4"/>
                            <path d="M4.14121 13.113C4.36073 12.7838 4.47769 12.397 4.47729 12.0013C4.47694 11.4712 4.26605 10.9629 3.891 10.5882C3.51594 10.2135 3.00744 10.0031 2.47729 10.0033C2.08165 10.0033 1.69489 10.1207 1.36595 10.3405C1.03701 10.5604 0.780662 10.8728 0.629345 11.2384C0.478029 11.604 0.438539 12.0062 0.515872 12.3942C0.593205 12.7822 0.783885 13.1386 1.06379 13.4182C1.3437 13.6979 1.70025 13.8882 2.08834 13.9651C2.47644 14.0421 2.87863 14.0022 3.24405 13.8505C3.60947 13.6988 3.92168 13.4422 4.14121 13.113Z"
                                  fill="#ABABC4"/>
                            <path d="M0.477295 8.79264C0.477295 7.97198 1.12863 7.00598 1.93196 7.00598V7.00664H5.11396C7.52396 7.00664 9.47729 9.30398 9.47729 11.768V12.512C9.48156 12.9021 9.33072 13.2779 9.05793 13.5568C8.78514 13.8358 8.41274 13.9949 8.02263 13.9993H5.38463C5.3238 13.9937 5.26536 13.9729 5.21468 13.9388C5.16399 13.9047 5.12269 13.8584 5.09455 13.8042C5.06641 13.75 5.05234 13.6895 5.05364 13.6285C5.05493 13.5674 5.07155 13.5076 5.10196 13.4546C5.41694 12.8848 5.5379 12.2279 5.44657 11.5833C5.35523 10.9386 5.05655 10.3412 4.59567 9.88133C4.13479 9.42143 3.53675 9.12403 2.89191 9.03406C2.24706 8.94409 1.59045 9.06645 1.02129 9.38264C0.96829 9.41292 0.908533 9.4294 0.847503 9.43058C0.786473 9.43177 0.726122 9.41761 0.671984 9.38941C0.617845 9.36122 0.571651 9.31988 0.537636 9.26919C0.503621 9.21851 0.482873 9.1601 0.477295 9.09931V8.79264Z"
                                  fill="#ABABC4"/>
                        </svg>
                        <span class="tr_trending_hotel_destination_each_rate">Rated 4.1/5 for cleanliness</span>
                    </div>
                </div>
                <?php $counter++; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    <div class="row col-md-12 mb-3 p-0 m-0 d-block d-sm-none">
        <div class="swiper-container pb-4 tr_trending_hotel_destination_items-container">
            <div class="swiper-wrapper">
                <?php foreach ($hotels->data as $hotel): ?>
                    <div class="swiper-slide bg-white p-2 tr_trending_hotel_destination_each_container">
                        <div class="tr_trending_hotel_destination_each_image mb-1"
                             style="background-image: url(<?php echo $hotel->hotel->mainImge ?>)">
                        <span class="bg-white pl-2 pr-2 float-right text-center mt-1 mr-1" style="border-radius: 4px">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                            <path d="M12.293 9.85017L15.7442 6.86821C16.2325 6.44474 15.9799 5.61543 15.3402 5.58014L10.8957 5.29783C10.6263 5.28018 10.3906 5.10374 10.2896 4.83907L8.65658 0.463174C8.42088 -0.154391 7.59595 -0.154391 7.36026 0.463174L5.72724 4.82142C5.62623 5.08609 5.39053 5.26254 5.12117 5.28018L0.659819 5.5625C0.020078 5.59779 -0.232451 6.42709 0.255772 6.85056L3.707 9.81488C3.90903 9.99133 4.01004 10.2913 3.9427 10.556L2.81473 15.0907C2.66322 15.7259 3.31979 16.2376 3.85852 15.8847L7.61279 13.3615C7.84848 13.2027 8.13468 13.2027 8.35354 13.3615L12.1246 15.8847C12.6634 16.2376 13.3199 15.7259 13.1684 15.0907L12.0405 10.5736C11.99 10.3089 12.0741 10.0266 12.293 9.85017Z"
                                  fill="#FFB310"/>
                            </svg>
                            <?php echo $hotel->hotel->rating ?>(32)
                        </span>
                        </div>
                        <svg width="10" height="14" viewBox="0 0 10 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6.00001 10.3086C6.00259 10.1927 6.04262 10.0807 6.11412 9.98934C6.18561 9.89802 6.28474 9.83228 6.39668 9.80195C7.55263 9.46566 8.54844 8.7236 9.2012 7.71206C9.85396 6.70052 10.1198 5.48742 9.95 4.29559C9.78016 3.10375 9.18601 2.01321 8.27668 1.22428C7.36734 0.435337 6.20389 0.000976563 5.00001 0.000976562C3.79614 0.000976563 2.63268 0.435337 1.72335 1.22428C0.814013 2.01321 0.219859 3.10375 0.0500193 4.29559C-0.119821 5.48742 0.146058 6.70052 0.798819 7.71206C1.45158 8.7236 2.44739 9.46566 3.60334 9.80195C3.71529 9.83228 3.81441 9.89802 3.88591 9.98934C3.9574 10.0807 3.99743 10.1927 4.00001 10.3086V12.9999C4.00001 13.2652 4.10537 13.5195 4.2929 13.7071C4.48044 13.8946 4.7348 13.9999 5.00001 13.9999C5.26523 13.9999 5.51958 13.8946 5.70712 13.7071C5.89466 13.5195 6.00001 13.2652 6.00001 12.9999V10.3086Z"
                                  fill="#007AFF"/>
                        </svg>
                        <span class="tr_trending_hotel_destination_each_destination">
                             <?php echo $hotel->hotel->city->name ?>, <?php echo $hotel->hotel->city->destination->country->name ?>
                        </span>
                        <p class="tr_trending_hotel_destination_each_name"><?php echo $hotel->hotel->name ?></p>
                        <p class="tr_trending_hotel_destination_each_price">CA
                            $<?php echo $hotel->availableRooms[0]->price->amount ?> <span
                                class="font-weight-normal">/ night</span></p>
                        <p class="tr_trending_hotel_destination_each_tax">price includes taxes and fees</p>
                        <p class="tr_trending_hotel_destination_each_cancel">Free Cancellation</p>
                        <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.3904 2.0133C4.27616 2.04447 4.17833 2.1185 4.1173 2.21998L4.11663 2.22131L4.10796 2.23731C4.04956 2.34437 4.03606 2.47025 4.07044 2.58726C4.10482 2.70428 4.18426 2.80285 4.29129 2.86131L8.45663 5.13064C8.57315 5.1928 8.6762 5.27744 8.75981 5.37966C8.84342 5.48188 8.90594 5.59967 8.94376 5.7262C8.98158 5.85273 8.99394 5.98551 8.98013 6.11685C8.96633 6.24819 8.92662 6.37549 8.86332 6.49139C8.80002 6.60729 8.71437 6.7095 8.61132 6.7921C8.50828 6.8747 8.38989 6.93606 8.26299 6.97263C8.13609 7.00919 8.0032 7.02025 7.872 7.00514C7.7408 6.99004 7.6139 6.94909 7.49863 6.88464L3.33396 4.61531C3.30374 4.59842 3.27374 4.58109 3.24396 4.56331C2.69661 4.23104 2.30053 3.6983 2.13998 3.07845C1.97944 2.4586 2.06711 1.80057 2.38434 1.24437C2.70157 0.688172 3.22332 0.277718 3.83857 0.100345C4.45382 -0.0770276 5.11399 -0.00731746 5.67863 0.294642L10.2533 2.75464C10.9259 3.11654 11.4349 3.72148 11.6766 4.44598L13.426 9.68731C13.5057 9.93783 13.4836 10.2097 13.3645 10.4441C13.2453 10.6784 13.0386 10.8564 12.7891 10.9395C12.5397 11.0226 12.2676 11.0041 12.0316 10.888C11.7957 10.7719 11.615 10.5676 11.5286 10.3193L9.77929 5.07664C9.69855 4.83512 9.52881 4.63344 9.30463 4.51264L4.73063 2.05264C4.62651 1.99623 4.50465 1.98213 4.3904 2.0133Z"
                                  fill="#ABABC4"/>
                            <path d="M11.091 12.0597C11.2147 12.015 11.346 11.9952 11.4773 12.0013H14.4773C14.5075 12 14.5375 12 14.5673 12.0013C14.8322 12.0132 15.0816 12.1299 15.2605 12.3257C15.4394 12.5215 15.5332 12.7804 15.5213 13.0453C15.5094 13.3103 15.3927 13.5596 15.1969 13.7385C15.0011 13.9174 14.7422 14.0112 14.4773 13.9993H11.4773C11.4475 14.0006 11.4177 14.0006 11.388 13.9993C11.2566 13.9937 11.1276 13.9622 11.0084 13.9067C10.8892 13.8512 10.7822 13.7727 10.6933 13.6758C10.6045 13.5788 10.5357 13.4653 10.4908 13.3417C10.4459 13.2181 10.4258 13.0869 10.4317 12.9556C10.4375 12.8242 10.4692 12.6953 10.525 12.5762C10.5808 12.4571 10.6594 12.3502 10.7566 12.2616C10.8537 12.1729 10.9673 12.1043 11.091 12.0597Z"
                                  fill="#ABABC4"/>
                            <path d="M4.14121 13.113C4.36073 12.7838 4.47769 12.397 4.47729 12.0013C4.47694 11.4712 4.26605 10.9629 3.891 10.5882C3.51594 10.2135 3.00744 10.0031 2.47729 10.0033C2.08165 10.0033 1.69489 10.1207 1.36595 10.3405C1.03701 10.5604 0.780662 10.8728 0.629345 11.2384C0.478029 11.604 0.438539 12.0062 0.515872 12.3942C0.593205 12.7822 0.783885 13.1386 1.06379 13.4182C1.3437 13.6979 1.70025 13.8882 2.08834 13.9651C2.47644 14.0421 2.87863 14.0022 3.24405 13.8505C3.60947 13.6988 3.92168 13.4422 4.14121 13.113Z"
                                  fill="#ABABC4"/>
                            <path d="M0.477295 8.79264C0.477295 7.97198 1.12863 7.00598 1.93196 7.00598V7.00664H5.11396C7.52396 7.00664 9.47729 9.30398 9.47729 11.768V12.512C9.48156 12.9021 9.33072 13.2779 9.05793 13.5568C8.78514 13.8358 8.41274 13.9949 8.02263 13.9993H5.38463C5.3238 13.9937 5.26536 13.9729 5.21468 13.9388C5.16399 13.9047 5.12269 13.8584 5.09455 13.8042C5.06641 13.75 5.05234 13.6895 5.05364 13.6285C5.05493 13.5674 5.07155 13.5076 5.10196 13.4546C5.41694 12.8848 5.5379 12.2279 5.44657 11.5833C5.35523 10.9386 5.05655 10.3412 4.59567 9.88133C4.13479 9.42143 3.53675 9.12403 2.89191 9.03406C2.24706 8.94409 1.59045 9.06645 1.02129 9.38264C0.96829 9.41292 0.908533 9.4294 0.847503 9.43058C0.786473 9.43177 0.726122 9.41761 0.671984 9.38941C0.617845 9.36122 0.571651 9.31988 0.537636 9.26919C0.503621 9.21851 0.482873 9.1601 0.477295 9.09931V8.79264Z"
                                  fill="#ABABC4"/>
                        </svg>
                        <span class="tr_trending_hotel_destination_each_rate">Rated 4.1/5 for cleanliness</span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="d-none d-sm-flex swiper-button-prev ">
            <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0.861978 8.68671L6.46214 14.8097C6.92546 15.2767 7.66838 15.3213 8.15605 14.9617C8.64369 14.6022 8.72405 13.8756 8.32469 13.4365L4.3371 9.08065H16.2001C16.8628 9.08065 17.4001 8.59689 17.4001 8.00015C17.4001 7.40338 16.8628 6.91963 16.2001 6.91963H4.3371L8.32469 2.56376C8.72405 2.12474 8.63418 1.40827 8.15605 1.03856C7.66302 0.657276 6.86138 0.751468 6.46214 1.19059L0.861978 7.31355C0.497418 7.77511 0.528538 8.24038 0.861978 8.68671Z"
                      fill="#66678F"/>
            </svg>
        </div>
        <div class="d-none d-sm-flex swiper-button-next ">
            <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.138 8.68671L11.5379 14.8097C11.0745 15.2767 10.3316 15.3213 9.84395 14.9617C9.35631 14.6022 9.27595 13.8756 9.67531 13.4365L13.6629 9.08065H1.79994C1.13718 9.08065 0.599899 8.59689 0.599899 8.00015C0.599899 7.40338 1.13718 6.91963 1.79994 6.91963H13.6629L9.67531 2.56376C9.27595 2.12474 9.36582 1.40827 9.84395 1.03856C10.337 0.657276 11.1386 0.751468 11.5379 1.19059L17.138 7.31355C17.5026 7.77511 17.4715 8.24038 17.138 8.68671Z"
                      fill="#66678F"/>
            </svg>
        </div>
    </div>
</div>
<style>
    @media (max-width: 540px) {
        .tr_trending_hotel_destination_main_container {
            background-color: #fff;
        }
    }

    @media (min-width: 541px) {
        .tr_trending_hotel_destination_main_container {
            background-color: #fcfcfd;
        }
    }

    .swiper-button-next {
        background-color: white;
        color: #0C0D25 !important;
        border-radius: 100%;
        box-shadow: 0px 5px 5px rgba(102, 103, 143, 0.04);
        margin-right: -60px;
        width: 40px;
        height: 40px;
        border: 1px solid rgba(102, 103, 143, 0.1);
    }

    .swiper-button-prev {
        background-color: white;
        color: #0C0D25 !important;
        border-radius: 100%;
        box-shadow: 0px 5px 5px rgba(102, 103, 143, 0.04);
        margin-left: -60px;
        width: 40px;
        height: 40px;
        border: 1px solid rgba(102, 103, 143, 0.1);
    }

    .swiper-button-next::after {
        font-size: 10px !important;
        font-weight: bold;
        color: #66678F !important;
        display: none !important;
    }

    .swiper-button-prev::after {
        font-size: 10px !important;
        font-weight: bold;
        color: #66678F !important;
        display: none !important;
    }

    .tr_trending_hotel_destination_main_title {
        color: #0C0D25;
        font-weight: normal;
        font-size: 26px;
        line-height: 100%;
    }

    .tr_trending_hotel_destination_second_title {
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 24px;
        letter-spacing: -0.02em;
        color: #66678F;
    }

    .tr-trending-hotel-destination-btn-active {
        background: #66678F !important;
        border-radius: 18px !important;
        padding-left: 10px !important;
        padding-right: 10px !important;
        color: #fff !important;
        cursor: pointer;
    }

    .tr-trending-hotel-destination-btn {
        background-color: #e8e8ef;
        border-radius: 18px;
        color: #66678F;
        padding-left: 5px;
        padding-right: 5px;
        width: auto !important;
        cursor: pointer;
    }

    .tr_trending_hotel_destination_each_container {
        border: 1px solid rgba(102, 103, 143, 0.1);
        box-shadow: 0px 2px 4px rgba(102, 103, 143, 0.2);
        border-radius: 8px;
    }

    .tr_trending_hotel_destination_each_image {
        background-position: center center;
        background-size: cover;
        background-repeat: no-repeat;
        height: 220px;
        width: 100%;
        border-radius: 4px;
    }

    .swiper-container-pointer-events {
        margin: 0px !important;
    }


    .tr_trending_hotel_destination_items-container {
        width: 100% !important;
    }

    .tr_trending_hotel_destination_each_destination {
        color: #007AFF;
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 100%;
        letter-spacing: -0.02em;
        margin-bottom: 0.5rem;
    }

    .tr_trending_hotel_destination_each_name {
        font-style: normal;
        margin-bottom: 1rem;
        font-weight: normal;
        font-size: 18px;
        line-height: 120%;
        letter-spacing: -0.01em;
        color: #0C0D25;
    }

    .tr_trending_hotel_destination_each_price {
        font-style: normal;
        font-weight: bold;
        font-size: 18px;
        margin-bottom: 0.2rem;
        line-height: 22px;
        letter-spacing: -0.03em;
        color: #0C0D25;
    }

    .tr_trending_hotel_destination_each_tax {
        font-style: normal;
        font-weight: normal;
        margin-bottom: 0.2rem;
        font-size: 12px;
        line-height: 15px;
        letter-spacing: -0.02em;
        color: #66678F;
    }

    .tr_trending_hotel_destination_each_cancel {
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 15px;
        letter-spacing: -0.03em;
        text-transform: capitalize;
        color: #00AD45;
    }

    .tr_trending_hotel_destination_each_rate {
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 100%;
        letter-spacing: -0.02em;
        color: #ABABC4;
    }

    .swiper-button-prev {
        left: -15px !important;
        color: #1c1c1c;
    }

    .swiper-button-prev::after, .swiper-button-next::after {
        font-size: 20px !important;
        background-color: #fff !important;
        padding: 15px;
        border: 1px solid rgba(102, 103, 143, 0.1);
        box-shadow: 0px 2px 2px rgba(102, 103, 143, 0.04);
        border-radius: 4000px;
    }

    .swiper-button-next {
        right: -15px !important;
        color: #1c1c1c;
    }

</style>

<script>
    var swiperTwo = new Swiper('.tr_trending_hotel_destination_items-container', {
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            960: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            720: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            540: {
                slidesPerView: 1.5,
                spaceBetween: 10
            },
            320: {
                slidesPerView: 1.5,
                spaceBetween: 10
            },
        },
        slidesPerView: 'auto'
    });
</script>
