<?php


namespace Tr\Feature\Vacation;


use wpdb;

class Database
{
    /**
     * @var string
     */
    private $tablePrefix;

    const CACHE_TABLE_QUERY = "CREATE TABLE IF NOT EXISTS `wp_tr_cache_table` (`id` int(11) NOT NULL auto_increment,   
                                  `name` varchar(256) NOT NULL default '',
                                  `value` JSON default NULL,
                                  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                  `created_at`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,     
                                   PRIMARY KEY  (`id`)
                                );";

    /**
     * @var wpdb
     */
    private $wpdb;

    /**
     * Database constructor.
     */
    public function __construct()
    {
        global $wpdb;
        $this->tablePrefix = $wpdb->prefix;
        $this->wpdb = $wpdb;
    }

    /**
     * @return array|object|null
     */
    public function up()
    {
        return $this->get(self::CACHE_TABLE_QUERY);
    }

    /**
     * @param $query
     * @return array|object|null
     */
    public function get($query)
    {
        return $this->wpdb->get_results($query);
    }

    /**
     * @param $table
     * @param $data
     * @param $where
     * @return false|int
     */
    public function update($table, $data, $where)
    {
        return $this->wpdb->update($table, $data, $where);
    }

    /**
     * @param $table
     * @param $data
     * @return false|int
     */
    public function insert($table, $data)
    {
        return $this->wpdb->insert($table, $data);
    }

    /**
     * @param $table
     * @param $where
     * @return false|int
     */
    public function delete($table, $where)
    {
        return $this->wpdb->delete($table, $where);
    }
}