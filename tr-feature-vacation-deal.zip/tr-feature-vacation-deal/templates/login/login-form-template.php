<!-- Button trigger modal -->
<div class="tr-plugin-login-header-section-container">
    <button type="button" class="btn btn-primary tr-login-plugin-popup-btn" data-toggle="modal" data-target="#exampleModal">
        Sign in
    </button>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h5 class="modal-title" id="exampleModalLabel">Sign in</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                         aria-labelledby="pills-home-tab">
                        <hr>
                        <div class="tr-plugin-forgot-password-success-message"></div>
                        <input type="email" placeholder="Email Address" class="form-control tr-login-plugin-login-email-address tr-login-form-inputs mb-4">
                        <input type="password" placeholder="Password" class="form-control tr-login-plugin-login-password tr-login-form-inputs mb-4">
                        <div class="spinner-border tr-login-plugin-spinner-loading d-none" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                        <button class="tr-login-plugin-forgot-password-section-btn btn-link">Forgot password?</button>
                        <button class="btn-block btn mt-2 btn-danger tr-login-plugin-login-btn">Sign in</button>
                        <hr>
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        <hr>
                        <input type="text" placeholder="First Name" class="form-control tr-login-plugin-register-first-name tr-login-form-inputs mb-4">
                        <input type="text" placeholder="Last Name" class="form-control tr-login-plugin-register-last-name tr-login-form-inputs mb-4">
                        <input type="email" placeholder="Email Address" class="form-control tr-login-plugin-register-email-address tr-login-form-inputs mb-4">
                        <input type="password" placeholder="Password" class="form-control tr-login-plugin-register-password tr-login-form-inputs mb-4">
                        <div class="spinner-border tr-login-plugin-spinner-loading-register d-none" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                        <div class="tr-login-plugin-create-account-message-show d-none text-danger"></div>
                        <button class="btn-block btn mt-2 btn-danger tr-login-plugin-register-btn">Create Account</button>
                        <hr>
                    </div>
                </div>
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav nav-iten tr-login-plugin-toggle-link-text">Don't have an account?</li>
                    <li class="nav-item">
                        <a class="nav-link active d-none tr-login-plugin-link-style pt-0" id="pills-home-tab"
                           data-toggle="pill"
                           href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Sign in</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link tr-login-plugin-link-style pt-0" id="pills-profile-tab" data-toggle="pill"
                           href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Create account</a>
                    </li>
                </ul>
            </div>
            <div class="forgot-password-form d-none p-3">
                <p>Reset your password to continue enjoying faster checkouts and easy access to your trip info. Just enter your email so we can send a secure link.</p>
                <div class="tr-login-plugin-forgot-password-error-message"></div>
                <input type="email" placeholder="Email Address" class="tr-login-plugin-forgot-password-email-field form-control tr-login-form-inputs mb-4">
                <button class="tr-login-plugin-bac-to-login-btn btn-link">Back to Login</button>
                <button class="btn-block btn btn-danger tr-login-plugin-rest-password mt-2 mb-4">Reset Password</button>
            </div>
        </div>
    </div>
</div>

<style>
    .modal-dialog {
        z-index: 2500
    }
    .modal-backdrop {
        z-index: -1000;
        background-color: transparent !important;
    }
    .tr-login-plugin-link-style {
        background-color: transparent !important;
        color: #0a84c0 !important;
        font-weight: bold !important;
    }

    .modal-header {
        border: none !important;
    }

    .tr-login-form-inputs {
        border-radius: 0px !important;
        border: 1px solid #ccc !important;
        background-color: #fff !important;
        box-shadow: none !important;
    }
    .tr-login-plugin-popup-btn {
        background-color: transparent !important;
        color: black;
        border: none;
    }

    .tr-login-plugin-popup-btn:hover {
        color: black;
    }

    .tr-login-plugin-popup-btn:focus {
        color: black;
    }
    .btn-link {
        background-color: transparent !important;
        font-width: bold;
    }
</style>

<script !src="">
    const loginUrl                          = 'https://myprofileapi.tripsupport.com/api/myprofile/userlogindetails';
    let trLoginRegisterBtns                 = document.querySelectorAll('.tr-login-plugin-link-style');
    let trLoginModelTitle                   = document.querySelector('#exampleModalLabel');
    let trLoginSuggestText                  = document.querySelector('.tr-login-plugin-toggle-link-text');
    let trLoginPluginLoginBtn               = document.querySelector('.tr-login-plugin-login-btn');
    let trLoginPluginLoginEmailAddress      = document.querySelector('.tr-login-plugin-login-email-address');
    let trLoginPluginLoginPassword          = document.querySelector('.tr-login-plugin-login-password ');
    let trPluginLoginHeaderSectionContainer = document.querySelector('.tr-plugin-login-header-section-container');
    let trLoginPluginSpinnerLoading         = document.querySelector('.tr-login-plugin-spinner-loading');

    if(localStorage.getItem('user')){
        let localStorageUserItem = JSON.parse(localStorage.getItem('user'));
        if(localStorageUserItem.hasResult == true){
            console.log('cdcdsss');
            trPluginLoginHeaderSectionContainer.innerHTML = `
                    <div class="dropdown">
                      <button class="btn btn-secondary text-dark dropdown-toggle tr-login-plugin-popup-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        ` + localStorageUserItem.result.lastname + `
                      </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="https://tripsupport.com/user/bookings">My Bookings</a>
                        <a class="dropdown-item" href="https://tripsupport.com/user/profile">My Profile</a>
                        <a class="dropdown-item tr-login-plugin-logout-btn" href="#">Logout</a>
                      </div>
                    </div>`;
            let trLoginPluginLogoutBtn = document.querySelector('.tr-login-plugin-logout-btn');
            trLoginPluginLogoutBtn.addEventListener('click', () => {
                localStorage.removeItem('user');
                trPluginLoginHeaderSectionContainer.innerHTML = `
                          <button type="button" class="btn btn-primary tr-login-plugin-popup-btn" data-toggle="modal" data-target="#exampleModal">
                            Sign in
                        </button>`;
            });
        }
    }

    trLoginRegisterBtns.forEach(trLoginRegisterBtn => {
        trLoginRegisterBtn.addEventListener('click', () => {
            setTimeout(function () {
                trLoginRegisterBtns.forEach(check => {
                    if (check.classList.contains('active')) {
                        check.classList.add('d-none');
                    } else {
                        check.classList.remove('d-none');
                        if (check.textContent == 'Create account') {
                            trLoginModelTitle.textContent = 'Sign in';
                            trLoginSuggestText.textContent = 'Don\'t have an account?';
                        }
                        if (check.textContent == 'Sign in') {
                            trLoginModelTitle.textContent = 'Create account';
                            trLoginSuggestText.textContent = 'Already have an account?';
                        }
                    }
                })
            }, 100)
        })
    });


    /**
     * Send login request
     */
    trLoginPluginLoginBtn.addEventListener('click', () => {
        trLoginPluginSpinnerLoading.classList.remove('d-none');
        jQuery.ajax({
            url : loginUrl,
            type: 'POST',
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({
                email: trLoginPluginLoginEmailAddress.value,
                password: trLoginPluginLoginPassword.value
            }),
            success: function (data) {
                trLoginPluginSpinnerLoading.classList.add('d-none');
                console.log(data);
                if (data.hasResult == true) {
                    console.log(trPluginLoginHeaderSectionContainer);

                    trPluginLoginHeaderSectionContainer.innerHTML = `
                    <div class="dropdown">
                      <button class="btn btn-secondary text-dark dropdown-toggle tr-login-plugin-popup-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        ` + data.result.lastname + `
                      </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="https://tripsupport.com/user/bookings">My Bookings</a>
                        <a class="dropdown-item" href="https://tripsupport.com/user/profile">My Profile</a>
                        <a class="dropdown-item tr-login-plugin-logout-btn" href="#">Logout</a>
                      </div>
                    </div>`;

                    localStorage.setItem('user', JSON.stringify(data));
                    let trLoginPluginLogoutBtn = document.querySelector('.tr-login-plugin-logout-btn');
                    trLoginPluginLogoutBtn.addEventListener('click', () => {
                        localStorage.removeItem('user');
                        trPluginLoginHeaderSectionContainer.innerHTML = `
                          <button type="button" class="btn btn-primary tr-login-plugin-popup-btn" data-toggle="modal" data-target="#exampleModal">
                            Sign in
                        </button>`;
                    });
                    const modals = document.getElementsByClassName('modal');
                    for(let i=0; i<modals.length; i++) {
                        modals[i].classList.remove('show');
                        modals[i].setAttribute('aria-hidden', 'true');
                        modals[i].setAttribute('style', 'display: none');
                    }
                    // get modal backdrops
                    const modalsBackdrops = document.getElementsByClassName('modal-backdrop');

                    // remove every modal backdrop
                    for(let i=0; i<modalsBackdrops.length; i++) {
                        document.body.removeChild(modalsBackdrops[i]);
                    }
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    });

    /**
     * Register section code
     */
    let trLoginPluginRegisterEmailAddress     = document.querySelector('.tr-login-plugin-register-email-address');
    let trLoginPluginRegisterFirstName        = document.querySelector('.tr-login-plugin-register-first-name');
    let trLoginPluginRegisterLastName         = document.querySelector('.tr-login-plugin-register-last-name');
    let trLoginPluginRegisterPassword         = document.querySelector('.tr-login-plugin-register-password');
    let trCreateNewAccountBtn                 = document.querySelector('.tr-login-plugin-register-btn');
    let trLoginPluginRegisterProcessSpinner   = document.querySelector('.tr-login-plugin-spinner-loading-register');
    let trLoginPluginCreateAccountMessageShow = document.querySelector('.tr-login-plugin-create-account-message-show');
    let registerUrl                           = 'https://myprofileapi.tripsupport.com/api/myprofile/userregistration';

    /**
     * Add event listener on create account btn
     */
    trCreateNewAccountBtn.addEventListener('click', () => {
        trLoginPluginRegisterProcessSpinner.classList.remove('d-none');
        jQuery.ajax({
            url : registerUrl,
            type: 'POST',
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({
                email:     trLoginPluginRegisterEmailAddress.value,
                password:  trLoginPluginRegisterPassword.value,
                firstname: trLoginPluginRegisterFirstName.value,
                lastname:  trLoginPluginRegisterLastName.value
            }),
            success: function(data) {
                trLoginPluginRegisterProcessSpinner.classList.add('d-none');
                if (data.message == 'registration successful') {
                    console.log(data);
                    data.result = {
                        email:     trLoginPluginRegisterEmailAddress.value,
                        password:  trLoginPluginRegisterPassword.value,
                        firstname: trLoginPluginRegisterFirstName.value,
                        lastname:  trLoginPluginRegisterLastName.value
                    };
                    trPluginLoginHeaderSectionContainer.innerHTML = `
                    <div class="dropdown">
                      <button class="btn btn-secondary text-dark dropdown-toggle tr-login-plugin-popup-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        ` + trLoginPluginRegisterFirstName.value + `
                      </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="https://tripsupport.ca/user/bookings">My Bookings</a>
                        <a class="dropdown-item" href="https://tripsupport.ca/user/profile">My Profile</a>
                        <a class="dropdown-item tr-login-plugin-logout-btn" href="#">Logout</a>
                      </div>
                    </div>`;
                    localStorage.setItem('user', JSON.stringify(data));
                    let trLoginPluginLogoutBtn = document.querySelector('.tr-login-plugin-logout-btn');
                    trLoginPluginLogoutBtn.addEventListener('click', () => {
                        localStorage.removeItem('user');
                        trPluginLoginHeaderSectionContainer.innerHTML = `
                          <button type="button" class="btn btn-primary tr-login-plugin-popup-btn" data-toggle="modal" data-target="#exampleModal">
                            Sign in
                        </button>`;
                    });
                    const modals = document.getElementsByClassName('modal');
                    for(let i=0; i<modals.length; i++) {
                        modals[i].classList.remove('show');
                        modals[i].setAttribute('aria-hidden', 'true');
                        modals[i].setAttribute('style', 'display: none');
                    }
                    // get modal backdrops
                    const modalsBackdrops = document.getElementsByClassName('modal-backdrop');

                    // remove every modal backdrop
                    for(let i=0; i<modalsBackdrops.length; i++) {
                        document.body.removeChild(modalsBackdrops[i]);
                    }
                } else {
                    trLoginPluginCreateAccountMessageShow.innerHTML = data.message;
                    trLoginPluginCreateAccountMessageShow.classList.remove('d-none');

                }
            },
            error: function(err) {
                console.log(err);
            }
        })
    });


    /**
     * Forgot password functionality
     */
    const baseUrlForgotPasswordRequest          = 'https://myprofileapi.tripsupport.com/api/myprofile/forgotpassword?Email=';
    let trLoginPluginForgotPasswordSectionBtn   = document.querySelector('.tr-login-plugin-forgot-password-section-btn');
    let trLoginPluginMainModalBody              = document.querySelector('.modal-body');
    let trPluginLoginForgotPasswordSection      = document.querySelector('.forgot-password-form');
    let trPluginLoginBackToLoginBtn             = document.querySelector('.tr-login-plugin-bac-to-login-btn');
    let trLoginPluginRestPassword               = document.querySelector('.tr-login-plugin-rest-password');
    let trLoginPluginForgotPasswordEmailField   = document.querySelector('.tr-login-plugin-forgot-password-email-field');
    let trLoginPluginForgotPasswordErrorMessage = document.querySelector('.tr-login-plugin-forgot-password-error-message');
    let trPluginForgotPasswordSuccessMessage    = document.querySelector('.tr-plugin-forgot-password-success-message');

    trLoginPluginForgotPasswordSectionBtn.addEventListener('click', () => {
        trLoginModelTitle.textContent = 'Forgot Password';
        trLoginPluginMainModalBody.classList.add('d-none');
        trPluginLoginForgotPasswordSection.classList.remove('d-none');
    });

    trPluginLoginBackToLoginBtn.addEventListener('click', () => {
        trLoginModelTitle.textContent = 'Sign in';
        trLoginPluginMainModalBody.classList.remove('d-none');
        trPluginLoginForgotPasswordSection.classList.add('d-none');
    });

    trLoginPluginRestPassword.addEventListener('click', () => {
        trLoginPluginForgotPasswordErrorMessage.innerHTML = '';
        jQuery.ajax({
            url: baseUrlForgotPasswordRequest + trLoginPluginForgotPasswordEmailField.value,
            type: 'GET',
            dataType: "json",
            contentType: "application/json",
            success: function (data) {
                if (data.message == '') {
                    trLoginPluginForgotPasswordErrorMessage.innerHTML = `<div class="alert alert-danger" role="alert">
                                                                          <strong>Reset Error! </strong>`+ data.errorDetails.errorMsg + `
                                                                        </div>`;
                }

                if (data.hasResult == true) {
                    trPluginForgotPasswordSuccessMessage.innerHTML = `<div class="alert alert-success" role="alert">
                                                                          <strong>Success!</strong>` + data.message + `
                                                                        </div>`;
                    trLoginModelTitle.textContent = 'Sign in';
                    trLoginPluginMainModalBody.classList.remove('d-none');
                    trPluginLoginForgotPasswordSection.classList.add('d-none');
                }
            }
        });
    })
</script>