<div style="padding: 5px 30px">
    <form action="" method="post">
        <label for="">Remove all cache data from trip support plugin</label><br>
        <input type="submit" class="button-primary" name="celar-tr-plugin-cache" value="Clear">
    </form>
</div>