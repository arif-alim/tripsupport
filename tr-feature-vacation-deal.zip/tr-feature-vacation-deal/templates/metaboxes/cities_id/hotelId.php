<?php
global $post;
$postCityIdMetaBoxValue = get_post_meta($post->ID, 'tr_hotel_id', true);
?>

<label>City ID : </label>
<input type="number" name="tr_hotel_post_id" value="<?php echo $postCityIdMetaBoxValue ?>">